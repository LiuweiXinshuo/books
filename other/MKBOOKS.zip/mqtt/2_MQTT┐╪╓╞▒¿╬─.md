# 控制报文

### 报文结构：

​	固定报头 [+ 可变报头 + 有效载荷]



#### 固定报头

格式：2 byte

​	控制报文类型和属性 + 剩余长度

* 报文类型和属性：
  * 7-4bit：MQTT控制报文的类型，具体接下来介绍
  * 4-0bit：指定控制报文类型的标志位，具体接下来介绍

* 剩余长度：用于结算一个报文大小



报文类型：

| 名字        | 值   | bit  | 报文方向       | 描述                                |
| ----------- | ---- | ---- | -------------- | ----------------------------------- |
| Reserved    | 0    | 0x0  | 禁止           | 保留                                |
| CONNECT     | 1    | 0x1  | 客户端到服务端 | 客户端请求连接服务端                |
| CONNACK     | 2    | 0x2  | 服务端到客户端 | 连接报文确认                        |
| PUBLISH     | 3    | 0x3  | 两个方向都允许 | 发布消息                            |
| PUBACK      | 4    | 0x4  | 两个方向都允许 | QoS 1消息发布收到确认               |
| PUBREC      | 5    | 0x5  | 两个方向都允许 | 发布收到（保证交付第一步）          |
| PUBREL      | 6    | 0x6  | 两个方向都允许 | 发布释放（保证交付第二步）          |
| PUBCOMP     | 7    | 0x7  | 两个方向都允许 | QoS 2消息发布完成（保证交互第三步） |
| SUBSCRIBE   | 8    | 0x8  | 客户端到服务端 | 客户端订阅请求                      |
| SUBACK      | 9    | 0x9  | 服务器到客户端 | 订阅请求确认报文                    |
| UNSUBSCRIBE | 10   | 0xa  | 客户端到服务端 | 客户端取消订阅请求                  |
| UNSUBSACK   | 11   | 0xb  | 服务端到客户端 | 取消订阅报文确认                    |
| PINGREQ     | 12   | 0xc  | 客户端到服务端 | 心跳请求                            |
| PINGRESP    | 13   | 0xd  | 服务端到客户端 | 心跳响应                            |
| DISCONNECT  | 14   | 0xe  | 客户端到服务端 | 客户端断开连接                      |
| Reserved    | 15   | 0xf  | 禁止           | 保留                                |



标志位：

| 控制报文    | 固定报头标志       | Bit3 | Bit2 | Bit1 | Bit0    |
| ----------- | ------------------ | ---- | ---- | ---- | ------- |
| CONNECT     | Reserved           | 0    | 0    | 0    | 0       |
| CONNACK     | Reserved           | 0    | 0    | 0    | 0       |
| PUBLISH     | Used in MQTT 3.1.1 | DUP1 | QoS2 | QoS2 | RETAIN3 |
| PUBACK      | Reserved           | 0    | 0    | 0    | 0       |
| PUBREC      | Reserved           | 0    | 0    | 0    | 0       |
| PUBREL      | Reserved           | 0    | 0    | 1    | 0       |
| PUBCOMP     | Reserved           | 0    | 0    | 0    | 0       |
| SUBSCRIBE   | Reserved           | 0    | 0    | 1    | 0       |
| SUBACK      | Reserved           | 0    | 0    | 0    | 0       |
| UNSUBSCRIBE | Reserved           | 0    | 0    | 1    | 0       |
| UNSUBACK    | Reserved           | 0    | 0    | 0    | 0       |
| PINGREQ     | Reserved           | 0    | 0    | 0    | 0       |
| PINGRESP    | Reserved           | 0    | 0    | 0    | 0       |
| DISCONNECT  | Reserved           | 0    | 0    | 0    | 0       |

* DUP 1 = 控制报文的重复分发标志
* QoS2 = PUBLISH 报文的服务质量等级
* RETAIN3 = PUBLISH 报文的保留标志



剩余长度： = 可变报文头 + 负载数据





