# -*- coding:utf-8 -*-
#  Author : lw

""" signals and slot
    1. button.clicked.connect(self.slot_method)
    2. widget.signal.connect(slot_method)
    3. QtCore.QObject.connect(widget, QtCore.SIGNAL('signalname'), slot_function)
"""

from PyQt5.QtWidgets import (QApplication, QDialog, QDialogButtonBox, QPushButton, QVBoxLayout,)
import sys

class Dialog(QDialog):
    def slot_method(self):
        print('Slot method called')

    def __init__(self):
        super(Dialog, self).__init__()

        button = QPushButton('click')
        button.clicked.connect(self.slot_method)

        mainLayout = QVBoxLayout()
        mainLayout.addWidget(button)

        self.setLayout(mainLayout)
        self.setWindowTitle('Button example')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    dialog = Dialog()
    sys.exit(dialog.exec_())