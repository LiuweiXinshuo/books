# 使用 Qt 组件创建用户界面

在本章中，我们将学习使用以下 widgets：

* 显示欢迎信息
* 使用单选按钮小部件
* 分组单选按钮
* 以复选框形式显示选项
* 显示两组复选框



## 介绍

我们将学习使用Qt工具包创建GUI应用程序。 Qt工具箱（简称 Qt）是 Trolltech 开发的跨平台应用程序和UI框架，用于开发GUI应用程序。 它可以在多个平台上运行，包括 Windows，macOS X，Linux 和其他 UNIX 平台。 它也称为窗口小部件工具箱，因为它提供了设计GUI所需的窗口小部件，例如按钮，标签，文本框，按钮和列表框。 它包括类的跨平台集合，集成开发工具和跨平台IDE。 为了创建实时应用程序，我们将为称为 PyQt5 的Qt工具包使用Python绑定。



### PyQt

PyQt 是跨平台应用程序框架的一组Python绑定，结合了Qt和Python的所有优点。使用PyQt，您可以在Python代码中包含Qt库，从而使您能够用Python编写GUI应用程序。换句话说，PyQt允许您通过Python代码访问Qt提供的所有功能。由于PyQt取决于要运行的Qt库，因此在安装PyQt时，所需的Qt版本也会自动安装在您的计算机上。
GUI应用程序可能包含一个带有多个对话框的主窗口，也可能只有一个对话框。一个小型GUI应用程序通常包含至少一个对话框。对话框应用程序包含按钮。它不包含菜单栏，工具栏，状态栏或中央小部件，而主窗口应用程序通常具有所有这些。
对话框有以下两种类型：

* 模态：此对话框是阻止用户与应用程序其他部分进行交互的对话框。对话框是用户可以与之交互的应用程序的唯一部分。在关闭对话框之前，无法访问应用程序的其他部分。
* 无模式：此对话框与模式对话框相反。当无模式对话框处于活动状态时，用户可以自由与对话框以及应用程序的其余部分进行交互。



### 创建GUI应用程序的方法

有以下两种方式来编写GUI应用程序：

* 从头开始，使用简单的文本编辑器
* 使用Qt Designer，这是一个可视化设计工具，您可以使用它通过拖放快速创建用户界面。您将使用Qt Designer在PyQt中开发GUI应用程序，因为它既快速又容易
  无需编写任何代码即可设计用户界面的方法。 因此，双击桌面上的图标启动Qt Designer。

打开时，Qt Designer要求您为新应用程序选择模板，如以下屏幕截图所示：

<img src="./images/1_1.png" alt="qtdesigner" style="zoom:90%;" />



Qt Designer提供了许多适用于不同类型应用程序的模板。 您可以选择任何这些模板，然后单击“创建”按钮。

Qt Designer为新应用程序提供了以下预定义模板：

* 带有按钮底部的对话框：此模板创建一个窗体，该窗体的右下角具有“确定”和“取消”按钮。
* 带有按钮的对话框向右：此模板创建一个带有右上角的“确定”和“取消”按钮的表单。
* 没有按钮的对话框：此模板创建一个空窗体，您可以在其中放置小部件。 对话框的超类是QDialog。
* 主窗口：此模板提供一个带有菜单栏和工具栏的主应用程序窗口，如果不需要，可以将其删除。
* 窗口小部件：此模板创建一个表单，其父类是QWidget而不是QDialog。

每个GUI应用程序都有一个顶级小部件，其余小部件称为其子级。 顶层小部件可以是QDialog，QWidget或QMainWindow，具体取决于所需的模板。 如果要基于对话框模板创建应用程序，则继承的顶级窗口小部件或第一个类将是QDialog。 同样，要创建基于主窗口模板的应用程序，顶级窗口小部件将是QMainWindow，并且要创建基于窗口小部件模板的应用程序，您需要继承QWidget类。 如前所述，用于用户界面的其余窗口小部件称为类的子窗口小部件。

Qt Designer 在顶部显示菜单栏和工具栏。 它在左侧显示一个“小部件”框，其中包含用于开发应用程序的各种小部件，按小节分组。 您要做的就是从表单中拖放所需的小部件。 您可以在布局中排列小部件，设置其外观，提供初始属性并将其信号连接到插槽。



### 显示欢迎信息

在此配方中，将提示用户输入他/她的名字，然后单击一个按钮。 单击按钮后，将出现欢迎消息“ Hello”，后跟用户输入的名称。 对于此食谱，我们需要使用三个小部件，即标签，行编辑和按钮。 让我们一一理解这些小部件。



### 了解标签小部件
Label小部件是QLabel类的实例，用于显示消息和图像。 因为“标签”小部件仅显示计算结果，并且不接受任何输入，所以它们仅用于在屏幕上提供信息。



### 方法

以下是QLabel类提供的方法：

* setText() ：此方法将文本分配给Label小部件
* setPixmap() ：此方法将pixmap（QPixmap类的实例）分配给 Label 小部件。
* setNum() ：此方法为Label小部件分配一个整数或双精度值
* clear() ：此方法从“标签”小部件中清除文本

QLabel的默认文本是TextLabel。 也就是说，当您通过拖动Label小部件并将其拖放到表单上来将QLabel类添加到表单时，它将显示TextLabel。 除了使用 setText() 之外，还可以通过在“属性编辑器”窗口中设置其文本属性，将文本分配给选定的QLabel对象。



### 了解 Line Edit widget

“Line Edit” widget 通常用于输入单行数据。 Line Edit小部件是QLineEdit类的实例，您不仅可以输入，还可以编辑数据。 除了输入数据，您还可以在“Line Edit ” widget 中撤消，重做，剪切和粘贴数据。





### 怎么做...

让我们基于无按钮对话框模板创建一个新的应用程序。 如前所述，该应用程序将提示用户输入名称，并且在输入名称后单击按钮时，该应用程序将显示问候消息以及输入的名称。 以下是创建此应用程序的步骤：

1. 将 lable widget 从 Display Widgets 类别中拖放到窗体上。 将其 text 属性设置为Enter your name。 将 Label widget 的 objectName 属性设置为 labelResponse。

2. 从Display Widgets 类别中再拖动一个 Label widget ，并将其放在表单上。 不要更改此 Label 小部件的text属性，并将其text属性保留为其默认值TextLabel。 这是因为此Label小部件的text属性将通过代码设置，即，它将用于向用户显示问候消息。

3. 从 Input Widgets 类别中拖动一个 Line Edit ，并将其拖放到表单上。 将其 objectName 属性设置为lineEditName。

4. 从Button 类别中拖动一个 Push Button widget，然后将其拖放到表单上。 将其text属性设置为Click。 您可以通过以下三种方式之一来更改“按钮”小部件的text属性：双击“按钮”小部件并覆盖默认文本，通过右键单击Push Button并选择“更改文本...”选项。 弹出的上下文菜单，或者从“属性编辑器”窗口中选择文本属性并覆盖默认文本。

5. 将“按钮”小部件的objectName属性设置为ButtonClickMe。

6. 使用名称demoLineEdit.ui保存应用程序。 现在将显示该表单，如以下屏幕截图所示：
   <img src="./images/1_2.png" alt="demo1" style="zoom:70%;" />

   您使用Qt Designer创建的用户界面存储在.ui文件中，该文件包含所有表单信息：其小部件，布局等。 .ui文件是XML文件，您需要将其转换为Python代码。 这样，您可以在视觉界面和代码中实现的行为之间保持清晰的分隔。

7. 要使用.ui文件，您首先需要将其转换为Python脚本。 用于将.ui文件转换为Python脚本的命令实用程序是pyuic5。 在Windows中，pyuic5实用程序与PyQt捆绑在一起。 要进行转换，您需要打开命令提示符窗口，然后导航到保存文件的文件夹，然后发出以下命令：

   ```shell
   C:\Pythonbook\PyQt5>pyuic5 demoLineEdit.ui -o demoLineEdit.py
   ```

   > 不应手动修改此方法生成的Python代码，因为下次您运行pyuic5命令时，所有更改都会被覆盖。

8. 将demoLineEdit.py文件中的代码视为头文件，并将其导入到您将从中调用其用户界面设计的文件中。

9. 让我们创建另一个名为callLineEdit.py的Python文件，并将demoLineEdit.py代码导入其中，如下所示：

   ```python
   import sys
   from PyQt5.QtWidgets import QDialog, QApplication
   from demoLineEdit import *
   
   class MyForm(QDialog):
       def __init__(self):
           super().__init__()
           self.ui = Ui_Dialog()
           self.ui.setupUi(self)
           self.ui.ButtonClickMe.clicked.connect(self.dispmessage)
           self.show()
       def dispmessage(self):
           self.ui.labelResponse.setText("Hello "+self.ui.lineEditName.text())
   
   if __name__=="__main__":
       app = QApplication(sys.argv)
       w = MyForm()
       w.show()
       sys.exit(app.exec_())
   ```



### 如何运作的...

demoLineEdit.py 文件非常容易理解。 将创建一个带有顶级对象名称的类，并带有Ui_前缀。 由于在我们的应用程序中使用的顶级对象是Dialog，因此将创建Ui_Dialog类并存储我们小部件的界面元素。 该类有两个方法，setupUi() 和 retranslateUi() 。 setupUi() 方法设置窗口小部件； 它创建您在Qt Designer中定义用户界面时使用的小部件。 该方法一个接一个地创建小部件，并设置其属性。 setupUi() 方法采用单个参数，这是在其中创建用户界面（子窗口小部件）的顶级窗口小部件。 在我们的应用程序中，它是QDialog的一个实例。 retranslateUi() 方法转换接口。

让我们了解一下callLineEdit.py在语句方面的作用：

1. 导入必要的模块。 QWidget是PyQt5中所有用户界面对象的基类。
2. 它创建一个新的MyForm类，该类继承自基类QDialog。
3. 它提供了QDialog的默认构造函数。默认构造函数没有父级，没有父级的窗口小部件称为窗口。
4. PyQt5中的事件处理使用信号和插槽。信号是事件，时隙是在信号出现时执行的方法。例如，当您单击按钮时，将发生clicked（）事件，也称为信号。 connect（）方法将信号与插槽连接。在这种情况下，slot是一种方法：
   dispmessage（）。也就是说，当用户单击按钮时，将调用dispmessage（）方法。 clicked（）是此处的事件，事件处理循环等待事件发生，然后分派它以执行某些任务。事件处理循环将继续工作，直到调用exit（）方法或销毁了主窗口小部件为止。
5. 它通过QApplication（）方法创建一个名为app的应用程序对象。每个PyQt5应用程序都必须创建sys.argv应用程序对象，该对象包含命令行中的参数列表，并在创建应用程序对象时将其传递给方法。 sys.argv参数有助于传递和控制脚本的启动属性。
6. 将创建名称为w的MyForm类的实例。

7. show() 方法将在屏幕上显示小部件。
8. dispmessage() 方法对按钮执行事件处理。 它显示Hello文本以及在Line Edit小部件中输入的名称。
9. sys.exit() 方法确保干净退出，释放内存资源。