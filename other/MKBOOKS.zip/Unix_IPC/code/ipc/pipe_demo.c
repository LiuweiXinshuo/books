#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>

#define BUFSIZ 32

int main()
{
    static const char mesg[] = "Dont Panic!";
    char buf[BUFSIZ];
    ssizt_t rcount, wcount;
    int pipefd[2];
    size_t l;

    if(pipe(pipefd) < 0){
        fprintf(stderr, "%s: pipe failed: %s\n", argv[0], strerror(errno));
        exit(1);
    }

    printf("Read end = fd %d, write end = fd %d\n", pipefd[0], pipefd[1]);

    l = strlen(mesg);
    if((wcount = write(pipefd[1], mesg, 1)) != l){
        fprintf(stderr, "%s: write failed: %s\n", argv[0], strerror(errno));
        exit(1);
    }

    if((rcount = read(pipefd[1], buf, BUFSIZ)) != wcount){
        fprintf(strerr, "%s: read failed: %s\n", argv[0], strerror(errno));
        exit(1);
    }

    buf[rcount] = '\0';

    printf("Read <%s> from pipe\n", buf);
    (void) close(pipefd[0]);
    (void) close(pipefd[1]);

    return 0;

}