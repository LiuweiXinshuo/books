# 使用 QJsonDocument 处理 JSON



### （1）：使用 QJsonDocument 处理 JSON
上一章我们了解了如何使用 QJson 处理 JSON 文档。QJson 是一个基于 Qt 的第三方库，适用于 Qt4 和 Qt5 两个版本。不过，如果你的应用仅仅需要考虑兼容 Qt5，其实已经有了内置的处理函数。Qt5 新增加了处理 JSON 的类，与 XML 类库类似，均以 QJson 开头，在 QtCore 模块中，不需要额外引入其它模块。Qt5 新增加六个相关类：

| QJsonArray | 封装 JSON 数组 |
| -- || -- |
| QJsonDocument | 读写 JSON 文档 |
| QJsonObject | 封装 JSON 对象 |
| QJsonObject::iterator | 用于遍历QJsonObject的 STL 风格的非 const 遍历器 |
| QJsonParseError | 报告 JSON 处理过程中出现的错误 |
| QJsonValue | 封装 JSON 值 |

我们还是使用前一章的 JSON 文档，这次换用`QJsonDocument` 来解析。注意，`QJsonDocument`要求使用 Qt5，本章中所有代码都必须在 Qt5 环境下进行编译运行。

```
QString json("{"
        "\"encoding\" : \"UTF-8\","
        "\"plug-ins\" : ["
        "\"python\","
        "\"c++\","
        "\"ruby\""
        "],"
        "\"indent\" : { \"length\" : 3, \"use_space\" : true }"
        "}");
QJsonParseError error;
QJsonDocument jsonDocument = QJsonDocument::fromJson(json.toUtf8(), &error);
if (error.error == QJsonParseError::NoError) {
    if (jsonDocument.isObject()) {
        QVariantMap result = jsonDocument.toVariant().toMap();
        qDebug() << "encoding:" << result["encoding"].toString();
        qDebug() << "plugins:";
 
        foreach (QVariant plugin, result["plug-ins"].toList()) {
            qDebug() << "\t-" << plugin.toString();
        }
 
        QVariantMap nestedMap = result["indent"].toMap();
        qDebug() << "length:" << nestedMap["length"].toInt();
        qDebug() << "use_space:" << nestedMap["use_space"].toBool();
    }
} else {
    qFatal(error.errorString().toUtf8().constData());
    exit(1);
}
```

这段代码与前面的几乎相同。`QJsonDocument::fromJson()`可以由`QByteArray`对象构造一个`QJsonDocument`对象，用于我们的读写操作。这里我们传入一个`QJsonParseError`对象的指针作为第二个参数，用于获取解析的结果。如果`QJsonParseError::error()`的返回值为`QJsonParseError::NoError`，说明一切正常，则继续以`QVariant`的格式进行解析（由于我们知道这是一个 JSON 对象，因此只判断了`isObject()`。当处理未知的 JSON 时，或许应当将所有的情况都考虑一边，包括`isObject()`、`isArray()`以及`isEmpty()`）。

也就是说，如果需要使用`QJsonDocument`处理 JSON 文档，我们只需要使用下面的代码模板：

```
// 1. 创建 QJsonParseError 对象，用来获取解析结果
QJsonParseError error;
// 2. 使用静态函数获取 QJsonDocument 对象
QJsonDocument jsonDocument = QJsonDocument::fromJson(json.toUtf8(), &error);
// 3. 根据解析结果进行处理
if (error.error == QJsonParseError::NoError) {
    if (!(jsonDocument.isNull() || jsonDocument.isEmpty())) {
        if (jsonDocument.isObject()) {
            // ...
        } else if (jsonDocument.isArray()) {
            // ...
        }
    }
} else {
    // 检查错误类型
}
```

将`QVariant`对象生成 JSON 文档也很简单：

```
QVariantList people;
 
QVariantMap bob;
bob.insert("Name", "Bob");
bob.insert("Phonenumber", 123);
 
QVariantMap alice;
alice.insert("Name", "Alice");
alice.insert("Phonenumber", 321);
 
people << bob << alice;
 
QJsonDocument jsonDocument = QJsonDocument::fromVariant(people);
if (!jsonDocument.isNull()) {
    qDebug() << jsonDocument.toJson();
```

这里我们仍然使用的是`QJsonDocument`，只不过这次我们需要使用`QJsonDocument::fromVariant()`函数获取`QJsonDocument`对象。`QJsonDocument`也可以以二进制格式读取对象，比如`QJsonDocument::fromBinaryData()`和`QJsonDocument::fromRawData()`函数。当我们成功获取到`QJsonDocument`对象之后，可以使用`toJson()`生成 JSON 文档。

以上介绍了当我们有一个 JSON 文档时，如何使用`QJsonDocument`进行处理。如果我们没有 JSON 文档，那么我们可以使用`QJsonDocument`的`setArray()`和`setObject()`函数动态设置该对象，然后再生成对应的 JSON 格式文档。不过这部分需求比较罕见，因为我们直接可以从`QVariant`值类型获取。

Qt5 提供的 JSON 类库直接支持[隐式数据共享](http://www.devbean.net/2013/01/qt-study-road-2-implicit-sharing/)，因此我们不需要为复制的效率担心。