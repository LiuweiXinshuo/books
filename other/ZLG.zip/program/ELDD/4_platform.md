# 平台设备和驱动程序

有关平台总线的驱动程序模型接口，请参见<linux/platform_device.h>：platform_device和platform_driver。 这种伪总线用于以最小的基础结构连接总线上的设备，例如用于集成许多片上系统处理器上的外围设备或某些“传统” PC互连的设备。 与大型正式指定的PCI或USB相对。

**平台设备**

平台设备是通常在系统中显示为自治实体的设备。 这包括基于旧端口的设备和到外围总线的主机桥接，以及集成到片上系统平台中的大多数控制器。 它们通常的共同点是从CPU总线直接寻址。 很少有 platform_device 通过某种其他类型的总线的一部分连接的。 但其寄存器仍将直接可寻址。

会给平台设备一个名称，用于驱动程序绑定，以及一个资源列表，例如地址和IRQ。

```c
struct platform_device {
	const char	*name;
	u32		id;
	struct device	dev;
	u32		num_resources;
	struct resource	*resource;
};
```

**平台驱动**

平台驱动程序遵循标准的驱动程序模型约定，其中发现/枚举在驱动程序之外进行，驱动程序提供 probe() 和remove() 方法。 它们支持使用标准约定的电源管理和关机通知。

```c
struct platform_driver {
	int (*probe)(struct platform_device *);
	int (*remove)(struct platform_device *);
	void (*shutdown)(struct platform_device *);
	int (*suspend)(struct platform_device *, pm_message_t state);
	int (*suspend_late)(struct platform_device *, pm_message_t state);
	int (*resume_early)(struct platform_device *);
	int (*resume)(struct platform_device *);
	struct device_driver driver;
};
```

请注意，probe() 应该常规验证指定的设备硬件确实存在； 有时无法确定平台设置代码。 探测可以使用设备资源，包括时钟和设备 platform_data。

平台驱动程序以正常方式注册自己：

```c
	int platform_driver_register(struct platform_driver *drv);
```

或者，在已知设备不可热插拔的常见情况下，probe() 例程可以驻留在init节中，以减少驱动程序的运行时内存占用量：

```c
	int platform_driver_probe(struct platform_driver *drv,
			  int (*probe)(struct platform_device *))
```

**设备枚举**