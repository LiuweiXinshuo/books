1.简介

​	这是一组驱动程序，旨在支持Linux下的所有输入设备。 尽管目前仅将其用于USB输入设备，但未来的用途（例如2.5 / 2.6）有望扩展以替代大多数现有的输入系统，这就是为什么它存在于driver / input /而不是driver / usb /的原因。

   输入驱动程序的中心是输入模块，必须在其他任何输入模块之前加载该输入模块-它用作两组模块之间的通信方式：

1.1设备驱动程序
   这些模块与硬件通信（例如，通过USB），并向输入模块提供事件（按键，鼠标移动）。

1.2事件处理程序
   这些模块从输入中获取事件，并通过各种接口将它们传递给需要的地方-击键到内核，鼠标移动通过模拟的PS / 2接口到GPM和X等。

2.简单的用法
   对于最普通的配置，用一个USB鼠标和一个USB键盘，您将必须加载以下模块（或将其内置到内核中）：

	input
	mousedev
	keybdev
	usbcore
	uhci_hcd or ohci_hcd or ehci_hcd
	usbhid
之后，USB键盘将立即工作，并且USB鼠标将在主要13，次要63上用作字符设备：

​	crw-r--r--   1 root     root      13,  63 Mar 28 22:45 mice

   必须创建该设备。
   手动创建的命令是：

	cd /dev
	mkdir input
	mknod input/mice c 13 63
   之后，您必须将GPM（文本模式鼠标剪切和粘贴工具）和XFree指向该设备才能使用它-GPM应该像这样调用：

```
	gpm -t ps2 -m /dev/input/mice
```

   在X中：

```
	Section "Pointer"
	    Protocol    "ImPS/2"
	    Device      "/dev/input/mice"
	    ZAxisMapping 4 5
	EndSection
```

   完成上述所有操作后，即可使用USB鼠标和键盘。

3.详细说明
3.1设备驱动程序
   设备驱动程序是生成事件的模块。 但是，如果不处理事件，这些事件将无用，因此您还需要使用3.2节中的某些模块。

3.1.1 USB
  usbhid是整个套件中最大，最复杂的驱动程序。它可以处理所有HID设备，并且因为它们种类繁多，并且因为USB HID规范并不简单，所以它必须很大。

  目前，它可以处理USB鼠标，操纵杆，游戏手柄，方向盘键盘，轨迹球和数字转换器。

 但是，USB也将HID用于监视器控件，扬声器控件，UPS，LCD和许多其他用途。

 监视器和扬声器控件应易于添加到隐藏/输入界面，但对于UPS和LCD而言，意义不大。为此，设计了hiddev接口。有关更多信息，请参见Documentation / usb / hiddev.txt。

  usbhid模块的用法非常简单，它不带任何参数，可以自动检测所有内容，并且在插入HID设备后，可以对其进行适当检测。

  但是，由于设备千差万别，您可能碰巧遇到了运行不正常的设备。在这种情况下，请在hid-core.c的开头#define DEBUG并向我发送syslog跟踪信息。

3.1.2 usbmouse
   对于嵌入式系统，对于具有损坏的HID描述符的鼠标，以及在大usbhid不太合适的情况下用于其他任何用途的情况，有usbmouse驱动程序。 它仅处理USB鼠标。 它使用更简单的HIDBP协议。 这也意味着鼠标必须支持此更简单的协议。 并非全部。 如果没有充分的理由使用此模块，请改用usbhid。

3.1.3 usbkbd
   就像usbmouse一样，此模块可与具有简化HIDBP协议的键盘对话。 它比较小，但是不支持任何额外的特殊键，如果没有特殊原因请使用usbhid。

3.1.4 wacom
   这是Wacom Graphire和Intuos平板电脑的驱动程序。 不是Wacom PenPartner，那是由HID驱动程序处理的。 尽管Intuos和Graphire平板电脑声称它们也是HID平板电脑，但它们不是HID平板电脑，因此需要此特定驱动程序。

3.1.5 iforce
   通过USB和RS232的I-Force操纵杆和滚轮驱动程序。 即使Immersion Corp.将该协议视为商业机密，也不会透露任何消息，但它现在包括ForceFeedback支持。

3.2事件处理程序
   事件处理程序根据需要将事件从设备分发到用户域和内核。

3.2.1 keybdev
   keybdev目前是一个相当丑陋的黑客，它将输入事件转换为特定于体系结构的键盘原始模式（x86上的Xlated AT Set2），并将其传递到keyboard.c模块的handle_scancode函数中。 这在keybdev可以在其上生成rawmode的所有体系结构上都足够好，可以向其添加其他体系结构。

   正确的方法是将事件直接传递给keyboard.c，最好是如果keyboard.c本身就是事件处理程序。 这是在输入补丁中完成的，该补丁可在下面提到的网页上找到。

3.2.2 mousedev
   mousedev还是一种使使用鼠标输入的程序正常工作的黑客。 它从鼠标或数字转换器/平板电脑获取事件，并使PS / 2样式（ /dev/psaux）鼠标设备可供用户使用。 理想情况下，程序可以使用更合理的界面，例如evdev
   /dev/input 中的Mousedev设备（如上所示）为：

```shell
	crw-r--r--   1 root     root      13,  32 Mar 28 22:45 mouse0
	crw-r--r--   1 root     root      13,  33 Mar 29 00:41 mouse1
	crw-r--r--   1 root     root      13,  34 Mar 29 00:41 mouse2
	crw-r--r--   1 root     root      13,  35 Apr  1 10:50 mouse3
	...
	...
	crw-r--r--   1 root     root      13,  62 Apr  1 10:50 mouse30
	crw-r--r--   1 root     root      13,  63 Apr  1 10:50 mice
```

每个“鼠标”设备都分配给一个鼠标或数字转换器，最后一个鼠标除外。 所有鼠标和数字转换器都共享该单字符设备，即使没有连接，也存在该设备。 这对于热插拔USB鼠标很有用，这样即使没有鼠标，程序也可以打开设备。

   内核配置中的CONFIG_INPUT_MOUSEDEV_SCREEN_ [XY]是XFree86中屏幕的大小（以像素为单位）。 如果要在X中使用数字转换器，则需要这样做，因为它的移动是通过虚拟PS / 2鼠标发送到X的，因此需要相应地缩放。 如果仅使用鼠标，则不会使用这些值。

   Mousedev将生成PS / 2，ImPS / 2（Microsoft IntelliMouse）或ExplorerPS / 2（IntelliMouse Explorer）协议，具体取决于读取数据的程序的要求。 您可以将GPM和X设置为其中任何一个。 如果要使用USB鼠标上的滚轮，则需要ImPS / 2；如果要使用额外的按钮（最多5个），则需要ExplorerPS / 2。

3.3 游戏杆

Joydev实现了v0.x和v1.x Linux游戏杆api，非常类似于早期版本中使用的driver / char / joystick / joystick.c。 有关详细信息，请参见“文档”子目录中的joystick-api.txt。 一旦连接了任何游戏杆，就可以在/ dev / input上对其进行访问：

```
	crw-r--r--   1 root     root      13,   0 Apr  1 10:50 js0
	crw-r--r--   1 root     root      13,   1 Apr  1 10:50 js1
	crw-r--r--   1 root     root      13,   2 Apr  1 10:50 js2
	crw-r--r--   1 root     root      13,   3 Apr  1 10:50 js3
	...
```

3.4 事件接口

evdev是通用输入事件接口。 它将带有时间戳的内核中生成的事件直接传递给程序。 该API仍在不断发展，但现在应该可以使用。 在第5节中进行了描述。

   这应该是GPM和X获取键盘和鼠标事件的方式。 它允许在X中使用多头，而无需任何特定的多头内核支持。 事件代码在所有体系结构上都是相同的，并且与硬件无关。



# INPUT 驱动编程



## 1. 创建一个 INPUT 设备驱动



### 1.0 最简单的例子

这有一个非常简单的 INPUT 设备驱动例子。这个设备只有一个按钮，该按钮能通过 `BUTTON_PORT` 端口来访问。当按下或者释放时，设备会产生一个 `BUTTON_IRQ` 中断。驱动代码看上去像这样：

```
#include <linux/input.h>
#include <linux/module.h>
#include <linux/init.h>

#include <asm/irq.h>
#include <asm/io.h>

static struct input_dev *button_dev;

static irqreturn_t button_interrupt(int irq, void *dummy)
{
    input_report_key(button_dev, BTN_0, inb(BUTTON_PORT) & 1);
    input_sync(button_dev);
    return IRQ_HANDLED;
}

static int __init button_init(void)
{
    int error;

    if (request_irq(BUTTON_IRQ, button_interrupt, 0, "button", NULL)) {
                printk(KERN_ERR "button.c: Can't allocate irq %d\n", button_irq);
                return -EBUSY;
        }

    button_dev = input_allocate_device();
    if (!button_dev) {
        printk(KERN_ERR "button.c: Not enough memory\n");
        error = -ENOMEM;
        goto err_free_irq;
    }

    button_dev->evbit[0] = BIT_MASK(EV_KEY);
    button_dev->keybit[BIT_WORD(BTN_0)] = BIT_MASK(BTN_0);

    error = input_register_device(button_dev);
    if (error) {
        printk(KERN_ERR "button.c: Failed to register device\n");
        goto err_free_dev;
    }

    return 0;

 err_free_dev:
    input_free_device(button_dev);
 err_free_irq:
    free_irq(BUTTON_IRQ, button_interrupt);
    return error;
}

static void __exit button_exit(void)
{
        input_unregister_device(button_dev);
    free_irq(BUTTON_IRQ, button_interrupt);
}

module_init(button_init);
module_exit(button_exit);
```



### 1.1 这个例子做了什么

首先，它包含了 `<linux/input.h>` 头文件，这是 INPUT 子系统的接口。该头文件提供了所有需要的定义。

初始化函数 `_init` 会在模块加载或者内核启动过程中调用，它分配必要的资源（它同时也应该检测相应设备是否存在）。

然后它通过 `input_allocate_device()` 分配一个新的 INPUT 设备结构体，并且设定相应位字段。设备驱动通过这个结构体告诉 INPUT 系统的其他模块：该设备是什么，它产生或者接受什么事件。我们的设备只能够产生 `EV_KEY` 类型事件，所以也只能有一个 `BTN_0` 事件编码。因此，我们只需要设置这两个位。我们可以使用下面两种形式来设置

```
set_bit(EV_KEY, button_dev.evbit);
set_bit(BTN_0, button_dev.keybit);
```

但是若不止一个位，第一种方法更简单一点。

然后示例驱动通过如下调用注册该 INPUT 设备结构体

```
input_register_device(&button_dev);
```

这会把 button_dev 架构体加入 INPUT 驱动链表里，然后调用设备处理模块 `_connect` 函数，来告诉他们一个新 INPUT 设备出现了。`input_register_device()` 调用可能会导致进程睡眠，因此不能在中断上下文或者自旋锁上下文调用。

在使用过程中，这个驱动唯一使用的函数是

```
button_interrupt()
```

该函数会在每一次按钮中断到来时，检测它的状态，并通过 `input_report_key()` 调用把该事件上报给 INPUT 系统。这里不需要在中断处理函数中检测是否上报了两个相同的值（例如，连续两次按下），因为 `input_report_*` 函数会检测这些。

然后这有一个

```
input_sync()
```

调用来告诉接收这个事件的模块：我们已经发送了一个完整的事件。在只有一个按钮情况下，这看上去并不是很重要。但是对于那些像鼠标移动事件来说，这种调用就非常重要了。因为你不想单独处理 X 和 Y 值，这会导致异常的鼠标移动。



### 1.2 `dev->open()` 和 `dev->close()`

假设该驱动需要不断轮询设备，因为它没有中断信号。但是长时间轮询代价很大，或者该设备占用了关键资源（例如，中断），不能长久占用。它可以利用 `close` 回调函数来暂停轮询，或者释放中断，利用 `open` 回调函数再次恢复轮询，注册中断。为了达到这样的效果，我们可以在驱动中加入如下代码：

```
static int button_open(struct input_dev *dev)
{
    if (request_irq(BUTTON_IRQ, button_interrupt, 0, "button", NULL)) {
                printk(KERN_ERR "button.c: Can't allocate irq %d\n", button_irq);
                return -EBUSY;
        }

        return 0;
}

static void button_close(struct input_dev *dev)
{
        free_irq(IRQ_AMIGA_VERTB, button_interrupt);
}

static int __init button_init(void)
{
    ...
    button_dev->open = button_open;
    button_dev->close = button_close;
    ...
}
```

这里要注意的是 INPUT 系统核心会跟踪当前使用该设备的用户数，并且保证 `dev->open()` 只会在第一个用户连接该设备时调用，`dev->close()` 只会在最后一个用户断开连接时调用。对这两个回调函数的调用都是串行化的。（**注：**互斥？？）

`open()` 回调函数应该在成功时返回 0，错误时返回负值。`close()` 回调函数总是成功的（返回类型为 void）。



### 1.3 基本事件类型

最简单的事件类型是 `EV_KEY`，用于按键和按钮。它通过如下调用上报给 INPUT 系统：

```
input_report_key(struct input_dev *dev, int code, int value)
```

查看 `linux/input.h` 文件获取 `code` 所有可能的取值（0 ~ KEY_MAX）。`value` 被翻译为真实的值，例如非零值是按键被按下，零值代表按键被释放。INPUT 系统只会在当前值不同于上一次报的值时，才会生成事件。

除了 `EV_KEY`，这还有两种事件类型：`EV_REL` 和 `EV_ABS`。它们用于设备产生的相对值和绝对值。相对值就像鼠标在 X 轴移动那样。因为它没有绝对的坐标系统做参照，只能上报相对于上一个位置的相对值。绝对值用于那些有绝对坐标系统做参照的设备，像游戏杆和数字转换器。

让设备上报 `EV_REL` 类型事件，跟上报 `EV_KEY` 类型事件一样简单，只需要设置相应的位，然后调用

```
input_report_rel(struct input_dev *dev, int code, int value)
```

函数。这里只会对非零值才会生成事件。

但是 `EV_ABS` 事件有一点特殊。在调用 `input_register_device` 之前，你必须在 `input_dev` 结构体中为该设备的每一个绝对类型的轴填充一些区域。如果按钮设备有一个 `ABS_X` 轴，我们需要做如下设置：

```
button_dev.absmin[ABS_X] = 0;
button_dev.absmax[ABS_X] = 255;
button_dev.absfuzz[ABS_X] = 4;
button_dev.absflat[ABS_X] = 8;
```

或者，我们可以简单调用：

```
input_set_abs_params(button_dev, ABS_X, 0, 255, 4, 8);
```

这种设定适合游戏杆的 X axis，最小值为 0，最大值为 255（游戏杆**必须**能够达到这个范围内的数值，偶尔超出这个范围也是没问题的，但是这个范围内的数值得能上报），数据的噪声为 +/- 4，点大小距中心位置为 8（**原文：**with a center flat position of size 8）。

如果你不需要 `absfuzz` 和 `absflat`，你可以把它们设为 0，这意味着报的值是非常精准的，并且每次都是在点的中心位置。



### 1.4 `BITS_TO_LONGS()`, `BIT_WORD()`, `BIT_MASK()`

这 3 个在 `bitops.h` 中的宏用于简化一些位计算：

- `BITS_TO_LONGS(x)` - 返回 x 位在 long 类型位域数组中的长度
- `BIT_WORD(x)` - 返回第 x 位在 long 类型数组中的位置
- `BIT_MASK(x)` - 返回第 x 位在 long 中的位置掩码



### 1.5 `id*` 和 `name` 字段

`dev->name` 必须在 INPUT 设备注册之前在驱动中设置。name 字段包含一个用户友好的设备名字，就像 “Generic button device” 一样。

`id*` 字段包含总线 ID（PCI，USB），以及该设备的 PID 和 VID。总线 ID 是在 `input.h` 文件中定义的。设备的 PID 和 VID 是在 `pci_ids.h`，`usb_ids.h` 等类似的头文件中定义的。这些字段应该在注册之前由设备驱动设置。

`idtype` 字段能够用于存储 INPUT 设备驱动的特殊信息。（**注：**最新的内核代码中已经没有该字段）

`id` 和 `name` 字段能够通过 evdev 接口传递给上层应用。



### 1.6 keycode，keycodemax 和 keycodesize 字段

有很多按键映射的 INPUT 设备应该使用这三个字段。 `keycode` 是一个数组，用于映射从扫码（scancode）到 INPUT 系统的按键码（keycode）。`keycodemax` 应该包含该数组的大小，而 `keycodesize` 则是数组里每一项的大小（字节数）。

用户空间程序可以通过对应的 evdev 接口，使用 `EVIOCGKEYCODE` 和 `EVIOCSKEYCODE` ioctl 操作来查询和修改当前扫码到按键码的映射关系。当一个设备填充了前面提到的三个字段，其驱动应该基于内核默认的实现，设置和查询按键码映射。



### 1.7 `dev->getkeycode()` 和 `dev->setkeycode()`

`getkeycode()` 和 `setkeycode()` 回调函数允许驱动覆盖 INPUT 核心提供的默认 `keycode/keycodesize/keycodemax` 映射机制，实现稀疏的按键映射。



### 1.8 按键自动重复

按键自动重复比较简单。它是在 `input.c` 模块中处理的。硬件自动重复并没有被使用，因为并不是所有的设备都有这个功能，而且该功能不是很稳定（Toshiba 笔记本上的键盘）。要使能设备的自动重复功能，只需设置 `dev->evbit` 中的 `EV_REP`。INPUT 系统会处理所有的工作。



### 1.9 处理输出事件的特殊事件类型

到目前为止，特殊事件类型有：

- `EV_LED` - 用于键盘灯
- `EV_SND` - 用于键盘蜂鸣器

（**注：**`EV_LED` 和 `EV_SND` 并不只是局限于键盘，对于其他设备的 LED 和 声音输出，也是可以使用的）

（**注：**在最新的内核代码里，除了这两个，还有 `EV_FF`，`EV_FF_STATUS`，和 `EV_PWR`，具体见 event-codes.txt）

他们和普通的按键事件非常类似，但是他们的方向是相反的 - 从系统到 INPUT 设备驱动。如果你的 INPUT 设备驱动能够处理这些事件，驱动中必须设置 `evbit` 中相应的位，和回调函数：

```
    button_dev->event = button_event;

int button_event(struct input_dev *dev, unsigned int type, unsigned int code, int value);
{
    if (type == EV_SND && code == SND_BELL) {
        outb(value, BUTTON_BELL);
        return 0;
    }
    return -1;
}
```

这个回调函数能够在中断上下文或者中断下半部中调用（尽管没有这个规则），因此这个回调函数里不能睡下去，也不能消耗过长的时间。