## SPI

什么是SPI？

“串行外围设备接口”（SPI）是同步四线串行链路，用于将微控制器连接到传感器，存储器和外围设备。这是一个简单的“事实”标准，不够复杂，无法获得标准化机构。 SPI使用主/从配置。

三根信号线保持一个时钟（SCK，通常为10 MHz左右），并带有“ Master Out，Slave In”（MOSI）或“ Master In，Slave Out”（MISO）信号的并行数据线。 （也使用其他名称。）共有四种时钟模式，通过它们可以交换数据。模式0和模式3是最常用的。每个时钟周期将数据移出和移入；除非有数据位需要移位，否则时钟不会循环。但是，并不是所有的数据位都被使用。并非每个协议都使用那些全双工功能。

SPI主设备使用第四条“芯片选择”线来激活给定的SPI从设备，因此这三根信号线可以并行连接到多个芯片。所有SPI从机均支持芯片选择；它们通常是低电平有效信号，从机“ x”标记为nCSx（例如nCS0）。一些设备具有其他信号，通常包括对主机的中断。

与USB或SMBus之类的串行总线不同，即使是SPI从属功能的低级协议通常也无法在供应商之间互操作（除了SPI存储器芯片之类的商品）。

  -SPI可以用于请求/响应样式的设备协议，就像触摸屏传感器和存储芯片一样。

  -它也可以用于在任一方向（半双工）或同时在两个方向（全双工）流数据。

  -某些设备可能使用八位字。其他的则可能有不同的字长，例如12位或20位数字样本流。

  -字通常以其最高有效位（MSB）首先发送，但有时最低有效位（LSB）则首先发送。

  -有时SPI用于菊链式器件，例如移位寄存器。

以同样的方式，SPI器件将只有很少的支持任何类型的自动发现/列举的协议。从给定的SPI主设备访问的从设备树通常将通过配置表手动设置。

SPI只是这种四线协议使用的名称之一，大多数控制器在处理“ MicroWire”（对于请求/响应协议，将其视为半双工SPI），SSP（“同步串行协议”）时都没有问题。 ，PSP（“可编程串行协议”）和其他相关协议。

一些芯片通过组合MOSI和MISO并在硬件级别将其限制为半双工来消除信号线。实际上，某些 SPI 芯片将此信号模式作为打包选项。可以使用与SPI相同的编程接口来访问它们，但是它们当然不会处理全双工传输。您可能会发现此类芯片被描述为使用“三线”信令：SCK，数据，nCSx。 （该数据线有时称为MOMI或SISO。）

微控制器通常同时支持SPI协议的主端和从端。本文档（和Linux）当前仅支持SPI交互的主端。



**谁使用它？在哪种系统上？**

使用 SPI 的 Linux 开发人员可能正在为嵌入式系统板编写设备驱动程序。 SPI 用于控制外部芯片，它也是每个MMC 或 SD 存储卡都支持的协议。（较早的“ DataFlash”卡早于MMC卡，但使用相同的连接器和卡形状，仅支持SPI。）某些PC硬件将SPI闪存用于BIOS代码。

SPI 从芯片包括用于模拟传感器和编解码器的数字/模拟转换器，存储器，USB控制器或以太网适配器等外设。和更多。

大多数使用SPI的系统都会在主板上集成一些设备。有些在扩展连接器上提供SPI链接；有些则在SPI链接中提供。如果没有专用的SPI控制器，则可以使用GPIO引脚创建一个低速“ bitbanging”适配器。很少有系统会“热插拔” SPI控制器。使用SPI的原因集中在低成本和简单操作上，并且如果动态重新配置很重要，USB通常将是更合适的低引脚数外围总线。

许多可以运行Linux的微控制器都将一个或多个 I/O 接口与SPI模式集成在一起。有了SPI支持，他们可以使用MMC或SD卡，而无需特殊用途的 MMC/SD/SDIO 控制器。

**我糊涂了。 这四种SPI“时钟模式”是什么？**

在这里很容易混淆，您会发现供应商文档不一定有帮助。 四种模式结合了两个模式位：

* -CPOL 指示初始时钟极性。 CPOL = 0 表示时钟从低电平开始，因此第一个（上升沿）上升，而第二个（下降沿）下降。 CPOL = 1表示时钟开始为高电平，因此第一个（上升沿）下降。

* -CPHA 指示用于采样数据的时钟相位； CPHA = 0表示在上升沿采样，CPHA = 1表示在下降沿。

由于信号需要在采样之前稳定下来，因此CPHA = 0表示其数据在第一个时钟沿之前的半个时钟被写入。 chipselect 可能已使其可用。

芯片规格将不会总是说“使用SPI模式X”，但它们的时序图将使CPOL和CPHA模式清晰可见。

在SPI模式编号中，CPOL是高阶位，CPHA是低阶位。 因此，当芯片的时序图显示时钟起始为低电平（CPOL = 0）并且数据在时钟下降沿（CPHA = 1）期间稳定下来进行采样时，这就是SPI模式1。

请注意，只要 chipselect 变为活动状态，时钟模式就相关。 因此，主机必须在选择从机之前将时钟设置为非活动状态，并且当其选择线处于活动状态时，从机可以通过对时钟电平进行采样来告知所选极性。 这就是为什么许多设备都支持模式0和3的原因，它们不关心极性，并且始终在时钟上升沿输入/输出时钟数据。

**这些驱动程序编程接口如何工作？**

<linux/spi/spi.h> 头文件包括 kerneldoc ，以及主要源代码，您当然应该阅读内核API文档的这一章。这只是一个概述，因此您可以在获得这些详细信息之前先了解一下全局。

SPI请求始终进入I / O队列。对给定SPI设备的请求始终以FIFO顺序执行，并通过完成回调异步完成。对于这些调用，还有一些简单的同步包装器，其中包括用于常见事务类型的调用器，例如编写命令然后读取其响应。

有两种类型的SPI驱动程序，在这里称为：

  控制器驱动程序...控制器可能内置于片上系统处理器中，并且通常同时支持主角色和从角色。这些驱动程序接触硬件寄存器，并可能使用DMA。或者它们可以是仅需GPIO引脚的PIO bitbangers。

  协议驱动程序...通过协议驱动程序传递消息，以与SPI链路另一侧的从设备或主设备进行通信。

因此，例如，一个协议驱动程序可能会与MTD层进行对话，以将数据导出到存储在SPI闪存中的文件系统（例如DataFlash）；其他则可能控制音频接口，将触摸屏传感器作为输入接口，或者在工业处理过程中监控温度和电压水平。而且这些可能都共享相同的控制器驱动程序

“ struct spi_device”封装了这两种类型的驱动程序之间的主侧接口。在撰写本文时，Linux没有从属端编程接口。

SPI编程接口只有一个最小的核心，它专注于使用驱动程序模型，通过板专用初始化代码提供的设备表来连接控制器和协议驱动程序。 SPI显示在sysfs中的多个位置：

   /sys/devices/.../CTLR ...给定SPI控制器的物理节点

   /sys/devices/.../CTLR/spiB.C ...总线“ B”上的spi_device，芯片选择C，可通过CTLR访问。

   /sys/bus/spi/devices/spiB.C ...该物理链接
    ... / CTLR / spiB.C设备

   /sys/devices/.../CTLR/spiB.C/modalias ...标识驱动程序
该设备应使用的（对于热插拔/冷插拔）

   / sys / bus / spi / drivers / D ...一个或多个spi *。*设备的驱动程序

   / sys / class / spi_master / spiB ...到逻辑节点的符号链接（或实际设备节点），该逻辑节点可以为管理总线“ B”的控制器保留与类相关的状态。所有spiB。*器件共享一个物理SPI总线段，以及SCLK，MOSI 和 MISO。

请注意，控制器类状态的实际位置取决于是否启用了CONFIG_SYSFS_DEPRECATED。 此时，唯一的特定于类的状态是总线号（“ spiB”中的“ B”），因此那些/ sys / class条目仅对快速识别总线有用。

**特定于板的初始化代码如何声明SPI设备？**

Linux需要多种信息来正确配置SPI设备。该信息通常由特定于电路板的代码提供，即使对于确实支持某些自动发现/枚举的芯片也是如此。

声明控制器

第一种信息是存在哪些SPI控制器的列表。对于基于片上系统（SOC）的板，这些板通常将是平台设备，并且控制器可能需要一些platform_data才能正常运行。 “ struct platform_device”将包括资源，例如控制器的第一个寄存器的物理地址及其IRQ。

平台通常会抽象化“注册SPI控制器”操作，也许将其与代码耦合以初始化引脚配置，以便多个板的arch /.../ mach-* / board-*。c文件都可以共享相同的基本控制器设置代码。这是因为大多数SOC都有几个具有SPI功能的控制器，并且通常只应设置并注册在给定板上实际可用的控制器。

因此，例如arch /.../ mach-* / board-*。c文件可能具有如下代码：

```c
	#include <mach/spi.h>	/* for mysoc_spi_data */

	/* if your mach-* infrastructure doesn't support kernels that can
	 * run on multiple boards, pdata wouldn't benefit from "__init".
	 */
	static struct mysoc_spi_data __initdata pdata = { ... };

	static __init board_init(void)
	{
		...
		/* this board only uses SPI controller #2 */
		mysoc_register_spi(2, &pdata);
		...
	}
```

SOC专用实用程序代码可能类似于：

```c
	#include <mach/spi.h>

	static struct platform_device spi2 = { ... };

	void mysoc_register_spi(unsigned n, struct mysoc_spi_data *pdata)
	{
		struct mysoc_spi_data *pdata2;

		pdata2 = kmalloc(sizeof *pdata2, GFP_KERNEL);
		*pdata2 = pdata;
		...
		if (n == 2) {
			spi2->dev.platform_data = pdata2;
			register_platform_device(&spi2);

			/* also: set up pin modes so the spi2 signals are
			 * visible on the relevant pins ... bootloaders on
			 * production boards may already have done this, but
			 * developer boards will often need Linux to do it.
			 */
		}
		...
	}
```

请注意，即使使用相同的SOC控制器，电路板的platform_data也可能有所不同。 例如，在一块板上SPI可能使用外部时钟，而另一块板上的SPI时钟则是从某个主时钟的当前设置得出的。

声明从设备

第二类信息是目标板上存在哪些SPI从设备的列表，通常包含驱动程序正确工作所需的一些特定于板的数据。

通常，您的arch /.../ mach-* / board-*。c文件会提供一张小表，列出每块板上的SPI设备。 （这通常只是一小部分。）可能看起来像：

```c
	static struct ads7846_platform_data ads_info = {
		.vref_delay_usecs	= 100,
		.x_plate_ohms		= 580,
		.y_plate_ohms		= 410,
	};

	static struct spi_board_info spi_board_info[] __initdata = {
	{
		.modalias	= "ads7846",
		.platform_data	= &ads_info,
		.mode		= SPI_MODE_0,
		.irq		= GPIO_IRQ(31),
		.max_speed_hz	= 120000 /* max sample rate at 3V */ * 16,
		.bus_num	= 1,
		.chip_select	= 0,
	},
	};
```

同样，请注意如何提供特定于董事会的信息；每个芯片可能需要几种类型。此示例显示了通用约束，例如允许的最快SPI时钟（在这种情况下，取决于电路板电压）或IRQ引脚的接线方式，以及特定于芯片的约束，例如重要的延迟（由一个引脚上的电容改变）。

（还有“ controller_data”，这些信息可能对控制器驱动程序有用。一个示例是特定于外设的DMA调整数据或chipselect回调。稍后将其存储在spi_device中。）

board_info应该提供足够的信息，以使系统在不加载芯片驱动程序的情况下工作。其中最麻烦的方面可能是spi_device.mode字段中的SPI_CS_HIGH位，因为只有在基础架构知道如何取消选择它之后，才能与解释chipselect“向后”的设备共享总线。

然后，您的电路板初始化代码将在SPI基础结构中注册该表，以便稍后注册SPI主控制器驱动程序时可以使用该表：

```c
spi_register_board_info(spi_board_info, ARRAY_SIZE(spi_board_info));
```

与其他静态特定于电路板的设置一样，您也不会取消注册。

广泛使用的“卡”式计算机将内存，CPU和其他东西捆绑到可能只有30平方厘米的卡上。在这样的系统上，arch/.../mach-.../board-*.c 文件将主要提供有关插入该卡的主板上设备的信息。这当然包括通过卡连接器连接的SPI设备！


非静态配置

开发板通常采用与产品板不同的规则，其中一个示例是可能需要热插拔SPI设备和/或控制器。

对于这些情况，您可能需要使用 spi_busnum_to_master() 查找spi总线主控器，并且可能需要 spi_new_device() 提供基于热插拔板的板信息。当然，删除该板后，您至少要调用 spi_unregister_device()。

当Linux通过SPI支持 MMC/SD/SDIO/DataFlash 卡时，这些配置也将是动态的。幸运的是，此类设备均支持基本的设备标识探针，因此它们应正常热插拔。



**如何编写“ SPI协议驱动程序”？**

当前大多数SPI驱动程序都是内核驱动程序，但也支持用户空间驱动程序。 在这里，我们仅讨论内核驱动程序。

SPI协议驱动程序有点类似于平台设备驱动程序：

```c
	static struct spi_driver CHIP_driver = {
		.driver = {
			.name		= "CHIP",
			.owner		= THIS_MODULE,
		},

		.probe		= CHIP_probe,
		.remove		= __devexit_p(CHIP_remove),
		.suspend	= CHIP_suspend,
		.resume		= CHIP_resume,
	};
```

驱动程序内核将自动尝试将此驱动程序绑定到 board_info 给出了“ CHIP”修饰符的任何 SPI 设备。 除非您要创建用于管理总线的设备（显示在 /sys/class/spi_master ），否则您的 probe() 代码可能看起来像这样:

```c
	static int __devinit CHIP_probe(struct spi_device *spi)
	{
		struct CHIP			*chip;
		struct CHIP_platform_data	*pdata;

		/* assuming the driver requires board-specific data: */
		pdata = &spi->dev.platform_data;
		if (!pdata)
			return -ENODEV;

		/* get memory for driver's per-chip state */
		chip = kzalloc(sizeof *chip, GFP_KERNEL);
		if (!chip)
			return -ENOMEM;
		spi_set_drvdata(spi, chip);

		... etc
		return 0;
	}

```

一旦进入probe（），驱动程序就可以使用“ struct spi_message”向SPI设备发出I / O请求。当remove（）返回时，或probe（）失败后，驱动程序将保证不再提交任何此类消息。

  -spi_message是协议操作的序列，作为一个原子序列执行。 SPI驱动程序控件包括：

+双向读写开始时...根据其spi_transfer请求顺序的排列方式；

  +使用了哪个I / O缓冲区...每个spi_transfer都为每个传输方向包装一个缓冲区，支持全双工（两个指针，两种情况下可能相同）和半双工（一个指针为NULL）传输；

  +（可选）使用spi_transfer.delay_usecs设置定义传输后的短延迟（如果缓冲区长度为零，则此延迟可能是唯一的协议效果）；

  +芯片选择是否在传输后和任何延迟后变为无效...通过使用spi_transfer.cs_change标志；

  +使用该原子组中最后一次传输的spi_transfer.cs_change标志提示下一条消息是否可能发送至同一设备...并可能节省芯片取消选择和选择操作的成本。

  -遵循标准的内核规则，并在您的消息中提供DMA安全的缓冲区。这样，除非硬件要求，否则使用DMA的控制器驱动程序不会被迫制作额外的副本（例如，解决硬件勘误表并强制使用反弹缓冲）。

如果对这些缓冲区的标准dma_map_single（）处理不合适，则可以使用spi_message.is_dma_mapped告诉控制器驱动程序您已经提供了相关的DMA地址。

  -基本的I / O原语是spi_async（）。可以在任何上下文（irq处理程序，任务等）中发出异步请求，并使用消息附带的回调报告完成情况。检测到任何错误后，将取消选择芯片并中止对该spi_message的处理。

  -也有类似spi_sync（）的同步包装，以及spi_read（），spi_write（）和spi_write_then_read（）的包装。这些可能仅在可能会休眠的上下文中发出，并且它们在spi_async（）上都是干净的（并且很小，并且是“可选的”）层。

  -spi_write_then_read（）调用及其周围的便利包装仅应用于少量数据，而多余副本的成本可以忽略。它旨在支持常见的RPC样式的请求，例如编写8位命令和读取16位响应-spi_w8r16（）是其包装程序之一，正是这样做的。

某些驱动程序可能需要修改spi_device特性，例如传输模式，字大小或时钟速率。这是通过spi_setup（）完成的，通常在对设备执行第一个I / O之前从probe（）调用它。但是，也可以在没有消息等待该设备挂起的任何时候调用它。

尽管“ spi_device”将是驱动程序的底部边界，但顶部边界可能包括sysfs（尤其是用于传感器读数），输入层，ALSA，网络，MTD，字符设备框架或其他Linux子系统。

请注意，驱动程序在与SPI设备交互时必须管理两种类型的内存。

  -I / O缓冲区使用通常的Linux规则，并且必须是DMA安全的。通常，您可以从堆或空闲页面池中分配它们。不要使用堆栈或任何声明为“静态”的东西。

  -用于将这些I / O缓冲区粘贴到一组协议事务中的spi_message和spi_transfer元数据。这些可以在任何方便的地方进行分配，包括作为其他“一次分配驱动程序”数据结构的一部分。零初始化这些。

如果愿意，可以使用spi_message_alloc（）和spi_message_free（）便利例程通过几次传输来分配spi_message并将其初始化为零。

**如何编写“ SPI主控制器驱动程序”？**

SPI控制器可能会在platform_bus上注册； 编写驱动程序以绑定到设备，无论涉及哪个总线。

这种类型的驱动程序的主要任务是提供一个“ spi_master”。 使用spi_alloc_master（）分配主机，并使用spi_master_get_devdata（）获取为该设备分配的驱动程序专用数据。

```c
	struct spi_master	*master;
	struct CONTROLLER	*c;

	master = spi_alloc_master(dev, sizeof *c);
	if (!master)
		return -ENODEV;

	c = spi_master_get_devdata(master);
```

驱动程序将初始化该spi_master的字段，包括总线号（可能与平台设备ID相同）以及用于与SPI内核和SPI协议驱动程序进行交互的三种方法。 它还将初始化自己的内部状态。 （有关总线编号和这些方法，请参见下文。）

初始化spi_master后，请使用spi_register_master（）将其发布到系统的其余部分。 届时，控制器和任何预先声明的spi设备的设备节点将变为可用，并且驱动程序模型核心将负责将其绑定到驱动程序。

如果需要删除SPI控制器驱动程序，则spi_unregister_master（）将反转spi_register_master（）的作用。

总线编号

总线编号很重要，因为这就是Linux识别给定SPI总线（共享的SCK，MOSI，MISO）的方式。 有效的总线号从零开始。 在SOC系统上，总线编号应与芯片制造商定义的编号匹配。 例如，硬件控制器SPI2的总线号为2，与其连接的设备的spi_board_info将使用该号。

如果您没有此类硬件分配的总线号，并且由于某种原因不能直接分配它们，请提供一个负的总线号。 然后，将替换为动态分配的号码。 然后，您需要将其视为非静态配置（请参见上文）。

SPI主方法

```c
master->setup(struct spi_device *spi)
```

这将设置设备时钟速率，SPI模式和字长。驱动程序可以更改board_info提供的默认值，然后调用spi_setup（spi）来调用此例程。它可能会睡觉。

除非每个SPI从设备都有自己的配置寄存器，否则不要立即更改它们...否则驱动程序可能会破坏其他SPI设备正在进行的I / O。

**错误警告：出于某些原因，许多spi_master驱动程序的第一个版本似乎都出错了。对setup（）进行编码时，ASSUME表示控制器正在积极处理另一设备的传输。

```c
master->transfer(struct spi_device *spi, struct spi_message *message)
```

这一定不能睡觉。它的责任是安排传输发生并发出complete（）回调。两者通常会在其他传输完成后再发生，如果控制器空闲，则需要启动它。

```c
master->cleanup(struct spi_device *spi)
```

您的控制器驱动程序可以使用 spi_device.controller_state 保持与该设备动态关联的状态。如果这样做，请确保提供cleanup（）方法以释放该状态。

SPI消息队列

驱动程序的大部分将管理由transfer（）提供的I / O队列。

该队列可能纯粹是概念上的。 例如，使用同步PIO，仅用于低频传感器访问的驱动程序可能会很好。

但是使用message-> queue，PIO，通常是DMA（尤其是如果根文件系统在SPI flash中）以及执行上下文（例如IRQ处理程序，tasklet或工作队列（例如keventd）），队列可能会非常真实。 您的驱动程序可以根据您的需要而不同。 这样的transfer（）方法通常只会将消息添加到队列中，然后启动一些异步传输引擎（除非它已经在运行）。