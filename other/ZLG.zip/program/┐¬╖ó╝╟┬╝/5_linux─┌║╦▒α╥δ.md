# Linux 内核编译

准备：

将 uboot 目录下的 mkimage 文件拷贝到 /usr/bin/目录下，主要用于生成的 zImage转化为uboot 可以引导的 uImage 文件。可以自行转换，但zlg的编译脚本已经有这个步骤，为防止出错，还是先执行此操作。



编译内核：

>  这里用的内核为： linux-2.6.35.3-v1.13.tar.bz2 ，解压到自己指定的目录。

1. 生成配置文件：```./config-kernel```  选择 EasyARM-i.MX287A
2. 编译：```make uImage``` 即会在 ```./arch/arm/boot``` 目录下生成需要的 uImage。



将生成的 uImage 复制到 之前准备的 tftp 传输目录 ```/tftpboot```. 在开发板启动会即会自动下载内核，并解压运行。