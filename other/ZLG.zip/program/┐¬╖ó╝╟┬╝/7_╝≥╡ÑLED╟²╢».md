# LED 驱动

ioctl 系统调用主要用于增加系统调用的硬件控制能力，它可以构建自己的命令，也能接受参数。通过 ioctl 控制硬件 I/O ，必须在驱动中为 ioctl() 系 统调用设计一些控制命令，通过不同的命令实现不同的硬件控制。

ioctl 操作与硬件平台相关，使用 ioctl 的驱动需要包含 <linux/ioctl.h> 文件。然而实际上，这个文件却只是包含了一个与硬件平台相关的 <asm/ioctl.h> 文件，对于 ARM 处理 器，使用通用的 ioctl ，最终使用 <asm generic/ioctl.h> 。

| 字段 | 31~30                                                        | 29~16    | 15~8                                        | 7~0                      |
| :--- | ------------------------------------------------------------ | -------- | ------------------------------------------- | ------------------------ |
| 含义 | 00 没有参数：\_IO<br/>01 写：\_IOW<br/>10 读：\_IOR<br/>11 读写：\_IOWR | 参数长度 | 驱动的幻数，常用ASCII字符表示，用于标识驱动 | 功能号，用于区分命令功能 |

**构造 ioctl 命令**

为驱动构造 ioctl 命令，首先要为驱动选择一个可用的幻数作为驱动的特征码，以区分不同驱动的命令。内核已经使用了很多幻数，为了防止冲突，最好不要再使用这些系统已经占用的幻数来作为驱动的特征码。已经被使用的幻数列表详见 Documentation/ioctl/ioctl number.txt 文件。在不同平台上，幻数所使用情况都不同，为防止冲突，可以选择其它平台使用的幻数来用。
选定幻数后，可以这样来进行定义：```#define LED_IOC_MAGIC Z```
ioctl 命令字段的 b i t[31:30] 表示命令的方向，分别表示使用 _IO 、 _IO W 、 _IOR 和 _IOWR
这几个宏定义，分别用于构造不同的命令：

* _IO( type, nr) 	    构造无参数的命令编号
* \_IOW( nr, size)      构造往驱动写入数据的命令编号
* \_IOR( nr, size)       构造从驱动中读取数据的命令编号
* \_IOWR( nr, size)    构造双向传输的命令编号

这些宏定义中， type 是幻数， nr 是功能号， size 是数据大小。
例如，为 LED 驱动构造 ioctl 命令，由于控制 LED 无需数据传输，可以这样定义：

```c
#define SET_LED_ON _IO(LED_IOC_MAGIC, 0)
#define SET_LED_OFF _IO(LED_IOC_MAGIC, 1)
```

如果想在 ioctl 中往驱动写入一个 int 型的数据，可以这样定义：

```c
#define CHAR_WRITE_DATA _IOW(CHAR_IOC_MAGIC, 2, int)
```

类似 的，要从驱动中读取 int 型的数据，则定义为：

```c
#define CHAR_READ_DATA _IOR(CHAR_IOC_MAGIC, 3, int)
```

> 注意：同一份驱动的 ioctl 命令定义，无论有无数据传输以及数据传输方向是否相同，各命令的序号都不能相同。

定义完所需的全部命令后，还需定义一个命令的最大的编号，防止传入参数超过编号范围。

 **解析 ioctl 命令**
驱动程序必须对传入的命令进行解析，包括传输方向、命令类型、命令编号以及参数大
小，分别可以通过下面的宏定义完成：

* \_IOC_DIR(nr)				解析命令的传输方向
* \_IOC_TYPE(nr) 			解析命令类型
* \_IOC_NR(nr) 				解析命令序号
* \_IOC_SIZE(nr ) 			解析参数大小

如果解析发现命令出错，可以返回 ENOTTY ，如

```c
if (_IOC_TYPE(cmd) != LED_IOC_MAGIC) {
	return ENOTTY;
}
if (_IOC_NR(cmd) >= LED_IOC_MAXNR) {
	return ENOTTY;
}
```

内核空间的 ioctl 函数：

```c
int (*ioctl) (struct inode *inode, struct file *fi lp , unsigned int cmd, unsigned long arg)
```

用户空间的 ioctl 函数：

```c
int ioctl (int fd, unsigned long cmd, ...)
```

代码

```c
//led_drv.h
#ifndef _LED_DRV_H
#define _LED_DRV_H

#define LED_IOC_MAGIC 'L'
#define LED_ON	_IO(LED_IOC_MAGIC, 0)
#define LED_OFF	_IO(LED_IOC_MAGIC, 1)

#define LED_IOCTL_MAXNR	2

#endif
```

```c
//led_drv.c
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/version.h>

#include <asm/mach/arch.h>
#include <mach/hardware.h>
#include <mach/gpio.h>
#include <asm/gpio.h>

#include "led_drv.h"

static int major;
static int minor;
struct cdev *led;
static dev_t devno;
static struct class *led_class;

#define DEVICE_NAME	"led"

#define GPIO_LED_PIN_NUM	55

static int led_open(struct inode *inode, struct file *file)
{
	try_module_get(THIS_MODULE);
	gpio_direction_output(GPIO_LED_PIN_NUM, 1);
	return 0;
}

static int led_release(struct inode *inode, struct file *file)
{
	module_put(THIS_MODULE);
	gpio_direction_output(GPIO_LED_PIN_NUM, 1);
	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36)
int led_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
#else
static int led_ioctl(struct inode *inode, struct file *file, unsigned int cmd, unsigned long arg)
#endif
{
	if(_IOC_TYPE(cmd) != LED_IOC_MAGIC){
		return -ENOTTY;
	}
	if(_IOC_NR(cmd) > LED_IOCTL_MAXNR){
		return -ENOTTY;
	}
	switch(cmd){
	case LED_ON:
		gpio_set_value(GPIO_LED_PIN_NUM, 0);
		break;
	case LED_OFF:
		gpio_set_value(GPIO_LED_PIN_NUM, 1);
		break;
	default :
		gpio_set_value(27, 0);
		break;
	}
	return 0;
}

struct file_operations led_fops = {
	.owner = THIS_MODULE,
	.open = led_open,
	.release = led_release,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36)
	.unlocked_ioctl = led_ioctl,
#else
	.ioctl = led_ioctl,
#endif
};



static int __init led_init(void)
{
	int ret;

	gpio_free(GPIO_LED_PIN_NUM);
	if(gpio_request(GPIO_LED_PIN_NUM, "led_run")){
		printk("request %s gpio fail\n", "led_run");
		return -1;
	}
	
	ret = alloc_chrdev_region(&devno, minor, 1, "led");
	major = MAJOR(devno);
	if(ret < 0){
		printk(KERN_ERR "cannot get major %d\n", major);
		return -1;
	}

	led = cdev_alloc();
	if(led != NULL){
		cdev_init(led, &led_fops);
		led->owner = THIS_MODULE;
		if(cdev_add(led, devno, 1) != 0){
			printk(KERN_ERR "add cdev error\n");
			goto error;
		}
	}else{
		printk(KERN_ERR "cdev_alloc error!\n");
		return -1;
	}

	led_class = class_create(THIS_MODULE, "led_class");
	if(IS_ERR(led_class)){
		printk(KERN_INFO "create class error\n");
		return -1;
	}

	device_create(led_class, NULL, devno, NULL, "led");
	return 0;

error:
	unregister_chrdev_region(devno, 1);
	return ret;
}

static void __exit led_exit(void)
{
	cdev_del(led);
	unregister_chrdev_region(devno, 1);
	device_destroy(led_class, devno);
	class_destroy(led_class);
}

module_init(led_init);
module_exit(led_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Haha");
```

```c
//led_test.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <errno.h>

#include "led_drv.h"

#define DEV_NAME	"/dev/led"

int main(int argc, char *argv[])
{
	int i;
	int fd = 0;
	fd = open(DEV_NAME, O_RDONLY);
	if(fd < 0)
	{
		perror("Open fail\n");
		exit(1);
	}
	
	while(1)
	{
		ioctl(fd, LED_ON);
		sleep(1);
		ioctl(fd, LED_OFF);
		sleep(1);
	}

	close(fd);
	return 0;
}
```



