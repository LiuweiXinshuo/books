# SPI 子系统

数据结构

```c
//include/linux/spi/spi.h
//SPI从设备的主端代理
struct spi_device {
	struct device		dev;			//设备的驱动程序模型表示。基类
	struct spi_master	*master;		//设备使用的SPI控制器。
	u32			max_speed_hz;			//该芯片（在该板上）要使用的最大时钟速率，
	u8			chip_select;			//Chipselect，区分@master处理的芯片。
	u8			mode;					//spi模式定义了如何时钟输出和输入数据。
#define	SPI_CPHA	0x01			/* clock phase */
#define	SPI_CPOL	0x02			/* clock polarity */
#define	SPI_MODE_0	(0|0)			/* (original MicroWire) */
#define	SPI_MODE_1	(0|SPI_CPHA)
#define	SPI_MODE_2	(SPI_CPOL|0)
#define	SPI_MODE_3	(SPI_CPOL|SPI_CPHA)
#define	SPI_CS_HIGH	0x04			/* chipselect active high? */
#define	SPI_LSB_FIRST	0x08			/* per-word bits-on-wire */
#define	SPI_3WIRE	0x10			/* SI/SO signals shared */
#define	SPI_LOOP	0x20			/* loopback mode */
#define	SPI_NO_CS	0x40			/* 1 dev/bus, no chipselect */
#define	SPI_READY	0x80			/* slave pulls low to pause */
	u8			bits_per_word;		//数据传输涉及一个或多个字节
	int			irq;				//传递给request_irq() 以接收来自此设备的中断的数字。
	void			*controller_state;	//控制器的运行状态
	void			*controller_data;	//特定于板的控制器定义
	char			modalias[SPI_NAME_SIZE];		//该设备要使用的驱动程序名称，或该名称的别名。 这显示在用于驱动程序冷插的sysfs“ modalias”属性中，以及用于热插拔的uevents中

	/*
	 * likely need more hooks for more protocol options affecting how
	 * the controller talks to each chip, like:
	 *  - memory packing (12 bit samples into low bits, others zeroed)
	 *  - priority
	 *  - drop chipselect after each word
	 *  - chipselect delays
	 *  - ...
	 */
};
/*@spi_device用于在SPI从设备（通常是分立芯片）和CPU存储器之间交换数据。
  在@dev中，platform_data用于保存有关该设备的信息，该信息对设备的协议驱动程序有意义，但对它的控制器没有意义。 一个示例可能是功能稍有不同的芯片变体的标识符。 另一个可能是有关该特定板如何连接芯片引脚的信息。*/
```



```c
//include/linux/spi/spi.h
//主机端“协议”驱动程序
struct spi_driver {
	const struct spi_device_id *id_table;		//该驱动程序支持的SPI设备列表
	int			(*probe)(struct spi_device *spi);		//将此驱动程序绑定到spi设备。
	int			(*remove)(struct spi_device *spi);		//将此驱动程序与spi设备解除绑定
	void			(*shutdown)(struct spi_device *spi);	//在系统状态转换期间使用的标准关闭回调，例如powerdown/halt和kexec
	int			(*suspend)(struct spi_device *spi, pm_message_t mesg);	//系统状态转换期间使用的标准暂停回调
	int			(*resume)(struct spi_device *spi);	//系统状态转换期间使用的标准恢复回调
	struct device_driver	driver;	//SPI设备驱动程序应初始化此结构的名称和所有者字段。
};
```

