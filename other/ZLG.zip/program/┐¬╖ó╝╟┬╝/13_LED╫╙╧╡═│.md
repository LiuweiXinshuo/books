# LED 子系统

LED 子系统的可以分为三部分：触发器、LED 设备和核心模块，如下图：

<img src="./images/13_1.png" alt="image" style="zoom:67%;" />



亮度指示数据：

```c
//linux/leds.h
enum led_brightness {
	LED_OFF		= 0,			//灭
	LED_HALF	= 127,			//中亮
	LED_FULL	= 255,			//最亮
};
```



```c
//linux/leds.h
struct led_classdev {
	const char		*name;				//led的名字
	int			 brightness;			//led的亮度
	int			 max_brightness;		//led的最大亮度
	int			 flags;

	/* Lower 16 bits reflect status */
#define LED_SUSPENDED		(1 << 0)
	/* Upper 16 bits reflect control information */
#define LED_CORE_SUSPENDRESUME	(1 << 16)

	/* 设置led亮度等级 */
	/* 不可以休眠如有需要请用workqueue */
	void		(*brightness_set)(struct led_classdev *led_cdev,
					  enum led_brightness brightness);
	/* 获取LED亮度等级 */
	enum led_brightness (*brightness_get)(struct led_classdev *led_cdev);

	/* Activate hardware accelerated blink, delays are in
	 * miliseconds and if none is provided then a sensible default
	 * should be chosen. The call can adjust the timings if it can't
	 * match the values specified exactly. */
	int		(*blink_set)(struct led_classdev *led_cdev,
				     unsigned long *delay_on,
				     unsigned long *delay_off);				//设置闪烁时亮灭的时间

	struct device		*dev;
	struct list_head	 node;			/* LED Device list */
	const char		*default_trigger;	/* Trigger to use */

#ifdef CONFIG_LEDS_TRIGGERS
	/* Protects the trigger data below */
	struct rw_semaphore	 trigger_lock;			//trigger的锁

	struct led_trigger	*trigger;				//led的trigger对象
	struct list_head	 trig_list;				//trigger链表
	void			*trigger_data;				//trigger的数据
#endif
};
```



简单的 LED子系统 驱动

```c
#include <linux/module.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/leds.h>

#include <mach/pinctrl.h>
#include <mach/hardware.h>
#include <mach/device.h>
#include <mach/regs-pwm.h>

//#define LED_GPIO	MXS_PIN_ENCODE(1, 23)
#define LED_GPIO	55

static void mxs_led_brightness_set(struct led_classdev *pled, enum led_brightness value)
{
	gpio_direction_output(LED_GPIO, !value);
}

struct led_classdev led_dev = {
	.name = "led-example",
	.flags = 0,
	.brightness_set = mxs_led_brightness_set,
	.default_trigger = "none",
};

static int __init led_init(void)
{
	int ret = 0;
	ret = led_classdev_register(NULL, &led_dev);
	if(ret)
	{
		printk("register led device failed\n");
		return -1;
	}

	gpio_request(LED_GPIO, "led");
	return 0;
}

static void __exit led_exit(void)
{
	led_classdev_unregister(&led_dev);
	gpio_free(LED_GPIO);
}

module_init(led_init);
module_exit(led_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("LW");

```

