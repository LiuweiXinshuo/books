# UBOOT编译

uboot源码：【bootloader-v1.13.tar.bz2  -> u-boot-2009.08】

| 目  录  | 说  明                                                       |
| ------- | :----------------------------------------------------------- |
| board   | 存放了U-Boot所支持开发板的相关代码，目前支持几十个不同体系架构的开发板，如evb4510、pxa255_idp、omap2420h4等 |
| common  | U-Boot命令实现代码目录                                       |
| cpu     | 包含了不同处理器相关的代码，按照不同的处理器进行分类，如arm920t、arm926ejs、i386、nios2等 |
| drivers | U-Boot所支持外设的驱动程序。按照不同类型驱动进行分类如spi、mtd、net等等 |
| fs      | U-Boot所支持的文件系统的代码。目前U-Boot支持cramfs、ext2、fat、fdos、jffs2、reiserfs |
| include | U-Boot头文件目录，里面还包含各种不同处理器的相关头文件，以asm-体系架构这样的目录出现。另外，不同开发板的配置文件也在这个目录下：include/configs/开发板.h |
| lib_xxx | 不同体系架构的一些库文件目录                                 |
| net     | U-Boot所支持网络协议相关代码，如bootp、nfs等                 |
| tools   | U-Boot工具源代码目录。其中的一些小工具如mkimage就非常实用    |



编译

1. 清除之前编译： ```make ARCH=arm CROSS_COMPILE=arm-fsl-linux-gnueabi- distclean```。
2. 生成配置文件：```make ARCH=arm CROSS_COMPILE=arm-fsl-linux-gnueabi- mx28_evk_config``` 。
3. 编译代码：```make ARCH=arm CROSS_COMPILE=arm-fsl-linux-gnueabi-``` 。
4.  生成 uboot、uboot.bin、uboot.lds、 uboot.map 等文件。



> 目前烧录 uboot 一直没成功，就先用的官方的 uboot。



此处使用 tftp下载内核 + nfs 加载网络文件系统 模式。好调试。

进入uboot，参数配置如下：

```
baudrate=115200
netmask=255.255.255.0
bootfile="uImage"
loadaddr=0x42000000
kernel=uImage
kernelsize=0x400000
showbitmap=0
kerneladdr=0x00200000
kerneladdr2=0x00780000
ds2460_mac=00:04:00:00:00:00
nfsroot=/nfsroot/rootfs
bootargs_nfs=setenv bootargs gpmi=g root=/dev/nfs rw console=ttyAM0,115200n8 nfsroot=$(serverip):$(nfsroot) ip=$(ipaddr):$(serverip):$(gatewayip):$(netmask):epc.zlgmcu.com:eth0:down
bootcmd_net=run bootargs_nfs;
bootcmd_mmc=run bootargs_mmc; mmc read 0 ${loadaddr} 100 3000; bootm
bootargs_nand=setenv bootargs gpmi=g console=ttyAM0,115200n8 ubi.mtd=5 root=ubi0:rootfs rootfstype=ubifs ro
bootargs_mmc=gpmi=g console=ttyAM0,115200n8 console=tty0 root=/dev/mmcblk0p3 rw
upuboot=tftp $(loadaddr) $(serverip):imx28_ivt_uboot.sb;nand erase 0x0 0x100000; nand write $(loadaddr) 0x0 0x100000
upkernel=tftp $(loadaddr) $(serverip):$(kernel);nand erase  $(kerneladdr) $(kernelsize);nand write $(loadaddr) $(kerneladdr) $(filesize);
upkernel2=nand erase $(kerneladdr2) $(kernelsize);nand write $(loadaddr) $(kerneladdr2) $(filesize)
uprootfs=mtdparts default;nand erase rootfs;ubi part rootfs;ubi create  rootfs;tftp $(loadaddr) $(rootfs);ubi write $(loadaddr) rootfs $(filesize)
sd_upkernel=mmc read 0 0x42000000 1 1; fatload mmc 0:1 42000000 uImage;nand erase  $(kerneladdr) $(kernelsize);nand write $(loadaddr) $(kerneladdr) $(filesize);
sd_upkernel2=nand erase $(kerneladdr2) $(kernelsize);nand write $(loadaddr) $(kerneladdr2) $(filesize)
sd_uprootfs=mtdparts default;nand erase rootfs;ubi part rootfs;ubi create  rootfs;mmc read 0 0x42000000 1 1; fatload mmc 0:1 42000000 rootfs.ubifs;ubi write $(loadaddr) rootfs $(filesize)
tftp_boot=tftp $(loadaddr) $(serverip):uImage; bootm;
nand_boot=nand read.jffs2 $(loadaddr) $(kerneladdr) $(kernelsize);bootm $(loadaddr);nand read.jffs2 $(loadaddr) $(kerneladdr2) $(kernelsize);bootm $(loadaddr)
setnandboot=setenv bootcmd 'run  nand_boot';saveenv 
settftpboot=setenv bootcmd 'run  tftp_boot';saveenv 
upsystem=run upkernel;run upkernel2;run uprootfs;reset 
sd_upsystem=run sd_upkernel;run sd_upkernel2;run sd_uprootfs;reset 
ethact=FEC0
bootdelay=3
ipaddr=10.88.133.16
serverip=10.88.133.100
gatewayip=10.88.133.254
bootcmd=run tftp_boot
bootargs=gpmi=g root=/dev/nfs rw console=ttyAM0,115200n8 nfsroot=10.88.133.100:/nfsroot/rootfs ip=10.88.133.16:10.88.133.100:10.88.133.254:255.255.255.0:epc.zlgmcu.com:eth0:up
rootfs=rootfs
mem=128M
stdin=serial
stdout=serial
stderr=serial
ver=U-Boot 2009.08 ( 5鏈13 2016 - 09:49:44)
```

