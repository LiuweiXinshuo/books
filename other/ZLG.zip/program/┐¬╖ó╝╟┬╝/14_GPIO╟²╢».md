# GPIO驱动

GPIOLIB 的接口十分简洁。在 GPIOLIB ，所有的 GPIO 都是用整形的 GPIO 编号标识。只要获得要操作 GPIO 的编号，就可以调用 GPIOLIB 提供的方法操作 GPIO 。

**GPIOLIB 内核操作接口**：【通用接口：include/asm-generic】

1. 申请获取 GPIO 接口

   ```c
   int gpio_request(unsigned gpio, const char *label);
   ```

   gpio : GPIO编号				label ：GPIO的标识字符串，可随意设定。

   返回值：成功 0； 失败 非0，可能时GPIO号不存在，或已被占用没有释放。

2. 释放 GPIO 接口

   ```c
   void gpio_free(unsigned gpio);
   ```

3. 设置 GPIO 传输方向为输出

   ```c
   int gpio_direction_output(unsigned gpio, int value);
   ```

   gpio ：GPIO编号				value：值，1为高电平；0为低电平

4. 设置 GPIO 输出电平

   ```c
   void gpio_set_value(unsigned gpio, int value);
   ```

   gpio ：GPIO编号				value：值，1为高电平；0为低电平

5. 设置 GPIO 传输方向为输入

   ```c
   int gpio_direction_input(unsigned gpio);
   ```

   gpio ：GPIO编号

6. 获取 GPIO 输入电平状态

   ```c
   int gpio_get_value(unsigned gpio);
   ```

   gpio ：GPIO编号

7. 获取中断号

   ```c
   int gpio_to_irq(unsigned gpio);			//不是所有端口都有中断号，因此不是强制实现
   ```

   返回： GPIO 中断号

8. 设置 GPIO 消抖时间，主要用于按键消抖

   ```c
   int gpio_set_debounce(unsigned gpio, unsigned debounce);
   ```

   gpio ：GPIO编号				debounce：时间



**GPIO 的实现：**

大部分的嵌入式处理器的GPIO 都是分组的。GPIOLIB 对系统的所有 GPIO 统一编号，而每组的 GPIO 编号都是连续的。GPIOLIB 对每组 GPIO 都用一个 gpio_chip 对象来实现其驱动。

```c
//GPIO 控制器
struct gpio_chip {
	const char		*label;
	struct device		*dev;
	struct module		*owner;			//成员拥有者，一般为THIS_MODULE

	int			(*request)(struct gpio_chip *chip, unsigned offset);
	void		(*free)(struct gpio_chip *chip, unsigned offset);
	int			(*direction_input)(struct gpio_chip *chip,unsigned offset);
	int			(*get)(struct gpio_chip *chip, unsigned offset);
	int			(*direction_output)(struct gpio_chip *chip, unsigned offset, int value);
	int			(*set_debounce)(struct gpio_chip *chip, unsigned offset, unsigned debounce);
	void			(*set)(struct gpio_chip *chip, unsigned offset, int value);

	int			(*to_irq)(struct gpio_chip *chip, unsigned offset);

	void			(*dbg_show)(struct seq_file *s, struct gpio_chip *chip);
	int			base;				//该组GPIO的起始值
	u16			ngpio;				//该组GPIO的数量
	const char		*const *names;	
	unsigned		can_sleep:1;
	unsigned		exported:1;
};
```

```c
//用于标记一个GPIO
struct gpio_desc {
	struct gpio_chip	*chip;
	unsigned long		flags;
/* flag symbols are bit numbers */
#define FLAG_REQUESTED	0
#define FLAG_IS_OUT	1
#define FLAG_RESERVED	2
#define FLAG_EXPORT	3	/* protected by sysfs_lock */
#define FLAG_SYSFS	4	/* exported via /sys/class/gpio/control */
#define FLAG_TRIG_FALL	5	/* trigger on falling edge */
#define FLAG_TRIG_RISE	6	/* trigger on rising edge */
#define FLAG_ACTIVE_LOW	7	/* sysfs value has active low */

#define PDESC_ID_SHIFT	16	/* add new flags before this one */

#define GPIO_FLAGS_MASK		((1 << PDESC_ID_SHIFT) - 1)
#define GPIO_TRIGGER_MASK	(BIT(FLAG_TRIG_FALL) | BIT(FLAG_TRIG_RISE))

#ifdef CONFIG_DEBUG_FS
	const char		*label;
#endif
};
```

当 GPIO 控制器初始化完成后，就可以调用 gpiochip_add() 函数注册到内核：

```c
int gpiochip_add(struct gpio_chip *chip);
```

在给一组 GPIO 安排编号时，注意不要和其它 GPIO 组的编号有重叠，否则会造成注册 GPIO 控制器的出错。

对于每种处理器平台，其最大 GPIO 编号值都由 MXS_ARCH_NR_GPIOS 宏设定的。对于 i.MX28 系列处理器 MXS_ARCH_NR_GPIOS 宏定义在 arch/arm/plat-mxs/include/mach/hardware.h 文件：

```c
#ifndef MXS_ARCH_NR_GPIOS
#define MXS_ARCH_NR_GPIOS	160
#endif
```

当需要把 GPIO 控制器从内核注销时，可以调用 gpiochip_remove() 函数：

```c
int __must_check gpiochip_remove(struct gpio_chip *chip);
```





_________

平台代码关联驱动：

```c
//arch/arm/mach-mx28/mx28evk.c
MACHINE_START(MX28EVK, "Freescale MX28EVK board")
	.phys_io	= 0x80000000,
	.io_pg_offst	= ((0xf0000000) >> 18) & 0xfffc,
	.boot_params	= 0x40000100,
	.fixup		= fixup_board,
	.map_io		= mx28_map_io,
	.init_irq	= mx28_irq_init,
	.init_machine	= mx28evk_init_machine,
	.timer		= &mx28_timer.timer,
MACHINE_ENDc

```

```c
//arch/arm/include/asm/mach/arch.h
//用于定义体系结构功能的宏集。 它由链接器构建到表中。
#define MACHINE_START(_type,_name)			\
static const struct machine_desc __mach_desc_##_type	\
 __used							\
 __attribute__((__section__(".arch.info.init"))) = {	\
	.nr		= MACH_TYPE_##_type,		\
	.name		= _name,

#define MACHINE_END				\
};
```

```c
struct machine_desc {
	/* 注意！ 前四个元素由head.S，head-common.S中的汇编代码使用*/
	unsigned int		nr;		/* 体系数量	*/
	unsigned int		phys_io;	/* 起始物理IO	*/
	unsigned int		io_pg_offst;	/* io页面tabe条目的字节偏移量	*/

	const char		*name;		/* 架构名称	*/
	unsigned long		boot_params;	/* 标记列表		*/

	unsigned int		video_start;	/* 显存起始地址	*/
	unsigned int		video_end;	/* 显存终止地址	*/

	unsigned int		reserve_lp0 :1;	/* never has lp0	*/
	unsigned int		reserve_lp1 :1;	/* never has lp1	*/
	unsigned int		reserve_lp2 :1;	/* never has lp2	*/
	unsigned int		soft_reboot :1;	/* soft reboot		*/
	void			(*fixup)(struct machine_desc *,
					 struct tag *, char **,
					 struct meminfo *);
	void			(*map_io)(void);/* IO mapping function	*/
	void			(*init_irq)(void);		/* 中断初始化指针 */
	struct sys_timer	*timer;		/* system tick timer	*/
	void			(*init_machine)(void);			/* 板级资源注册 */
};
```

```c
static void __init mx28evk_init_machine(void)
{
	mx28_pinctrl_init();		//
	/* Init iram allocate */
#ifdef CONFIG_VECTORS_PHY_ADDR
	/* reserve the first page for irq vector table*/
	iram_init(MX28_OCRAM_PHBASE + PAGE_SIZE, MX28_OCRAM_SIZE - PAGE_SIZE);
#else
	iram_init(MX28_OCRAM_PHBASE, MX28_OCRAM_SIZE);
#endif

	mx28_gpio_init();			//初始化GPIO
	mx28evk_pins_init();		
	mx28_device_init();
	mx28evk_device_init();
}
```



```c
//arch/arm/mach-mx28/gpio.c
int __init mx28_gpio_init(void)
{
	...
	for (i = 0; i < ARRAY_SIZE(mx28_gpios); i++) {
		void __iomem *base = PINCTRL_BASE_ADDR + 0x10 * i;
		if (!(reg & (BM_PINCTRL_CTRL_PRESENT0 << i)))
			continue;
		mxs_set_gpio_chip(&mx28_gpios[i], &mx28_gpio_chip);		//这里将操作函数绑定给对象
		mx28_gpios[i].id = i;
		__raw_writel(0, base + HW_PINCTRL_IRQEN0);
		__raw_writel(0xFFFFFFFF, base + HW_PINCTRL_PIN2IRQ0);
		mx28_gpios[i].child_irq = MXS_GPIO_IRQ_START +
		    (i * PINS_PER_BANK);
		mxs_add_gpio_port(&mx28_gpios[i]);
	}
	return 0;
}
```

```c
static struct mxs_gpio_chip mx28_gpio_chip = {
	.set_dir = mx28_gpio_direction,
	.get = mx28_gpio_get,
	.set = mx28_gpio_set,
	.get_irq_stat = mx28_gpio_irq_stat,
	.set_irq_type = mx28_gpio_set_irq_type,
	.unmask_irq = mx28_gpio_unmask_irq,
	.mask_irq = mx28_gpio_mask_irq,
	.ack_irq = mx28_gpio_ack_irq,
};
```

```c
struct mxs_gpio_chip {
	int (*set_dir) (struct mxs_gpio_port *, int, unsigned int);
	int (*get) (struct mxs_gpio_port *, int);
	void (*set) (struct mxs_gpio_port *, int, int);
	unsigned int (*get_irq_stat) (struct mxs_gpio_port *);
	int (*set_irq_type) (struct mxs_gpio_port *, int, unsigned int);
	void (*unmask_irq) (struct mxs_gpio_port *, int);
	void (*mask_irq) (struct mxs_gpio_port *, int);
	void (*ack_irq) (struct mxs_gpio_port *, int);
};
```

```c
//arch/arm/plat-mxs/gpio.c
int __init mxs_add_gpio_port(struct mxs_gpio_port *port)
{
	int i, ret;
	if (!(port && port->chip))
		return -EINVAL;

	if (mxs_valid_gpio(port))
		return -EINVAL;

	if (mxs_gpios[port->id])
		return -EBUSY;

	mxs_gpios[port->id] = port;

	port->port.base = port->id * PINS_PER_BANK;
	port->port.ngpio = PINS_PER_BANK;
	port->port.can_sleep = 1;
	port->port.exported = 1;
	port->port.to_irq = mxs_gpio_to_irq;
	port->port.direction_input = mxs_gpio_input;
	port->port.direction_output = mxs_gpio_output;
	port->port.get = mxs_gpio_get;
	port->port.set = mxs_gpio_set;
	port->port.request = mxs_gpio_request;
	port->port.free = mxs_gpio_free;
	port->port.owner = THIS_MODULE;
	ret = gpiochip_add(&port->port);			//这里将mxs的GPIO接口注册到内核
	if (ret < 0)
		return ret;

	if (port->child_irq < 0)
		return 0;

	for (i = 0; i < PINS_PER_BANK; i++) {
		gpio_irq_chip.mask(port->child_irq + i);
		set_irq_chip(port->child_irq + i, &gpio_irq_chip);
		set_irq_handler(port->child_irq + i, handle_level_irq);
		set_irq_flags(port->child_irq + i, IRQF_VALID);
	}
	set_irq_chained_handler(port->irq, mxs_gpio_irq_handler);
	set_irq_data(port->irq, port);
	return ret;
};
```

调用顺序

start_kernel()--->setup_arch()--->do_initcalls()--->customize_machine()--->mx28evk_init_machine()--->mx28_gpio_init()