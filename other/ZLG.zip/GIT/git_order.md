# GIT 命令汇总

```git init``` : 初始化 git 仓库

```git add <filename>``` : 添加文件到暂存区

```git rm --cache <filename>``` : 将暂存区的代码删除 

```git commit -m "infomation"``` : 将暂存区内容提交到版本库

```git status``` : 查看git仓库的状态

```git log``` : 查看git仓库提交日志

```git branch``` : 查看仓库分支

```git branch <branch-name>``` : 创建新本地分支

```git branch -m <new-branch-name>``` : 重命名本地分支

```git branch --merged``` : 查看已经合并的分支

```git checkout <branch-name>```: 切换到新分支

```git checkout -b <branch-name>``` : 创建并切换到新分支

```git merge <branch-name>``` : 合并分支，将 branch-name 的分支代码合并到当前分支

```git branch -d <branch-name>``` : 删除已经合并的分支

```git branch -D <branch-name>``` : 强制删除任意分支

``` git tag``` : 查看标签

```git tag <version-number>``` : 本地创建标签【最近一次提交】

```git tag -a <version-number> -m "infomation" <commit-id>``` : 为特定的某次提交打标签

```git push origin <local-version-numer> ``` : 推送某个标签到远程

```git push origin --tags``` : 一次性推送所有标签，同步到远程仓库

```git tag -d <tag-name>``` : 删除本地标签

``` git push origin :refs/tags/<tag-name>``` : 删除远程标签【前提是要先删除本地标签】

```git checkout .``` : 放弃工作区的所有修改

```git remote add origin ssh://xxxxxxxxx ``` : 关联远端仓库

```git push -u origin``` : 将本地仓库推送到远端

