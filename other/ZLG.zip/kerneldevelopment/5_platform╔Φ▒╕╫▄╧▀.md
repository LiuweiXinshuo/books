# Platform 设备总线

​	我们都知道即插即用的设备，插入后便立即由内核处理。它们可能是USB或PCI Express 或任何其他自动发现的设备。 但是，还存在其他设备类型，这些设备类型不可热插拔，并且内核在被管理之前需要了解。 有些I2C，UART，SPI和其他设备未连接到具有枚举功能的总线。

​	你可能已经知道一些真实的物理总线：USB，I2S，I2C，UART，SPI，PCI，SATA等。 这样的总线是称为控制器的硬件设备。 由于它们是SoC的一部分，因此无法将其删除，不可发现，也称为平台设备。

> 人们常说平台设备是片上设备（嵌入在SoC中）。 实际上，这是部分正确的，因为它们被硬连线到芯片中并且不能被移除。 但是连接到I2C或SPI的设备不在芯片上，并且由于无法发现而也属于平台设备。 同样，可能存在片上PCI或USB设备，但它们不是平台设备，因为它们是可发现的。

​	从SoC的角度来看，这些设备（总线）通过专用总线在内部进行连接，并且在大多数情况下是专有的，并且特定于制造商。 从内核的角度来看，这些是根设备，没有任何连接。 这就是伪平台总线的引入的原因。伪平台总线，也称为平台总线，是一种内核虚拟总线，用于不位于内核已知的物理总线上的设备。 在本章中，平台设备是指依赖伪平台总线的设备。

​	处理平台设备本质上需要两个步骤：

1. 注册用于管理您的设备的平台驱动程序（具有唯一的名称）
2. 使用与驱动程序相同的名称注册平台设备及其资源，以使内核知道您的设备在那里

话虽如此，在本章中，我们将讨论以下内容：

* 平台设备及其驱动程序
* 内核中的设备和驱动程序匹配机制
* 向设备注册平台驱动程序以及平台数据



#### 平台驱动

在继续之前，请注意以下警告：并非所有平台设备都由平台驱动程序处理（或者我应该说是伪平台驱动程序）。 平台驱动程序专用于不基于常规总线的设备。 I2C 设备或 SPI 设备是平台设备，但分别依赖于I2C 或 SPI 总线而不是平台总线。 一切都需要使用平台驱动程序手动完成。 平台驱动程序必须实现探测功能，该功能在插入模块或设备声明其功能时由内核调用。 在开发平台驱动程序时，必须填写的主要结构是 struct platform_driver，并且必须使用具有专用功能的平台总线核心注册驱动程序，如下所示：

```c
static struct platform_driver mypdrv = {
    .probe = my_pdrv_probe,
    .remove = my_pdrv_remove,
    .driver = {
    .name = "my_platform_driver",
    .owner = THIS_MODULE,
    },
};
```

让我们看看组成该结构的每个元素的含义以及它们的用途：

* probe()：这是设备在发生匹配后要求您的驱动程序时调用的函数。 稍后，我们将看到核心如何调用probe。 其声明如下：

```c
static int my_pdrv_probe(struct platform_device *pdev);
```

* remove() ：当设备不再需要该驱动程序时，调用此函数以卸载驱动程序，并且其声明如下所示：

```c
static int my_pdrv_remove(struct platform_device *pdev);
```

* struct device_driver：这描述了驱动程序本身，提供了一个名称，所有者和一些字段，我们将在后面看到。



在内核中注册平台驱动程序就像在 ```init``` 函数中调用 ```platform_driver_register()```或```platform_driver_probe() ```一样简单（加载模块时）。 这些功能之间的区别在于：

* ```platform_driver_register()``` 注册驱动程序并将其放入内核维护的驱动程序列表中，以便每当发生新匹配时就可以按需调用其 ```probe()``` 函数。 为了防止您的驱动程序已经被插入并注册到该列表中，只需使用 ```next``` 功能即可。

* 使用 ```platform_driver_probe() ```，内核会立即运行match循环，检查是否存在具有匹配名称的平台设备，然后在发生匹配时调用驱动程序的 ```probe()```，表示存在该设备。 如果不是，则忽略驱动程序。 由于此方法不会在系统上注册驱动程序，因此可以防止延迟探查。 此处，探测功能放置在```__init``` 节中，当内核启动完成时将释放该探测功能，从而避免了推迟探测并减少了驱动程序的内存占用。 如果您100％确定系统中存在该设备，请使用此方法：

  ```c
  ret = platform_driver_probe(&mypdrv, my_pdrv_probe);
  ```

  

以下是一个向内核注册自身的简单平台驱动程序：

```c
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/platform_device.h>

static int my_pdrv_probe(struct platform_device *pdev)
{
    pr_info("hello! device probed!\n");
	return 0;
}

static void my_pdrv_remove(struct platform_device *pdev)
{
	pr_info("good bye reader! \n");
}

static struct platform_driver mypdrv = {
	.probe = my_pdrv_probe,
	.remove = my_pdrv_remove,
	.driver = {
		.name = KBUILD_MODNAME,
		.owner = THIS_MODULE,
	},
};

static int __init my_pdrv_init(void)
{
    pr_info("Hello Guy\n");
    /* Registering with kernel */
	platfrom_driver_register(&mypdrv);
    return 0;
}

static void __exit my_pdrv_exit(void)
{
    pr_info("Good buy Guy\n");
    /* Unregistering from kernel */
	platform_driver_unregister(&mypdrv);
}

module_init(my_pdrv_init);
module_exit(my_pdrv_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("John Madieu");
MODULE_DESCRIPTION("My platform hello world module");
```

我们的模块在 ```init/exit``` 函数中不执行任何其他操作，而是向平台总线核心注册/注销。 大多数驱动程序就是这种情况。 在这种情况下，我们可以摆脱 ```module_init``` 和 ```module_exit``` ，而使用```module_platform_driver``` 宏。

module_platform_driver 宏如下所示：

```c
/*
* module_platform_driver() - Helper macro for drivers that don't
* do anything special in module init/exit. This eliminates a lot
* of boilerplate. Each module may only use this macro once, and
* calling it replaces module_init() and module_exit()
*/
#define module_platform_driver(__platform_driver) \
	module_driver(__platform_driver, platform_driver_register, \
	platform_driver_unregister)
```

该宏将负责向平台驱动程序内核注册我们的模块。 不再需要module_init和module_exit宏，也不需要init和exit函数。 这并不意味着不再调用这些函数，只是我们可以不编写它们。

> 探测功能不能替代初始功能。 每次给定设备与驱动程序匹配时，都会调用probe函数，而init函数仅在加载模块时运行一次。

```c
[...]
static int my_driver_probe (struct platform_device *pdev){
	[...]
}
static void my_driver_remove(struct platform_device *pdev){
	[...]
}
static struct platform_driver my_driver = {
	[...]
};
module_platform_driver(my_driver);
```



您需要向其注册驱动程序的每条总线都有特定的宏。 以下列表并不详尽：

* 用于平台驱动程序的 ```module_platform_driver(struct platform_driver)```，专用于不位于常规物理总线上的设备（我们之前使用过）
* 用于 SPI 驱动程序的 ```module_spi_driver(struct spi_driver)```
* 用于 I2C 驱动程序的 ```module_i2c_driver(struct i2c_driver)```
* 用于 PCI 驱动程序的 ```module_pci_driver(struct pci_driver)```
* 用于 USB 驱动程序的 ```module_usb_driver(struct usb_driver)```
* 用于 Mdio 的 ```module_mdio_driver(struct mdio_driver)```
* [...]

> 如果你不知道驱动程序需要注册到哪条总线上，那么它就是平台驱动程序，您应该使用platform_driver_register或platform_driver_probe来注册驱动程序。



#### 平台设备

实际上，我们应该称之为伪平台设备，因为本节涉及位于伪平台总线上的设备。 完成驱动程序后，你将必须向内核提供需要该驱动程序的设备。 平台设备在内核中表示为 struct platform_device 的实例，如下所示：

```c
struct platform_device {
    const char *name;
    u32 id;
    struct device dev;
    u32 num_resources;
    struct resource *resource;
};
```

对于平台驱动程序，在驱动程序和设备匹配之前，```struct platform_device``` 和 ```static struct platform_driver.driver.name``` 的名称字段必须相同。 下一部分将讨论 ```num_resources``` 和 ```struct resource * resource``` 字段。 请记住，由于资源是一个数组，因此 ```num_resources``` 必须包含该数组的大小。



#### 资源和平台数据

在可热插拔设备的另一端，内核不知道系统中存在哪些设备，它们有能力或需要什么才能正常工作。 由于没有自动协商过程，因此内核希望用户提供相关信息。 有两种方法可以将设备所需的资源（IRQ，DMA，内存区域，I/O端口，总线）和数据（您可能希望传递给驱动程序的任何自定义和私有数据结构）通知内核。 在这里讨论。

##### 设备配置–旧的和过时的方法
此方法将与不支持设备树的内核版本一起使用。 使用这种方法，驱动程序保持通用，并且设备在与板相关的源文件中注册。

**资源**
资源代表了从硬件角度表征设备的所有元素，并且设备需要正确设置才能正常工作。 内核中只有六种资源，所有资源都列在 ```include/linux/ioport.h``` 中，并用作描述资源类型的标志：

```c
    #define IORESOURCE_IO  0x00000100 /* PCI/ISA I/O ports */
    #define IORESOURCE_MEM 0x00000200 /* Memory regions */
    #define IORESOURCE_REG 0x00000300 /* Register offsets */
    #define IORESOURCE_IRQ 0x00000400 /* IRQ line */
    #define IORESOURCE_DMA 0x00000800 /* DMA channels */
    #define IORESOURCE_BUS 0x00001000 /* Bus */
```

资源在内核中表示为 ```struct resource``` 的实例：

```c
struct resource {
        resource_size_t start;
        resource_size_t end;
        const char *name;
        unsigned long flags;
    };
```

让我们解释一下结构中每个元素的含义：

* ```start/end```：这表示资源的开始/结束位置。 对于I/O或内存区域，它表示它们的开始/结束位置。 对于IRQ线路，总线或DMA通道，开始/结束必须具有相同的值。
* ```flags``` ：这是一个表征资源类型的掩码，例如IORESOURCE_BUS。
* ```name``` ：这标识或描述资源。

提供资源后，需要将它们提取回驱动程序以便使用。 探测功能是提取它们的好地方。 在继续之前，请记住平台设备驱动程序的probe函数的声明：

```c
	int probe(struct platform_device *pdev);
```

内核会自动使用先前注册的数据和资源填充 pdev。 让我们看看如何取出它们。

可以使用 ```platform_get_resource()``` 函数来检索 ```struct platform_device``` 中嵌入的 ```struct resource``` 。 以下是 platform_get_resource 的原型：

```c
struct resource *platform_get_resource(struct platform_device *dev,unsigned
int type, unsigned int num);
```

* 第一个参数是平台设备本身的实例。 
* 第二个参数表示我们需要哪种资源。 对于内存，它应该是IORESOURCE_MEM。 再次，请查看 ```include/linux/ioport.h``` 以获得更多详细信息。 
* num 参数是一个索引，表明需要哪种资源类型的第几个。 零表示第一个，依此类推。

如果资源是IRQ，则必须使用 ```int platform_get_irq(struct platform_device * pdev, unsigned int num)```，其中 ```pdev``` 是平台设备，```num``` 是资源中的 IRQ 索引（如果有多个）。 我们可以用来提取为设备注册的平台数据的整个探测功能如下所示：

```c
static int my_driver_probe(struct platform_device *pdev)
{
    struct my_gpios *my_gpio_pdata = (struct my_gpios*)dev_get_platdata(&pdev->dev);
    int rgpio = my_gpio_pdata->reset_gpio;
    int lgpio = my_gpio_pdata->led_gpio;
    
    struct resource *res1, *res2;
    void *reg1, *reg2;
    int irqnum;
    
    res1 = platform_get_resource(pdev, IORESSOURCE_MEM, 0);
    if((!res1)){
        pr_err(" First Resource not available");
        return -1;
    }
    res2 = platform_get_resource(pdev, IORESSOURCE_MEM, 1);
    if((!res2)){
        pr_err(" Second Resource not available");
        return -1;
    }
    
    /* extract the irq */
    irqnum = platform_get_irq(pdev, 0);
    pr_info("IRQ number of Device: %d\n", irqnum);
    /*
    * At this step, we can use gpio_request, on gpio,
    * request_irq on irqnum and ioremap() on reg1 and reg2.
    * ioremap() is discussed in chapter 11, Kernel Memory Management
    */
    [...]
    return 0;
}
```



**平台数据**
其他类型不属于上一节中列举的资源类型的数据（例如GPIO）也属于此。 无论它们是什么类型，```struct platform_device``` 都包含一个 ```struct device``` 字段，而该字段又包含一个 ```struct platform_data``` 字段。 通常，您应该将该数据嵌入结构中，然后将其传递到 ```platform_device.device.platform_data``` 字段。 举例来说，假设您声明一个平台设备，它需要两个 GPIO 号作为平台数据，一个 IRQ 号和两个内存区域作为资源。 以下示例显示如何将平台数据与设备一起注册。 在这里，我们使用 ```platform_device_register(struct platform_device *pdev)``` 函数，你可以使用该函数向平台核心注册平台设备：

```c
/*
* Other data than IRQ or memory must be embedded in a structure
* and passed to "platform_device.device.platform_data"
*/
struct my_gpios {
    int reset_gpio;
    int led_gpio;
};

/*our platform data*/
static struct my_gpios needed_gpios = {
    .reset_gpio = 47,
    .led_gpio = 41,
};

/* Our resource array */
static struct resource needed_resources[] = {
    [0] = { /* The first memory region */
        .start = JZ4740_UDC_BASE_ADDR,
        .end = JZ4740_UDC_BASE_ADDR + 0x10000 - 1,
        .flags = IORESOURCE_MEM,
        .name = "mem1",
    },
    [1] = {
        .start = JZ4740_UDC_BASE_ADDR2,
        .end = JZ4740_UDC_BASE_ADDR2 + 0x10000 -1,
        .flags = IORESOURCE_MEM,
        .name = "mem2",
    },
    [2] = {
        .start = JZ4740_IRQ_UDC,
        .end = JZ4740_IRQ_UDC,
        .flags = IORESOURCE_IRQ,
        .name = "mc",
    },
};

static struct platform_device my_device = {
    .name = "my-platform-device",
    .id = 0,
    .dev = {
    	.platform_data = &needed_gpios,
    },
    .resource = needed_resources,
    .num_resources = ARRY_SIZE(needed_resources),
};
platform_device_register(&my_device);
```

在前面的示例中，我们使用 IORESOURCE_IRQ 和 IORESOURCE_MEM 来告知内核我们提供了哪种资源。 要查看所有其他标志类型，请查看内核树中的 ```include/linux/ioport.h```。

为了检索我们之前注册的平台数据，我们可以只使用 ```pdev->dev.platform_data```（记住 ```struct platform_device``` 结构体），但是建议使用内核提供的函数（诚然，它也做同样的事情） ：

```c
void *dev_get_platdata(const struct device *dev)
struct my_gpios *picked_gpios = dev_get_platdata(&pdev->dev);
```



**在哪里声明平台设备？**
设备连同其资源和数据一起注册。 在此旧的，过时的方法中，它们在单独的模块中或在```arch/<arch>/mach-xxx/yyyy.c``` 中的板初始化文件中声明。 这里我们用NXP i.MX6Q 的文件做示例，```arch/arm/mach-imx/mach-imx6q.c```。 platform_device_register() 函数允许您执行以下操作：

```c
    static struct platform_device my_device = {
        .name 				= 	"my_drv_name",
        .id 				= 	0,
        .dev.platform_data 	= 	&my_device_pdata,
        .resource 			= 	jz4740_udc_resources,
        .num_resources 		= 	ARRY_SIZE(jz4740_udc_resources),
    };
    platform_device_register(&my_device);
```

设备的名称非常重要，内核使用它来匹配具有相同名称的驱动程序。



##### 设备配置-推荐的新方法

在第一种方法中，任何修改都必须重建整个内核。如果内核必须包含任何应用程序/主板特定的配置，则其大小将大大增加。为了使事情保持简单和与内核源代码分开的设备声明（因为它们实际上不是内核的一部分），引入了一个新概念：设备树。 DTS的主要目标是从内核中删除非常具体且未经测试的代码。使用设备树，平台数据和资源是同质的。设备树是硬件描述文件，其格式类似于树结构，其中每个设备都由一个节点表示，任何数据或资源或配置数据均表示为节点的属性。这样，您仅需进行一些修改即可重新编译设备树。设备树构成下一章的主题，我们将看到如何将其介绍给平台设备。





#### 设备，驱动程序和总线匹配

在发生任何匹配之前，Linux 会调用 ```platform_match(struct device *dev, struct device_driver *drv)``` 。 平台设备通过字符串与驱动程序匹配。 根据Linux设备模型，总线元素是最重要的部分。 每个总线都维护一个向其注册的驱动程序和设备的列表。 总线驱动程序负责设备和驱动程序的匹配。 每当您将新设备连接到总线或向总线添加新驱动程序时，该总线都会启动匹配循环。

现在，假设您使用I2C内核提供的功能注册新的I2C器件（在下一章中讨论）。 内核将通过调用在I2C总线驱动程序中注册的I2C核心匹配函数来检查是否已经存在与您的设备匹配的已注册驱动程序，从而触发I2C总线匹配循环。 如果没有匹配项，则不会发生任何事情。 如果发生匹配，内核将（通过称为 netlink socket的通信机制）通知设备管理器（udev/mdev），该设备管理器将加载（如果尚未加载）与设备匹配的驱动程序。 驱动程序加载后，将立即执行其 ```probe()``` 函数。 不仅 I2C 可以这样工作，其它每个总线都有类似的匹配机制（略有不同）。 在每个设备或驱动程序注册时都会触发总线匹配循环。

我们可以在下图中总结上一节中所说的内容：

<img src="./images/5_1.png" alt="image1" style="zoom:90%;" />

每个注册的驱动程序和设备都安装在总线上。 这样创建出一棵树型结构。 USB总线 可以是PCI总线的子代，而MDIO总线通常是其他设备的子代，依此类推。 因此，我们前面的图更改为：

<img src="./images/5_2.png" alt="image2" style="zoom:90%;" />

当您使用 ```platform_driver_probe()``` 函数注册驱动程序时，内核会遍历已注册平台设备的表并查找匹配项。 如果有，它将调用与平台数据匹配的驱动程序的探测功能。



##### 平台设备和平台驱动程序如何匹配？

到目前为止，我们仅讨论了如何填充设备和驱动程序的不同结构，但是现在我们将看到如何在内核中注册它们，以及Linux如何知道哪些设备由哪个驱动程序处理。 答案是 **MODULE_DEVICE_TABLE**。 在编译时，构建过程将从驱动程序中提取此信息，并构建一个可读的文件，称为 modules.alias ，位于目录 ```/lib/modules/kernel_version/``` 中。

该宏使驱动程序可以公开其ID表，该 ID表 描述了它可以支持的设备。 同时，如果可以将驱动程序编译为模块，则 driver.name 字段应与模块名称匹配。 如果不匹配，除非我们使用 **MODULE_ALIAS** 宏为该模块添加另一个名称，否则不会自动加载该模块。 在编译时，将从所有驱动程序中提取该信息以构建设备表。 当内核必须找到设备的驱动程序时（需要执行匹配时），内核会遍历设备表。 如果找到与所添加设备的兼容（对于设备树），设备/供应商ID或名称（对于设备ID表或名称）值匹配的条目，则将加载提供匹配项的模块（运行模块的init函数） ，然后调用探测功能。 MODULE_DEVICE_TABLE 宏在 ```linux/module.h``` 中定义：

```c
	#define MODULE_DEVICE_TABLE(type, name)
```

下面是对该宏给出的每个参数的描述：

* ```type``` ：这可以是i2c，spi，acpi，platform，usb，pci 或在 ```include/linux/mod_devicetable.h```中可能找到的任何其他总线。 这取决于设备所在的总线或我们要使用的匹配机制。
* ```name``` ：这是 ```XXX_device_id``` 数组上的指针，用于设备匹配。 如果我们谈论的是I2C设备，则结构应为 i2c_device_id。 对于SPI设备，它应该是 spi_device_id，依此类推。 对于设备树**Open**
  **Firmware (OF)** 匹配机制，我们必须使用 of_device_id。

> 对于新的不可发现的平台设备驱动程序，建议不要再使用平台数据，而应使用具有OF匹配机制的设备树功能。 请注意，这两种方法不是互斥的，因此可以将它们混合在一起。

除了OF样式匹配（我们将在第6章“设备树的概念”中讨论）外，让我们更深入地了解匹配机制的细节。



##### 内核设备和驱动程序匹配功能

内核中负责平台设备的功能和驱动程序匹配功能在 ```/drivers/base/platform.c``` 中定义如下：

```c
static int platform_match(struct device *dev, struct device_driver *drv)
{
    struct platform_device *pdev = to_platform_device(dev);
    struct platform_driver *pdrv = to_platform_driver(drv);
    
    /* When driver_override is set, only bind to the matching driver */
    if (pdev->driver_override)
    	return !strcmp(pdev->driver_override, drv->name);
    
    /* Attempt an OF style match first */
    if (of_driver_match_device(dev, drv))
    	return 1;
    
    /* Then try ACPI style match */
    if (acpi_driver_match_device(dev, drv))
    	return 1;
    
    /* Then try to match against the id table */
    if (pdrv->id_table)
    	return platform_match_id(pdrv->id_table, pdev) != NULL;
    
    /* fall-back to driver name match */
    return (strcmp(pdev->name, drv->name) == 0);
}
```

我们可以列举四种匹配机制。 它们全部基于字符串比较。 如果我们看一看 ```platform_match_id```，我们将了解下面的情况：

```c
static const struct platform_device_id *platform_match_id(
                        const struct platform_device_id *id,
                        struct platform_device *pdev)
{
    while (id->name[0]) {
        if (strcmp(pdev->name, id->name) == 0) {
            pdev->id_entry = id;
            return id;
    	}
    	id++;
    }
    return NULL;
}
```

现在，让我们看一下第4章 “字符设备驱动程序” 中讨论的 ```struct device_driver``` 结构：

```c
struct device_driver {
    const char *name;
    [...]
    const struct of_device_id 	*of_match_table;
    const struct acpi_device_id *acpi_match_table;
};
```

我有意删除了我们不感兴趣的字段。struct device_driver 构成了每个设备驱动程序的基础。 无论是I2C，SPI，TTY还是其他设备驱动程序，它们都嵌入了struct device_driver 元素。

**OF样式和ACPI匹配**
OF样式在第6章“设备树的概念”中进行了说明。 第二种机制是基于ACPI表的匹配。 在本书中我们将不再讨论，但为您参考，它使用了acpi_device_id结构。

**ID表匹配**
这种匹配样式已经存在很长时间了，并且基于 struct device_id 结构。 所有设备ID结构都在```include/linux/mod_devicetable.h``` 中定义。 要找到正确的结构名称，您需要在 ```device_id```之前加上设备驱动程序所在的总线名称。 示例包括用于 I2C 的 ```struct i2c_device_id``` ，用于平台设备（不位于真实物理总线上）的 ```struct platform_device_id```，用于SPI设备的 ```spi_device_id```，用于USB的```usb_device_id``` 等。 平台设备的 device_id 表的典型结构如下：

```c
struct platform_device_id {
    char name[PLATFORM_NAME_SIZE];
    kernel_ulong_t driver_data;
};
```

无论如何，如果注册了一个ID表，只要内核运行match函数为未知或新平台设备找到驱动程序，就会遍历该ID表。 如果存在匹配项，则将调用匹配的驱动程序的探测功能，并以```struct platform_device``` 作为参数，该结构将保存指向发起匹配项的匹配ID表条目的指针。 ```.driver_data``` 元素为无符号长，有时会被转换为指针地址以指向任何内容，就像在 serialimx 驱动程序中一样。 以下是在中使用 ```platform_device_id``` 的示例:

```c
//drivers/tty/serial/imx.c:
static const struct platform_device_id imx_uart_devtype[] = {
    {
        .name = "imx1-uart",
        .driver_data = (kernel_ulong_t) &imx_uart_devdata[IMX1_UART],
    }, {
        .name = "imx21-uart",
        .driver_data = (kernel_ulong_t)&imx_uart_devdata[IMX21_UART],
    }, {
        .name = "imx6q-uart",
        .driver_data = (kernel_ulong_t)&imx_uart_devdata[IMX6Q_UART],
    }, {
    /* sentinel */
    }
};
```

```.name``` 字段必须与您在主板专用文件中注册设备时提供的设备名称相同。 负责这种匹配样式的函数是```platform_match_id```。 如果在 ```drivers/base/platform.c``` 中查看其定义，则会看到：

```c
static const struct platform_device_id *platform_match_id(
                        const struct platform_device_id *id,
                        struct platform_device *pdev)
{
    while (id->name[0]) {
        if (strcmp(pdev->name, id->name) == 0) {
            pdev->id_entry = id;
            return id;
        }
        id++;
    }
    return NULL;
}
```

在下面的示例（摘录自内核源代码中的 ```drivers/tty/serial/imx.c```）中，您可以看到仅通过强制转换如何将平台数据转换回原始数据结构。 人们有时就是这样将任何数据结构作为平台数据传递的：

```c
static void serial_imx_probe_pdata(struct imx_port *sport,
				struct platform_device *pdev)
{
    struct imxuart_platform_data *pdata = dev_get_platdata(&pdev->dev);
    
    sport->port.line = pdev->id;
    sport->devdata = (struct imx_uart_data *) pdev->id_entry->driver_data;
    
    if (!pdata)
    	return;
    [...]
}
```

```pdev->id_entry``` 是一个 ```struct platform_device_id```，它是指向内核提供的匹配ID表条目的指针，并且其 ```driver_data``` 元素被强制返回到数据结构上的指针。



**ID表匹配中每个设备的特定数据**
在上一节中，我们使用 ```platform_device_id.platform_data``` 作为指针。 您的驱动程序可能需要支持多种设备类型。 在这种情况下，您需要支持的每种设备类型的特定设备数据。 然后，您应该将设备ID用作包含所有可能的设备数据的数组的索引，而不再用作指针地址。 以下是示例中的详细步骤：

1. 我们定义一个枚举，具体取决于我们需要在驱动程序中支持的设备类型：

   ```c
   enum abx80x_chip {
       AB0801,
       AB0803,
       AB0804,
       AB0805,
       AB1801,
       AB1803,
       AB1804,
       AB1805,
       ABX80X
   };
   ```

2. 我们定义了特定的数据类型结构：

   ```c
   struct abx80x_cap {
       u16 pn;
       bool has_tc;
   };
   ```

3. 我们用默认值填充一个数组，并根据device_id中的索引，我们可以选择正确的数据：

   ```c
   static struct abx80x_cap abx80x_caps[] = {
       [AB0801] = {.pn = 0x0801},
       [AB0803] = {.pn = 0x0803},
       [AB0804] = {.pn = 0x0804, .has_tc = true},
       [AB0805] = {.pn = 0x0805, .has_tc = true},
       [AB1801] = {.pn = 0x1801},
       [AB1803] = {.pn = 0x1803},
       [AB1804] = {.pn = 0x1804, .has_tc = true},
       [AB1805] = {.pn = 0x1805, .has_tc = true},
       [ABX80X] = {.pn = 0}
   };
   ```

4. 我们用特定的索引定义 ```platform_device_id``` ：

   ```c
   static const struct i2c_device_id abx80x_id[] = {
       { "abx80x", ABX80X },
       { "ab0801", AB0801 },
       { "ab0803", AB0803 },
       { "ab0804", AB0804 },
       { "ab0805", AB0805 },
       { "ab1801", AB1801 },
       { "ab1803", AB1803 },
       { "ab1804", AB1804 },
       { "ab1805", AB1805 },
       { "rv1805", AB1805 },
       { }
   };
   ```

5. 在这里，我们只需要在probe函数中做一些事情：

   ```c
   static int rs5c372_probe(struct i2c_client *client,
   					const struct i2c_device_id *id)
   {
       [...]
       
       /* We pick the index corresponding to our device */
       int index = id->driver_data;
       /*
       * And then, we can access the per device data
       * since it is stored in abx80x_caps[index]
       */
   }
   ```

   

**名称匹配–平台设备名称匹配**
如今，大多数平台驱动程序根本不提供任何表。 它们只是在驱动程序的名称字段中填写驱动程序本身的名称。 但是该匹配有效，因为，如果您查看 ```platform_match``` 函数，您将看到匹配最终归结为名称匹配，比较了驱动程序的名称和设备的名称。 一些较旧的驱动程序仍然使用该匹配机制。 以下是来自```sound/soc/fsl/imx-ssi.c``` 的名称匹配 :

```c
static struct platform_driver imx_ssi_driver = {
    .probe = imx_ssi_probe,
    .remove = imx_ssi_remove,
    
    /* As you can see here, only the 'name' field is filled */
    .driver = {
    	.name = "imx-ssi",
    },
};
module_platform_driver(imx_ssi_driver);
```

要添加与此驱动程序匹配的设备，您必须使用与特定于板的文件（通常在```arch/<your_arch>/mach-*/board-*.c``` 中）相同的名称 imx-ssi 调用 ```platform_device_register``` 或 ```platform_add_devices``` . 对于基于i.MX6的四核UDOO，它是 ```arch/arm/mach-imx/mach-imx6q.c```。



#### 总结

内核伪平台总线对你已不再是秘密。 使用总线匹配机制，您可以了解如何，何时以及为什么加载驱动程序，以及该驱动程序用于哪个设备。 我们可以基于所需的匹配机制来实现任何探测功能。 由于驱动程序的主要目的是处理设备，因此我们现在可以在系统中填充设备（旧的和新的方式）。 为完成样式，下一章将专门讨论设备树，这是用于在系统上填充设备及其配置的新机制。