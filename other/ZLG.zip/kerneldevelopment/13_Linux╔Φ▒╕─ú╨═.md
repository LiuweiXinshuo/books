# Linux设备模型

在2.5版之前，内核无法描述和管理对象，并且代码可重用性并未像现在这样得到增强。换句话说，没有设备拓扑或组织。没有有关子系统关系的信息，也没有有关系统如何组合的信息。然后是Linux设备模型（LDM），它引入了以下内容：

* 类的概念，用于将相同类型的设备或具有相同功能的设备分组（例如，鼠标和键盘都是输入设备）。
* 通过称为sysfs的虚拟文件系统与用户空间进行通信，以使用户空间可以管理和枚举设备及其公开的属性。
* 使用引用计数（在托管资源中大量使用）管理对象生命周期。
* 电源管理以便处理设备应关闭的指令。
* 代码可重用性。类和框架公开接口，其行为就像契约一样，向其注册的任何驱动程序都必须遵守。
* LDM为内核带来了类似于面向对象（OO）的编程风格。

在本章中，我们将利用LDM并通过sysfs文件系统将某些属性导出到用户空间。

在本章中，我们将介绍以下主题：

* 介绍 LDM 数据结构（驱动程序，设备，总线）
* 按类型收集内核对象
* 处理内核sysfs接口



### LDM数据结构

目标是构建一个完整的设备树，以映射系统上存在的每个物理设备并介绍其层次结构。 已经创建了一个通用的通用结构来表示可以成为设备模型一部分的任何对象。 LDM 的高层依赖于内核中作为 struct bus_type 实例表示的总线。 设备驱动程序（由 struct device_driver 结构表示）和设备（最后一个元素表示为struct device 结构的实例）。 在本节中，我们将设计一个总线驱动程序打包总线，以便详细研究LDM数据结构和机制。



#### 总线

总线是设备和处理器之间的通道链接。 管理总线并将其协议导出到设备的硬件实体称为总线控制器。 例如，USB控制器提供USB支持。 I2C控制器提供 I2C 总线支持。 因此，总线控制器本身就是一个设备，必须像任何设备一样注册。 它将是需要坐在总线上的设备的父级。 换句话说，坐在总线上的每个设备都必须使其父字段指向总线设备。 总线在内核中由 ```struct bus_type``` 结构表示：

```c
struct bus_type {
    const char *name;
    const char *dev_name;
    struct device *dev_root;
    struct device_attribute *dev_attrs; 	/* use dev_groups instead */
    const struct attribute_group **bus_groups;
    const struct attribute_group **dev_groups;
    const struct attribute_group **drv_groups;
    int (*match)(struct device *dev, struct device_driver *drv);
    int (*probe)(struct device *dev);
    int (*remove)(struct device *dev);
    void (*shutdown)(struct device *dev);
    int (*suspend)(struct device *dev, pm_message_t state);
    int (*resume)(struct device *dev);
    const struct dev_pm_ops *pm;
    struct subsys_private *p;
    struct lock_class_key lock_key;
};
```

以下是结构体中各成员的含义：

* ```match```：这是一个回调，每当将新设备或驱动程序添加到总线时都将调用此回调。 回调必须足够智能，并且当设备和驱动程序之间都存在匹配项时都应返回非零值，二者均作为参数给出。 匹配回调的主要目的是允许总线确定特定设备是否可以由给定驱动程序或其他逻辑处理，如果给定驱动程序支持给定设备。 多数情况下，验证是通过简单的字符串比较（表和DT兼容属性的设备和驱动程序名称）完成的。 对于枚举设备（PCI，USB），通过比较驱动程序支持的设备ID与给定设备的设备ID来完成验证，而不会牺牲特定于总线的功能。

* ```probe``` ：匹配发生后，这是将新设备或驱动程序添加到总线时的回调。 该函数负责分配特定的总线设备结构，并调用给定的驱动程序的探测功能，该功能应该用于管理设备（较早分配）。

* ```remove```：从总线上删除设备时调用。
* ```suspend``` ：当需要将总线上的设备置于睡眠模式时，此方法将被调用。
* ```resume```：当必须使总线上的设备退出睡眠模式时调用此方法。
* ```pm``` ：这是总线的一组电源管理操作，它将调用特定设备驱动程序的pm-ops。

* ```drv_groups``` ：这是指向 struct attribute_group 元素的列表（数组）的指针，每个元素都有一个指向struct attribute_元素的列表（数组）的指针。 它代表总线上设备驱动程序的默认属性。 传递给该字段的属性将提供给在总线上注册的每个驱动程序。 这些属性可以在驱动程序的目录 ```/sys/bus/<busname>/
  drivers/<driver-name>``` 中找到。
* ```dev_groups``` ：这表示总线上设备的默认属性。 （通过struct attribute_group元素的列表/数组）传递给该字段的属性将提供给在总线上注册的每个设备。 这些属性可以在 ```/sys/bus/<busname>/devices/<device-name>``` 的设备目录中找到。
* ```bus_group``` ：保存总线向核心注册时自动添加的默认属性集（组）。

除了定义bus_type之外，总线控制器驱动程序还必须定义扩展通用结构device_driver的特定于总线的驱动程序结构，以及扩展通用结构设备结构的特定于总线的设备结构，这都是设备模型核心的一部分。 总线驱动程序还必须为探测时发现的每个物理设备分配特定于总线的设备结构，并负责初始化设备的总线和父字段并向LDM内核注册设备。 这些字段必须指向总线设备和在总线驱动程序中定义的bus_type结构。 LDM核心使用它来构建设备层次结构并初始化其他字段。

在我们的示例中，以下是获得通用结构设备和结构驱动程序的两个帮助程序宏，用于获取打包设备和打包驱动程序：

```c
#define to_packt_driver(d) container_of(d, struct packt_driver, driver)
#define to_packt_device(d) container_of(d, struct packt_device, dev)
```

然后是用于标识打包设备的结构：

```c
struct packt_device_id {
    char name[PACKT_NAME_SIZE];
    kernel_ulong_t driver_data; /* Data private to the driver */
};
```

以下是特定于数据包的设备和驱动程序结构：

```c
/*
 * Bus specific device structure
 * This is what a packt device structure looks like
 */
struct packt_device {
    struct module *owner;
    unsigned char name[30];
    unsigned long price;
    struct device dev;
};
/*
 * Bus specific driver structure
 * This is what a packt driver structure looks like
 * You should provide your device's probe and remove function.
 * may be release too
 */
struct packt_driver {
    int (*probe)(struct packt_device *packt);
    int (*remove)(struct packt_device *packt);
    void (*shutdown)(struct packt_device *packt);
};
```

每条总线在内部管理两个重要列表： 已添加并位于上面的设备的列表，以及在其中注册的驱动程序的列表。 每当您在总线上添加/注册或从总线上删除/注销设备/驱动程序时，就会使用新条目更新相应的列表。 总线驱动程序必须提供帮助程序功能来注册/注销可以处理该总线上的设备的设备驱动程序，以及帮助程序功能来注册/注销位于总线上的设备。 这些辅助函数始终包装LDM内核提供的通用函数，它们是 ```driver_register()``` ，```device_register()``` ，```driver_unregister()``` 和 ```device_unregister()```。

```c
/*
 * Now let us write and export symbols that people writing
 * drivers for packt devices must use.
 */
int packt_register_driver(struct packt_driver *driver)
{
    driver->driver.bus = &packt_bus_type;
    return driver_register(&driver->driver);
}
EXPORT_SYMBOL(packt_register_driver);

void packt_unregister_driver(struct packt_driver *driver)
{
	driver_unregister(&driver->driver);
}
EXPORT_SYMBOL(packt_unregister_driver);

int packt_device_register(struct packt_device *packt)
{
	return device_register(&packt->dev);
}
EXPORT_SYMBOL(packt_device_register);

void packt_unregister_device(struct packt_device *packt)
{
	device_unregister(&packt->dev);
}
EXPORT_SYMBOL(packt_device_unregister);
```

用于分配打包设备的功能如下。 必须使用它来创建总线上任何物理设备的实例：

```c
/*
 * This function allocate a bus specific device structure
 * One must call packt_device_register to register
 * the device with the bus
 */
struct packt_device * packt_device_alloc(const char *name, int id)
{
    struct packt_device *packt_dev;
    int status;
    packt_dev = kzalloc(sizeof *packt_dev, GFP_KERNEL);
    if (!packt_dev)
    	return NULL;
    /* new devices on the bus are son of the bus device */
    strcpy(packt_dev->name, name);
    packt_dev->dev.id = id;
    dev_dbg(&packt_dev->dev,
            "device [%s] registered with packt bus\n", packt_dev->name);
    return packt_dev;
    
 out_err:
    dev_err(&adap->dev, "Failed to register packt client %s\n",
            packt_dev->name);
    kfree(packt_dev);
    return NULL;
}
EXPORT_SYMBOL_GPL(packt_device_alloc);

int packt_device_register(struct packt_device *packt)
{
    packt->dev.parent = &packt_bus;
    packt->dev.bus = &packt_bus_type;
    return device_register(&packt->dev);
}
EXPORT_SYMBOL(packt_device_register);
```



### 总线注册

总线控制器本身就是设备，在99％的情况下，总线是平台设备（甚至是提供枚举的总线）。 例如，PCI控制器是平台设备，其相应的驱动程序也是如此。 为了在内核中注册总线，必须使用 ```bus_register(struct *bus_type)``` 函数。 打包总线的结构如下所示：

```c
/*
 * This is our bus structure
 */
struct bus_type packt_bus_type = {
    .name = "packt",
    .match = packt_device_match,
    .probe = packt_device_probe,
    .remove = packt_device_remove,
    .shutdown = packt_device_shutdown,
};
```

总线控制器本身就是设备。 它必须在内核中注册，并将用作总线上设备位置的父级。 这是在总线控制器的 probe 或 init 函数中完成的。 对于packt总线，代码如下：

```c
/*
 * Bus device, the master.
 *
 */
struct device packt_bus = {
    .release = packt_bus_release,
    .parent = NULL, 	/* Root device, no parent needed */
};

static int __init packt_init(void)
{
    int status;
    status = bus_register(&packt_bus_type);
    if (status < 0)
    	goto err0;
    status = class_register(&packt_master_class);
    if (status < 0)
    	goto err1;
    /*
    * After this call, the new bus device will appear
    * under /sys/devices in sysfs. Any devices added to this
    * bus will shows up under /sys/devices/packt-0/.
    */
    device_register(&packt_bus);
    return 0;
    
err1:
    bus_unregister(&packt_bus_type);
err0:
    return status;
}
```

通过总线控制器驱动程序注册设备时，该设备的父成员必须指向总线控制器设备，并且其总线属性必须指向总线类型以构建物理DT。 要注册一个packt设备，必须调用 ```packt_device_register```，它是与 ```packt_device_alloc``` 一起分配的一个参数：

```c
int packt_device_register(struct packt_device *packt)
{
    packt->dev.parent = &packt_bus;
    packt->dev.bus = &packt_bus_type;
    return device_register(&packt->dev);
}
EXPORT_SYMBOL(packt_device_register);
```



#### 设备驱动程序

全局设备层次结构允许以通用方式表示系统中的每个设备。 这使内核可以轻松地通过DT创建诸如正确排序的电源管理转换之类的内容：

```c
struct device_driver {
    const char *name;
    struct bus_type *bus;
    struct module *owner;
    const struct of_device_id *of_match_table;
    const struct acpi_device_id *acpi_match_table;
    int (*probe) (struct device *dev);
    int (*remove) (struct device *dev);
    void (*shutdown) (struct device *dev);
    int (*suspend) (struct device *dev, pm_message_t state);
    int (*resume) (struct device *dev);
    const struct attribute_group **groups;
    const struct dev_pm_ops *pm;
};
```

struct device_driver 为核心定义了一组简单的操作，以在每个设备上执行以下操作：

* ```* name```代表驱动的名字。 通过与设备名称进行比较，可以将其用于匹配。

* ```* bus``` 代表驱动所在的总线。 总线驱动程序必须填写此字段。

* ```module``` 代表拥有驱动程序的模块。 在99％的情况下，应将此字段设置为THIS_MODULE。

* ```of_match_table``` 是指向结构 of_device_id 数组的指针。struct of_device_id 结构用于通过称为 DT 的特殊文件执行 OF 匹配，该文件在引导过程中传递给内核：

  ```c
  struct of_device_id {
      char compatible[128];
      const void *data;
  };
  ```

* ```suspend/resume``` 回调提供电源管理功能。 从设备物理上从系统中删除设备时，或当其引用计数达到0时，将调用remove回调。在系统重新引导期间，也会调用remove回调。

* ```probe``` 是尝试将驱动程序绑定到设备时运行的探针回调。 总线驱动程序负责调用设备驱动程序的探测功能。

* ```group``` 是指向struct attribute_group列表（数组）的指针，用作驱动程序的默认属性。 使用此方法，而不是单独创建属性。



#### 设备驱动程序注册

```driver_register()``` 是用于向总线注册设备驱动程序的低级函数。 它将驱动程序添加到总线的驱动程序列表中。 在总线上注册了设备驱动程序后，内核会遍历总线的设备列表，并为每个没有与之关联的驱动程序的设备调用总线的match回调，以便找出驱动程序中是否有任何设备 可以处理。

发生匹配时，设备和设备驱动程序将联系在一起。 将设备与设备驱动程序关联的过程称为绑定。

返回我们的驱动向 pack 总线注册； 必须使用 ```packt_register_driver(struct packt_driver * driver)```，它是 ```driver_register()``` 的封装。 在注册 packt 驱动程序之前，必须已填写 ```* driver``` 参数。 LDM核心提供了用于遍历在总线上注册的驱动程序列表的帮助程序功能：

```c
int bus_for_each_drv(struct bus_type * bus,
                     struct device_driver * start,
                     void * data, int (*fn)(struct device_driver *,
                     void *));
```

该帮助程序遍历总线的驱动程序列表，并为列表中的每个驱动程序调用fn回调。



#### 设备

struct device 是，用于描述和表征系统上的每个设备（无论是否物理）的通用数据结构。 它包含有关设备物理属性的详细信息，并提供适当的链接信息以构建合适的设备树和参考计数：

```c
struct device {
    struct device *parent;
    struct kobject kobj;
    const struct device_type *type;
    struct bus_type *bus;
    struct device_driver *driver;
    void *platform_data;
    void *driver_data;
    struct device_node *of_node;
    struct class *class;
    const struct attribute_group **groups;
    void (*release)(struct device *dev);
};
```

* ```* parent``` ：表示设备的父级，用于构建设备树层次结构。 在总线上注册后，总线驱动程序负责在总线设备上设置此字段。
* ```* bus``` ：表示设备所在的总线。 总线驱动程序必须填写此字段。
* ```* type``` ：标识设备的类型。

* ```kobj``` : 是句柄引用计数和设备模型支持中的kobject。

* ```* of_node``` : 是指向与设备关联的OF（DT）节点的指针。 由总线驱动程序来设置此字段。
* ```platform_data``` : 是指向特定于设备的平台数据的指针。 通常在设备供应期间在特定于电路板的文件中声明。
* ```driver_data``` : 是指向驱动程序私有数据的指针。
* ```class``` : 是指向设备所属类的指针。
* ```* group``` : 是指向 struct attribute_group 列表（数组）的指针，用作设备的默认属性。 使用此方法，而不是单独创建属性。
* ```release``` : 是当设备引用计数达到零时调用的回调。 总线负责设置此字段。 打包总线驱动程序向您显示了如何执行此操作。



#### 设备注册

device_register 是LDM内核提供的用于向总线注册设备的功能。 调用后，将遍历驱动程序的总线列表以查找支持该设备的驱动程序，然后将该设备添加到总线的设备列表中。 ```device_register()``` 内部调用```device_add()``` ：

```c
int device_add(struct device *dev)
{
    [...]
    bus_probe_device(dev);
    if (parent)
    	klist_add_tail(&dev->p->knode_parent,
                       &parent->p->klist_children);
    [...]
}
```

内核提供的用于遍历总线设备列表的迭代器函数为 bus_for_each_dev：

```c
int bus_for_each_dev(struct bus_type * bus,
                     struct device * start, void * data,
                     int (*fn)(struct device *, void *));
```

每当添加设备时，内核都会调用总线驱动程序的 match 方法（bus_type-> match）。 如果 match 函数匹配到该设备的驱动程序，则内核将调用总线驱动程序的探测功能（bus_type-> probe），同时将设备和驱动程序作为参数。 然后由总线驱动程序调用设备驱动程序的探测方法（driver-> probe）。 对于我们的 packt 总线驱动程序，用于注册设备的函数是 packt_device_register(struct packt_device * packt)，该函数内部调用 device_register，其中参数是使用 packt_device_alloc 分配的 packt 设备。



### 深入LDM

在底层，LDM依赖于三个重要的结构，即kobject，kobj_type和kset。 让我们看看这些结构中的每一个如何与设备模型有关。



#### kobject 结构

kobject 是设备模型的核心，在后台运行。 它为内核带来了类似于OO的编程风格，主要用于引用计数和公开设备层次结构以及它们之间的关系。 kobjects 引入了封装通用对象属性的概念，例如用法引用计数：

```c
struct kobject {
    const char *name;
    struct list_head entry;
    struct kobject *parent;
    struct kset *kset;
    struct kobj_type *ktype;
    struct sysfs_dirent *sd;
    struct kref kref;
    /* Fields out of our interest have been removed */
};
```

* ```name``` : 指向此kobject的名称。 可以使用kobject_set_name（struct kobject * kobj，const char * name）函数更改此设置。
* ```parent``` : 是指向该kobject的父对象的指针。 它用于建立层次结构来描述对象之间的关系。
* ```sd``` : 指向一个 sysfs_dirent 结构，该结构表示sysfs的该结构内 sysfs inode 中的此 kobject。
* ```kref``` : 提供对 kobject 的引用计数。
* ```ktype``` : 描述对象，而 kset 告诉我们该对象属于哪个对象集（组）。

嵌入 kobject 的每个结构都被嵌入并接收 kobject 提供的标准化功能。 嵌入的 kobject 将使结构成为对象层次结构的一部分。

```container_of ```宏用于获取 kobject 所属对象的指针。 每个内核设备都直接或间接嵌入 kobject 属性。 在将kobject 添加到系统之前，必须使用 ```kobject_create()``` 函数进行分配，该函数将返回一个空的 kobject，必须使用 ```kobj_init()``` 对其进行初始化，并将已分配和未初始化的 kobject 指针作为参数提供给该对象 其kobj_type指针：

```c
struct kobject *kobject_create(void)
void kobject_init(struct kobject *kobj, struct kobj_type *ktype)
```

```kobject_add()``` 函数用于将 kobject 添加并链接到系统，同时根据其层次结构及其默认属性创建其目录。 反向函数是 ```kobject_del()``` ：

```c
int kobject_add(struct kobject *kobj, struct kobject *parent, const char *fmt, ...);
```

kobject_create 和 kobject_add 的反向函数都是 kobject_put 。 在本书随附的源代码中，以下摘录将kobject与系统相关联：

```c
/* Somewhere */
static struct kobject *mykobj;
mykobj = kobject_create();
    if (mykobj) {
        kobject_init(mykobj, &mytype);
        if (kobject_add(mykobj, NULL, "%s", "hello")) {
            err = -1;
            printk("ldm: kobject_add() failed\n");
            kobject_put(mykobj);
            mykobj = NULL;
        }
        err = 0;
    }
```

可以使用 ```kobject_create_and_add``` ，在内部调用 kobject_create 和 kobject_add。 以下来自 drivers/base/core.c 的摘录显示了如何使用它：

```c
static struct kobject * class_kobj = NULL;
static struct kobject * devices_kobj = NULL;

/* Create /sys/class */
class_kobj = kobject_create_and_add("class", NULL);
if (!class_kobj) {
	return -ENOMEM;
}

/* Create /sys/devices */
devices_kobj = kobject_create_and_add("devices", NULL);
if (!devices_kobj) {
	return -ENOMEM;
}
```

> 如果kobject的父级为NULL，则kobject_add将父级设置为kset。 如果两者均为NULL，则该对象成为顶级sys目录的子成员。



#### kobj_type

```struct kobj_type``` 结构描述了 kobject 的行为。 kobj_type 结构描述了通过 ktype 字段嵌入 kobject 的对象的类型。 嵌入 kobject 的每个结构都需要一个对应的 kobj_type，它将控制在创建和销毁 kobject 以及读取或写入属性时发生的情况。 每个 kobject 都有一个 struct kobj_type 类型的字段，代表内核对象类型：

```c
struct kobj_type {
    void (*release)(struct kobject *);
    const struct sysfs_ops sysfs_ops;
    struct attribute **default_attrs;
};
```

struct kobj_type 结构允许内核对象共享通用操作（sysfs_ops），无论这些对象在功能上是否相关。 这种结构的字段足够有意义。 release 是需要释放对象时由 ```kobject_put()``` 函数调用的回调。 您必须在此处释放对象保留的内存。 可以使用 container_of 宏获取指向该对象的指针。 sysfs_ops 字段指向 sysfs 操作，而 default_attrs 定义与此 kobject 相关的默认属性。 sysfs_ops 是访问 sysfs 属性时调用的一组回调（sysfs操作）。 default_attrs是指向 struct属性元素列表的指针，这些元素将用作此类型每个对象的默认属性：

```c
struct sysfs_ops {
    ssize_t (*show)(struct kobject *kobj,
                    struct attribute *attr, char *buf);
    ssize_t (*store)(struct kobject *kobj,
                     struct attribute *attr,const char *buf,
                     size_t size);
};
```

show 是在读取具有此 kobj_type 的任何 kobject 的属性时调用的回调。 即使要显示的值是一个简单的字符，缓冲区的大小也始终为 PAGE_SIZE。 应该设置 buf 的值（使用scnprintf），并在成功时返回实际写入缓冲区的数据大小（以字节为单位），或者在失败时返回负错误。 出于存储目的而调用存储。 其buf参数最多为PAGE_SIZE，但可以更小。 如果成功，则返回实际从缓冲区读取的数据大小（以字节为单位）；如果失败，则返回负错误（或者如果接收到不需要的值）。 可以使用 get_ktype 获取给定 kobject 的 kobj_type：

```c
struct kobj_type *get_ktype(struct kobject *kobj);
```

在本书的示例中，我们的k_type变量表示我们的 kobject 的类型：

```c
static struct sysfs_ops s_ops = {
    .show = show,
    .store = store,
};

static struct kobj_type k_type = {
    .sysfs_ops = &s_ops,
    .default_attrs = d_attrs,
};
```

在这里，show 和 store 回调定义如下：

```c
static ssize_t show(struct kobject *kobj, struct attribute *attr, char *buf)
{
    struct d_attr *da = container_of(attr, struct d_attr, attr);
    printk( "LDM show: called for (%s) attr\n", da->attr.name );
    return scnprintf(buf, PAGE_SIZE,"%s: %d\n", da->attr.name, da->value);
}
static ssize_t store(struct kobject *kobj, struct attribute *attr, const char *buf, size_t len)
{
    struct d_attr *da = container_of(attr, struct d_attr, attr);
    sscanf(buf, "%d", &da->value);
    printk("LDM store: %s = %d\n", da->attr.name, da->value);
    return sizeof(int);
}
```



#### ksets

内核对象集（ksets）主要将相关的内核对象分组在一起。 kset 是 kobject 的集合。 换句话说，一个kset将相关的kobject 收集到一个位置，例如，所有块设备：

```c
struct kset {
    struct list_head list;
    spinlock_t list_lock;
    struct kobject kobj;
};
```

前面的结构可以解释如下：

* list是 kset 中所有 kobject 的链表
* list_lock 是一个自旋锁，用于保护链接列表访问
* kobj 代表集合的基类

每个已注册（添加到系统中）的 kset 都对应一个 sysfs 目录。 可以使用 ```kset_create_and_add()``` 函数创建和添加kset，并使用 ```kset_unregister()``` 函数将其删除：

```c
struct kset * kset_create_and_add(const char *name,
                                  const struct kset_uevent_ops *u,
                                  struct kobject *parent_kobj);
void kset_unregister (struct kset * k);
```

向集合添加一个 kobject 就像在右边的 kset 中指定其 kset 字段一样简单：

```c
static struct kobject foo_kobj, bar_kobj;

example_kset = kset_create_and_add("kset_example", NULL, kernel_kobj);
/*
* since we have a kset for this kobject,
* we need to set it before calling the kobject core.
*/
foo_kobj.kset = example_kset;
bar_kobj.kset = example_kset;
retval = kobject_init_and_add(&foo_kobj, &foo_ktype,
                              NULL, "foo_name");
retval = kobject_init_and_add(&bar_kobj, &bar_ktype,
                              NULL, "bar_name");
```

现在，删除 kobject 及其属性后，请在模块退出函数中注意以下内容：

```c
kset_unregister(example_kset);
```



#### 属 性(Attributes)

属性是由kobjects导出到用户空间的sysfs文件。 属性表示可以从用户空间读取，写入或两者兼有的对象属性。 也就是说，每个嵌入struct kobject的数据结构都可以公开由kobject本身提供的默认属性（如果有）或自定义属性。 换句话说，属性将内核数据映射到sysfs中的文件。

属性定义如下所示：

```c
struct attribute {
    char * name;
    struct module *owner;
    umode_t mode;
};
```

用于从文件系统添加/删除属性的内核函数如下：

```c
int sysfs_create_file(struct kobject * kobj,
                      const struct attribute * attr);
void sysfs_remove_file(struct kobject * kobj,
                       const struct attribute * attr);
```

让我们尝试定义两个要导出的属性，每个属性都由一个属性表示：

```c
struct d_attr {
    struct attribute attr;
    int value;
};

static struct d_attr foo = {
    .attr.name="foo",
    .attr.mode = 0644,
    .value = 0,
};

static struct d_attr bar = {
    .attr.name="bar",
    .attr.mode = 0644,
    .value = 0,
};
```

要分别创建每个枚举属性，我们必须调用以下命令：

```c
sysfs_create_file(mykobj, &foo.attr);
sysfs_create_file(mykobj, &bar.attr);
```

从属性开始的一个好地方是内核源代码中的 ```samples/kobject/kobject-example.c```。



#### 属性组

到目前为止，我们已经了解了如何分别添加属性并在每个属性上分别调用（直接或间接通过包装函数，例如```device_create_file()``` ，```class_create_file()``` ,```sysfs_create_file()``` 等。我们还想要一次调用多个属性， 这就是属性组的来源。它依赖于```struct attribute_group``` 结构：

```c
struct attribute_group {
	struct attribute **attrs;
};
```

当然，我们删除了不需要的字段。 attrs 字段是指向以NULL结尾的属性列表的指针。 必须为每个属性组提供一个指向结构属性元素列表/数组的指针。 该组只是一个帮助程序包装器，它使管理多个属性更加容易。

用于向文件系统添加/删除组属性的内核函数是：

```c
int sysfs_create_group(struct kobject *kobj,
                       const struct attribute_group *grp)
void sysfs_remove_group(struct kobject * kobj,
                        const struct attribute_group * grp)
```

可以将先前定义的两个属性嵌入struct attribute_group中，以仅进行一次调用即可将它们都添加到系统中：

```c
static struct d_attr foo = {
    .attr.name="foo",
    .attr.mode = 0644,
    .value = 0,
};

static struct d_attr bar = {
    .attr.name="bar",
    .attr.mode = 0644,
    .value = 0,
};

/* attrs is a pointer to a list (array) of attributes */
static struct attribute * attrs [] =
{
    &foo.attr,
    &bar.attr,
    NULL,
};

static struct attribute_group my_attr_group = {
	.attrs = attrs,
};
```

这里要调用的唯一函数是：

```c
sysfs_create_group(mykobj, &my_attr_group);
```

这比对每个属性进行调用要好得多。



### 设备模型和sysfs

Sysfs 是一个非持久性虚拟文件系统，它提供系统的全局视图，并通过其 kobject 公开内核对象的层次结构（拓扑）。 每个 kobject 都显示为一个目录，目录中的文件表示由相关kobject导出的内核变量。 这些文件称为属性，可以读取或写入。

任何注册的kobject都会在sysfs中创建一个目录； 创建目录的位置取决于kobject的父对象（也是kobject）。 将目录创建为kobject父级的子目录是很自然的。 这突出显示了用户空间的内部对象层次结构。 sysfs中的顶级目录表示对象层次结构的共同祖先，即对象所属的子系统。

顶级 sysfs 目录位于 /sys/ 目录下：

```shell
/sys$ tree -L 1
├── block
├── bus
├── class
├── dev
├── devices
├── firmware
├── fs
├── hypervisor
├── kernel
├── module
└── power
```

block 包含系统上每个块设备的目录，每个目录都包含设备上分区的子目录。 bus 包含系统上已注册的总线。 dev以原始方式（无层次结构）包含已注册的设备节点，每个节点都是 /sys/devices 目录中到实际设备的符号链接。 devices 提供了系统中设备拓扑的视图。 firmware 显示了特定系统的低级子系统树，例如：ACPI，EFI，OF（DT）。 fs 列出了系统上实际使用的文件系统。 kernel 包含内核配置选项和状态信息。 module 是已加载模块的列表。

这些目录中的每一个都对应一个kobject，其中的一些被导出为内核符号。 这些是：

* kernel_kobj ：它对应于 /sys/kernel
* power_kobj ：对应于 /sys/power
* firmware_kobj ：对应于 /sys/firmware，已在 drivers/base/firmware.c 源文件中导出
* hypervisor_kobj ：对应于 /sys/hypervisor，在驱动程序 /base/hypervisor.c 中导出
* fs_kobj：对应于 /sys/fs，已导出到 fs/namespace.c 文件中

但是，class/，dev/ 和 devices/ 是在引导过程中由内核源中 drivers/base/core.c 中的 devices_init 函数创建的，block/ 是在 block/genhd.c 中创建的，而 bus/ 是作为drivers / base / bus.c中的kset 被创建的。

将 kobject 目录添加到 sysfs 中（使用kobject_add）时，其添加位置取决于 kobject 的父位置。 如果设置了其父指针，它将作为子目录添加到父目录内。 如果父指针为NULL，则将其作为子目录添加到 kset->kobj 中。 如果未设置父字段或 kset 字段，则它将映射到 sysfs（/sys）中的根目录。

可以使用 ```sysfs_{create | remove}_link``` 函数在现有对象（目录）上创建/删除符号链接：

```c
int sysfs_create_link(struct kobject * kobj,
                      struct kobject * target, char * name);
void sysfs_remove_link(struct kobject * kobj, char * name);
```

这将使一个对象存在多个位置。 create 函数将创建一个名为 name 的符号链接，该符号链接指向目标kobject sysfs条目。 一个著名的例子是设备同时出现在 /sys/bus 和 /sys/devices 中。 即使删除目标后，创建的符号链接也将保持不变。 您必须知道何时删除目标，然后删除相应的符号链接。



#### Sysfs文件和属性

现在我们知道，默认文件集是通过 kobjects 和 ksets 中的 ktype 字段以及 kobj_type 的 default_attrs 字段提供的。 在大多数情况下，默认属性就足够了。 但是有时，ktype 的实例可能需要其自己的属性来提供不被更一般的ktype 共享的数据或功能。

只是回顾一下； 用于在默认集合之上添加/删除新属性（或一组属性）的低级函数是：

```c
int sysfs_create_file(struct kobject *kobj, const struct attribute *attr);
void sysfs_remove_file(struct kobject *kobj, const struct attribute *attr);
int sysfs_create_group(struct kobject *kobj, const struct attribute_group *grp);
void sysfs_remove_group(struct kobject * kobj, const struct attribute_group * grp);
```



#### 当前接口
sysfs中当前存在接口层。 除了创建自己的ktype或kobject来添加属性外，还可以使用当前存在的属性：设备，驱动程序，总线和类属性。 它们的描述如下：



##### 设备属性
除了嵌入在设备结构中的kobject提供的默认属性外，您还可以创建自定义属性。 用于此目的的结构是struct device_attribute，它只不过是标准struct属性的包装，以及一组用于显示/存储属性值的回调：

```c
struct device_attribute {
    struct attribute attr;
    ssize_t (*show)(struct device *dev,
                    struct device_attribute *attr,
                    char *buf);
    ssize_t (*store)(struct device *dev,
                     struct device_attribute *attr,
                     const char *buf, size_t count);
};
```

它们的声明是通过 DEVICE_ATTR 宏完成的：

```c
DEVICE_ATTR(_name, _mode, _show, _store);
```

每当使用DEVICE_ATTR声明设备属性时，都会在属性名称中添加前缀 ```dev_attr_```。 例如，如果声明一个_name参数设置为foo的属性，则可以通过```dev_attr_foo```变量名称访问该属性。

要了解原因，让我们看看如何在DEVICE_ATTR宏的定义 include/linux/device.h:

```c
#define DEVICE_ATTR(_name, _mode, _show, _store) \
struct device_attribute dev_attr_##_name = __ATTR(_name, _mode, _show, _store)
```

最后，您可以使用 ```device_create_file``` 和 ```device_remove_file``` 函数添加/删除它们：

```c
int device_create_file(struct device *dev,
                       const struct device_attribute * attr);
void device_remove_file(struct device *dev,
                        const struct device_attribute * attr);
```

下面的示例演示如何将它们组合在一起：

```c
static ssize_t foo_show(struct device *child,
                        struct device_attribute *attr, char *buf)
{
	return sprintf(buf, "%d\n", foo_value);
}

static ssize_t bar_show(struct device *child,
                        struct device_attribute *attr, char *buf)
{
	return sprintf(buf, "%d\n", bar_value);
}
```

这是该属性的静态声明：

```c
static DEVICE_ATTR(foo, 0644, foo_show, NULL);
static DEVICE_ATTR(bar, 0644, bar_show, NULL);
```

以下代码显示了如何在系统上实际创建文件：

```c
if ( device_create_file(dev, &dev_attr_foo) != 0 )
	/* handle error */
if ( device_create_file(dev, &dev_attr_bar) != 0 )
	/* handle error*/
```

对于清理，属性删除是在remove函数中完成的，如下所示：

```c
device_remove_file(wm->dev, &dev_attr_foo);
device_remove_file(wm->dev, &dev_attr_bar);
```

您可能想知道为什么以及为什么我们曾经为相同 kobject/ktype 的所有属性定义了一组 store/show 回调，以及为什么现在为每个属性使用自定义变量。 第一个原因是因为设备子系统定义了自己的属性结构，该属性结构包装了标准的结构。 其次，它不 store/show 属性的值，而是使用container_of宏提取提供通用struct attribute的struct device_attribute，然后根据用户操作执行 show/store 回调。 以下来自drivers / base / core.c的摘录显示了设备kobject的sysfs_ops：

```c
static ssize_t dev_attr_show(struct kobject *kobj,
                             struct attribute *attr,
                             char *buf)
{
    struct device_attribute *dev_attr = to_dev_attr(attr);
    struct device *dev = kobj_to_dev(kobj);
    ssize_t ret = -EIO;
    
    if (dev_attr->show)
    	ret = dev_attr->show(dev, dev_attr, buf);
    if (ret >= (ssize_t)PAGE_SIZE) {
        print_symbol("dev_attr_show: %s returned bad count\n",
                     (unsigned long)dev_attr->show);
    }
    return ret;
}

static ssize_t dev_attr_store(struct kobject *kobj, struct attribute *attr,
                              const char *buf, size_t count)
{
    struct device_attribute *dev_attr = to_dev_attr(attr);
    struct device *dev = kobj_to_dev(kobj);
    ssize_t ret = -EIO;
    
    if (dev_attr->store)
    	ret = dev_attr->store(dev, dev_attr, buf, count);
    return ret;
}

static const struct sysfs_ops dev_sysfs_ops = {
    .show = dev_attr_show,
    .store = dev_attr_store,
};
```

总线（在drivers/base/bus.c中），驱动程序（在drivers/base/bus.c中）和类（在drivers/base/class.c中）属性的原理相同。 他们使用 container_of 宏提取其特定的属性结构，然后调用嵌入其中的 show/store 回调。



##### 总线属性
它们依赖于```struct bus_attribute``` 结构：

```c
struct bus_attribute {
    struct attribute attr;
    ssize_t (*show)(struct bus_type *, char * buf);
    ssize_t (*store)(struct bus_type *, const char * buf, size_t count);
};
```

总线属性使用 BUS_ATTR 宏定义：

```c
BUS_ATTR(_name, _mode, _show, _store)
```

使用 BUS_ATTR 声明的任何总线属性都将在属性变量名称中添加前缀 bus_attr_ ：

```c
#define BUS_ATTR(_name, _mode, _show, _store) \
struct bus_attribute bus_attr_##_name = __ATTR(_name, _mode, _show, _store)
```

它们是使用 ```bus_{create|remove}_file``` 函数创建/删除的：

```c
int bus_create_file(struct bus_type *, struct bus_attribute *);
void bus_remove_file(struct bus_type *, struct bus_attribute *);
```



##### 设备驱动属性

它们依赖于 ```struct driver_attribute``` 结构：

```c
struct driver_attribute {
    struct attribute attr;
    ssize_t (*show)(struct device_driver *, char * buf);
    ssize_t (*store)(struct device_driver *, const char * buf, size_t count);
};
```

其声明依赖于 DRIVER_ATTR 宏，该宏将在属性变量名称前加上DRIVER_ATTR：

```c
DRIVER_ATTR(_name, _mode, _show, _store)
```

其宏的定义如下 ：

```c
#define DRIVER_ATTR(_name, _mode, _show, _store) \
struct driver_attribute driver_attr_##_name = __ATTR(_name, _mode, _show, _store)
```

它们是使用 ```driver_{create|remove}_file``` 函数创建/删除的：

```c
int driver_create_file(struct device_driver *, const struct driver_attribute *);
void driver_remove_file(struct device_driver *, const struct driver_attribute *);
```



##### 类属性

它们依赖于 ```struct class_attribute``` 结构：

```c
struct class_attribute {
    struct attribute attr;
    ssize_t (*show)(struct device_driver *, char * buf);
    ssize_t (*store)(struct device_driver *, const char * buf, size_t count);
};
```

其声明依赖于 CLASS_ATTR 宏 :

```c
CLASS_ATTR(_name, _mode, _show, _store)
```

如宏的定义所示，任何用CLASS_ATTR声明的类属性都将在属性变量名称中添加前缀class_attr_ ：

```c
#define CLASS_ATTR(_name, _mode, _show, _store) \
struct class_attribute class_attr_##_name = __ATTR(_name, _mode, _show, _store)
```

它们是使用 ```class_{create|remove}_file``` 函数创建/删除的：

```c
int class_create_file(struct class *class, const struct class_attribute *attr);
void class_remove_file(struct class *class, const struct class_attribute *attr);
```

> 请注意，device_create_file() ，bus_create_file()，driver_create_file() 和class_create_file() 都对sysfs_create_file() 进行了内部调用。 由于它们都是内核对象，因此它们的结构中嵌入了一个 kobject。 然后将该 kobject 作为参数传递给 sysfs_create_file，如下面的代码所示。

```c
int device_create_file(struct device *dev,
                       const struct device_attribute *attr)
{
    [...]
    error = sysfs_create_file(&dev->kobj, &attr->attr);
    [...]
}

int class_create_file(struct class *cls,
                      const struct class_attribute *attr)
{
    [...]
    error =
    sysfs_create_file(&cls->p->class_subsys.kobj, &attr->attr);
    return error;
}

int bus_create_file(struct bus_type *bus,
                    struct bus_attribute *attr)
{
    [...]
    error =
    sysfs_create_file(&bus->p->subsys.kobj, &attr->attr);
    [...]
}
```





#### 允许sysfs属性文件可轮询

在这里，我们将看到如何不让 CPU 浪费轮询来感知 sysfs 属性数据的可用性。 想法是使用轮询或选择系统调用来等待属性的内容更改。 Neil Brown 和 Greg Kroah-Hartman 创建了使sysfs属性可轮询的补丁。 kobject 管理器（有权访问kobject的驱动程序）必须支持通知，以允许轮询或选择在内容更改时返回（释放）。 能达到该目的的奇幻函数是来自内核的 **sysfs_notify()** ：

```c
void sysfs_notify(struct kobject *kobj, const char *dir, const char *attr)
```

如果 dir 参数为非null，则用于查找包含属性的子目录（可能由sysfs_create_group创建）。 每个属性一个int的成本，每个 kobject 一个 wait_queuehead 的成本，每个打开的文件一个int的成本。

```poll``` 将返回 POLLERR | POLLPRI，而 ```select``` 将返回fd，无论它是在等待读取，写入还是异常。 阻止民意调查来自用户方面。 仅在调整内核属性值之后才应调用 ```sysfs_notify()``` 。

> 可以将```poll()```  ( 或```select()``` )代码视为订阅者，以注意感兴趣的属性的变化，而将 ```sysfs_notify()``` 视为发布者，将任何更改通知给订阅者。

本书随附的以下摘录代码显示了store函数操作属性：

```c
static ssize_t store(struct kobject *kobj, struct attribute *attr,
                     const char *buf, size_t len)
{
    struct d_attr *da = container_of(attr, struct d_attr, attr);
    
    sscanf(buf, "%d", &da->value);
    printk("sysfs_foo store %s = %d\n", a->attr.name, a->value);
    
    if (strcmp(a->attr.name, "foo") == 0){
        foo.value = a->value;
        sysfs_notify(mykobj, NULL, "foo");
    }
    else if(strcmp(a->attr.name, "bar") == 0){
        bar.value = a->value;
        sysfs_notify(mykobj, NULL, "bar");
    }
    
    return sizeof(int);
}
```

用户空间中的代码必须具有以下行为才能感知数据更改：

1. 打开文件属性。
2. 虚拟读取所有内容。
3. 呼叫轮询以请求POLLERR | POLLPRI（select / exceptfds也起作用）。
4. 当轮询（或选择）返回（指示值已更改）时，请读取其数据已更改的文件的内容。
5. 关闭文件并转到循环顶部。

如果不确定 sysfs 属性是否可轮询，请设置适当的超时值。 用户空间示例随书样本一起提供。



### 摘要

现在，您熟悉LDM的概念及其数据结构（总线，类，设备驱动程序和设备），包括低级数据结构（即kobject，kset和kobj_types）以及属性（或其中的一组） ）。 如何在内核中表示对象（因此是sysfs和设备拓扑）已不再是秘密。 您将能够创建属性（或组），并通过sysfs公开设备或驱动程序功能。 如果您对本主题很清楚，我们将继续进行下一章，第14章，引脚控制和GPIO子系统，该子系统充分利用了sysfs的功能。