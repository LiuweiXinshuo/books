#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/moduleparam.h>

static char *mystr = "hello";
static int myint = 1;
static int myarr[3] = {0, 1, 2};

module_param(myint, int, S_IRUGO);
module_param(mystr, charp, S_IRUGO);
module_param(myarr, int NULL, S_IWUSR | S_IRUSR);

MODULE_PARM_DESC(myint, "this is my int variable");
MODULE_PARM_DESC(mystr, "this is my str point var");
MODULE_PARM_DESC(myarr, "this is my array of int");
MODULE_INFO(my_field_name, "what easy value");

static int __init helloworld_init(void)
{
	printk("Hello world with parameters\n");
	printk("The *mystr param: %s\n", mystr);
	printk("The *myint param: %d\n", myint);
	printk("The *myarr param: %d,%d,%d\n", myarr[0],myarr[1],myarr[2]);
	return 0;
}

static void __exit helloworld_exit(void)
{
	printk("end of the world\n");
}

module_init(helloworld_init);
module_exit(helloworld_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("John");
