#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>

static int __init helloworld_init()
{
	printk("hello world\n");
	return 0;
}

static void __exit helloworld_exit()
{
	printk("end of world\n");
}

module_init(helloworld_init);
module_eixt(helloworld_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("John");