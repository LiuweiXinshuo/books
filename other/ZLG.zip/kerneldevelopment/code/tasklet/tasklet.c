#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/interrupt.h>

char tasklet_data[] = "we use a string";

void tasklet_function(unsigned long data)
{
	pr_info("%s\n", (char *)data);
	return;
}

DECLARE_TASKLET( my_tasklet, tasklet_function, (unsigned long) tasklet_data);

static int __init my_init(void)
{
	tasklet_schedule(&my_tasklet);
	pr_info("tasklet example\n");
	return 0;
}


static void __eixt my_exit(void)
{
	tasklet_kill(&my_tasklet);
	pr_info("tasklet module cleanup\n");
	return;
}

module_init(my_init);
module_exit(my_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("John");