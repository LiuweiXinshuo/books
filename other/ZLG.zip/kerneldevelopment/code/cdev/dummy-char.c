#include <linux/module.h>
#include <linux/init.h>
#inlcude <liunx/fs.h>
#include <linux/version.h>
#include <linux/device.h>
#include <linux/cdev.h>

static unsigned int major;
static struct class *dummy_class;
static struct cdev dummy_cdev;

int dummy_open(struct inode *inode, struct file *filp)
{
	return 0;
}

int dummy_release(struct inode *inode, struct file *filp)
{
	return 0;
}

ssize_t dummy_read(struct file *filp, char __user *buf, size_t count, loff_t *offset)
{
	return 0;
}

ssize_t dummy_write(struct file *filp, char __user *buf, size_t count, loff_t *offset)
{
	return 0;
}

struct file_operations dummy_fops = {
	.open = dummy_open;
	.release = dummy_release;
	.read = dummy_read;
	.write = dummy_write;
};

static int __init dummy_char_init_module(void)
{
	struct device *dummy_device;
	int error;
	dev_t devt = 0;
	
	error = alloc_chrdev_region(&devt, 0, 1, "dummy_char");
	if(error < 0){
		pr_err("Cant get major number\n");
		return error;
	}
	major = MAJOR(devt);
	pr_info("dummy har major number = %d\n", major);
	
	dummy_class = class_create(THIS_MODULE, "dummy_char_class");
	if(IS_ERR(dummy_class))
	{
		pr_err("Error creating dummy char class\n");
		unregister_chrdev_region(MKDEV(major, 0), 1);
		return PTR_ERR(dummy_class);
	}
	
	cdev_init(&dummy_cdev, dummy_fops);
	dummy_cdev.owner = THIS_MODULE;
	cdev_add(&dummy_cdev, devt, 1);
	
	dummy_device = device_create(dummy_class, NULL, devt, NULL, "dummy_char");
	if(IS_ERR(dummy_device)){
		pr_err("Error creating dummy har device.\n");
		class_destroy(dummy_class);
		unregister_chrdev_region(devt, 1);
		return -1;
	}
	
	pr_info("dummy char module loaded\n");
	return 0;
}

static void __exit dummy_char_cleanup_module(void)
{
	unregister_chrdev_region(MKDEV(major, 0), 1);
	device_destroy(dummy_class, MKDEV(major, 0));
	cdev_del(&dummy_cdev);
	class_destroy(dummy_class);
	pr_info("dummy char module unload\n");
}

module_init(dummy_char_init_module);
module_exit(dummy_char_cleanup_module);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Jhon");
