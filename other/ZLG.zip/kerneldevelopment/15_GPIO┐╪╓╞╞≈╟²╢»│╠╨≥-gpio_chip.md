# GPIO控制器驱动程序 - gpio_chip

在上一章中，我们讨论了GPIO线。 这些线通过称为GPIO控制器的特殊设备暴露给系统。 本章将逐步说明如何为此类设备编写驱动程序，从而涵盖以下主题：

* GPIO控制器驱动程序架构和数据结构
* GPIO控制器的Sysfs接口
* 设备树中的GPIO控制器表示



### 驱动程序架构和数据结构

此类设备的驱动程序应提供以下内容：

* 建立GPIO方向（输入和输出）的方法。
* 用于访问GPIO值（获取和设置）的方法。
* 将给定的GPIO映射到IRQ并返回相关编号的方法。
* 表示是否调用其方法的标志可能会休眠。 这个非常重要。
* 可选的 ```debugfs dump``` 方法（显示额外的状态，例如上拉配置）。
* 可选编号，称为基本编号，应从该编号开始GPIO编号。 如果省略，它将被自动分配。

在内核中，GPIO控制器表示为linux / gpio / driver.h中定义的struct gpio_chip实例：

```c
struct gpio_chip {
    const char *label;
    struct device *dev;
    struct module *owner;

    int (*request)(struct gpio_chip *chip, unsigned offset);
    void (*free)(struct gpio_chip *chip, unsigned offset);
    int (*get_direction)(struct gpio_chip *chip, unsigned offset);
    int (*direction_input)(struct gpio_chip *chip, unsigned offset);
    int (*direction_output)(struct gpio_chip *chip, unsigned offset,
                            int value);
    int (*get)(struct gpio_chip *chip,unsigned offset);
    void (*set)(struct gpio_chip *chip, unsigned offset, int value);
    void (*set_multiple)(struct gpio_chip *chip, unsigned long *mask,
                         unsigned long *bits);
    int (*set_debounce)(struct gpio_chip *chip, unsigned offset,
                        unsigned debounce);
    int (*to_irq)(struct gpio_chip *chip, unsigned offset);
    
    int base;
    u16 ngpio;
    const char *const *names;
    bool can_sleep;
    bool irq_not_threaded;
    bool exported;
#ifdef CONFIG_GPIOLIB_IRQCHIP
    /*
    * With CONFIG_GPIOLIB_IRQCHIP we get an irqchip
    * inside the gpiolib to handle IRQs for most practical cases.
    */
    struct irq_chip *irqchip;
    struct irq_domain *irqdomain;
    unsigned int irq_base;
    irq_flow_handler_t irq_handler;
    unsigned int irq_default_type;
#endif
#if defined(CONFIG_OF_GPIO)
    /*
    * If CONFIG_OF is enabled, then all GPIO controllers described in the
    * device tree automatically may have an OF translation
    */
    struct device_node *of_node;
    int of_gpio_n_cells;
    int (*of_xlate)(struct gpio_chip *gc,
    const struct of_phandle_args *gpiospec, u32 *flags);
}
```

以下是结构中每个元素的含义：

* ```request```  是用于特定于芯片的激活的可选挂钩。如果提供的话，只要您调用 ```gpio_request()``` 或```gpiod_get()``` ，它就会在分配 GPIO 之前执行。
* ```free``` 是一个可选的挂钩，用于特定于芯片的停用。如果提供了该函数，则无论何时调用 ```gpiod_put()``` 或```gpio_free()``` ，都会在释放GPIO之前执行该命令。
* ```get_direction``` 用于获取 GPIO 输出的方向。返回值应为0表示输出，返回值为1表示输入（与GPIOF_DIR_XXX 相同）或 负错误。
* ```direction_input``` 将信号传输方向配置为输入，或者返回错误。
* ```get``` 获取 GPIO 的输入值；对于输出信号，这将返回实际检测到的值或零。
* ```set``` 将输出值输出给 GPIO 输出方向。
* ```set_multiple``` 用于定义多个输出信号定义输出值。如果未提供，内核将安装通用钩子，该钩子将遍历掩码位并在每个位集上执行 chip->set(i)。

请参见以下代码，该代码显示了如何实现此功能：

```c
static void gpio_chip_set_multiple(struct gpio_chip *chip,
                                   unsigned long *mask, unsigned long *bits)
{
    if (chip->set_multiple) {
    	chip->set_multiple(chip, mask, bits);
    } else {
        unsigned int i;
        /* set outputs if the corresponding mask bit is set */
        for_each_set_bit(i, mask, chip->ngpio)
        chip->set(chip, i, test_bit(i, bits));
    }
}
```

* ```set_debounce```（如果控制器支持），此挂钩是提供的可选回调，用于设置指定GPIO的去抖动时间。
* ```to_irq``` 是一个可选的挂钩，用于提供GPIO到IRQ的映射。每当您要执行 ```gpio_to_irq()``` 或 ```gpiod_to_irq()``` 函数时，都会调用此方法。此实现可能无法休眠。
* ```base``` 标识此芯片处理的第一个GPIO编号；或者，如果在注册期间为负，则内核将自动（动态）分配一个。
* ```ngpio``` 是此控制器提供的GPIO数量；它从 base 开始到（base + ngpio-1）。
* ```name``` （如果已设置）必须是字符串数组，以用作该芯片中GPIO的备用名称。数组必须为 ngpio 大小，并且不需要别名的任何GPIO都可以在数组中将其条目设置为NULL。
* ```can_sleep``` 是一个bool值的标志位，用于指示 ```get()/set()```  函数是否可以休眠。位于总线（例如I2C或SPI）上的GPIO控制器（也称为扩展器）就是这种情况，其访问可能导致睡眠。这意味着，如果芯片支持IRQ，则需要对这些IRQ进行线程化，例如在读取IRQ状态寄存器时，芯片访问可能会休眠。对于映射到内存（SoC的一部分）的GPIO控制器，可以将其设置为false。
* ```irq_not_threaded``` 是一个布尔型标志，如果设置了can_sleep，则必须设置 irq_not_threaded，但是不需要对IRQ进行线程化。

> 每个芯片都公开许多信号，这些信号在方法调用中由0（ngpio-1）范围内的偏移值标识。 当通过诸如gpio_get_value(gpio) 之类的调用引用这些信号时，通过从GPIO编号中减去基数来计算偏移量。



在定义了每个回调并设置了其他字段之后，应在已配置的 struct gpio_chip 结构上调用 ```gpiochip_add()``` 以便向内核注册控制器。 关于注销，请使用 ```gpiochip_remove()``` 。 就这些。 您可以看到编写自己的GPIO控制器驱动程序有多么容易。 在书籍资源库中，您会找到来自微芯片的适用于MCP23016 I2C I/O 扩展器的 GPIO控制器驱动程序，其数据手册可从http://ww1.microchip.com/downloads/en/DeviceDoc/20090C.pdf 获取。

要编写此类驱动程序，您应包括：

```c
#include <linux/gpio.h>
```

以下是我们为控制器编写的驱动程序的摘录，目的只是向您展示编写GPIO控制器驱动程序的任务有多容易：

```c
#define GPIO_NUM 16
struct mcp23016 {
    struct i2c_client *client;
    struct gpio_chip chip;
};

static int mcp23016_probe(struct i2c_client *client,
                          const struct i2c_device_id *id)
{
    struct mcp23016 *mcp;
    if (!i2c_check_functionality(client->adapter, I2C_FUNC_SMBUS_BYTE_DATA))
    	return -EIO;
    
    mcp = devm_kzalloc(&client->dev, sizeof(*mcp), GFP_KERNEL);
    if (!mcp)
    	return -ENOMEM;
    
    mcp->chip.label = client->name;
    mcp->chip.base = -1;
    mcp->chip.dev = &client->dev;
    mcp->chip.owner = THIS_MODULE;
    mcp->chip.ngpio = GPIO_NUM; /* 16 */
    mcp->chip.can_sleep = 1; /* may not be accessed from atomic context */
    mcp->chip.get = mcp23016_get_value;
    mcp->chip.set = mcp23016_set_value;
    mcp->chip.direction_output = mcp23016_direction_output;
    mcp->chip.direction_input = mcp23016_direction_input;
    mcp->client = client;
    i2c_set_clientdata(client, mcp);
    
    return gpiochip_add(&mcp->chip);
}
```

要从控制器驱动程序中请求一个自有的 GPIO，请勿使用 ```gpio_request()```  。 GPIO驱动程序可以使用以下函数代替请求和释放描述符，而无需永远固定在内核上：

```c
struct gpio_desc *gpiochip_request_own_desc(struct gpio_desc *desc, const char *label)
void gpiochip_free_own_desc(struct gpio_desc *desc)
```

使用 ```gpiochip_request_own_desc()``` 请求的描述符必须与 ```gpiochip_free_own_desc()``` 配合释放。



#### 引脚控制器准则

根据编写驱动程序的控制器的不同，您可能需要实施引脚控制操作以处理引脚多路复用，配置等：

* 对于只能执行简单GPIO的引脚控制器，简单的struct gpio_chip就足以处理它。 无需设置struct pinctrl_desc结构。 只需编写GPIO控制器驱动程序即可。
* 如果控制器可以在GPIO功能的基础上生成中断，则必须设置irq_chip结构并将其注册到IRQ子系统。
* 对于具有引脚多路复用，高级引脚驱动器强度和复杂偏置的控制器，您应该设置以下三个接口：
  * 本章前面讨论的 struct gpio_chip
  * 下一章（第16章，高级IRQ管理）中讨论了struct irq_chip。
  * struct pinctrl_desc，在本书中没有讨论，但是在 Documentation/pinctrl.txt 中的内核文档中有很好的解释



#### GPIO控制器的Sysfs接口

成功执行 ```gpiochip_add()``` 时，将创建带有 /sys/class/gpio/gpiochipX/ 等路径的目录条目，其中X是GPIO控制器库（该控制器提供从#X开始的GPIO），具有以下属性：

* base，其值与X相同，并且对应于 gpio_chip.base（如果已静态分配），并且是此芯片管理的第一个GPIO。
* label，用于诊断（并非总是唯一的）。
* ngpio，它告诉该控制器提供了多少个GPIO（从N到N + ngpio-1）。 这与gpio_chip.ngpios中定义的相同。

前面所有的属性都是只读的。



#### GPIO控制器和DT

在DT中声明的每个GPIO控制器都必须设置布尔属性gpiocontroller。 某些控制器提供映射到GPIO的IRQ。 在这种情况下，还应该设置interrupt-cells属性。 通常您使用2，但这取决于需要。 第一个单元格是引脚号，第二个单元格是中断标志。

应该设置gpio-cells以识别用于描述GPIO说明符的单元数。 通常使用<2>，第一个单元格用于标识GPIO号，第二个单元格用于标志。 实际上，大多数非内存映射的GPIO控制器都不使用标志：

```dtd
expander_1: mcp23016@27 {
    compatible = "microchip,mcp23016";
    interrupt-controller;
    gpio-controller;
    #gpio-cells = <2>;
    interrupt-parent = <&gpio6>;
    interrupts = <31 IRQ_TYPE_LEVEL_LOW>;
    reg = <0x27>;
    #interrupt-cells=<2>;
};
```

前面的示例是我们的 GPIO控制器设备的节点，完整的设备驱动程序随源手册一起提供。



### 摘要

本章不仅仅是为您可能遇到的任何GPIO控制器编写驱动程序的基础； 它说明了此类设备的主要结构。 下一章介绍高级IRQ管理，在其中我们将了解如何管理中断控制器，以及如何在微芯片的MCP23016扩展器的驱动器中添加此类功能。

