# IIO框架

工业 I/O（IIO）是专用于模数转换器（ADC）和数模转换器（DAC）的内核子系统。 随着越来越多的传感器（具有模拟到数字或数字到模拟功能的测量设备）在内核源上散布着不同的代码实现，收集它们变得很有必要。 这是IIO 框架以通用且同质的方式进行的。 自2009年以来，Jonathan Cameron和Linux IIO社区一直在开发它。

加速度计，陀螺仪，电流/电压测量芯片，光传感器，压力传感器等都属于IIO系列设备。

IIO模型基于设备和通道架构：

* 设备代表芯片本身。 它是层次结构的顶层。
* 通道代表设备的一条采集线。 一台设备可能具有一个或多个通道。 例如，加速度计是具有三个通道的设备，每个轴一个（X，Y和Z）。

IIO芯片是物理和硬件传感器/转换器。 它作为字符设备（支持触发缓冲）和一个sysfs目录条目（包含一组文件，其中一些代表通道）显示给用户空间。 单个通道由单个sysfs文件条目表示。

这是从用户空间与IIO驱动程序进行交互的两种方法：

* /sys/bus/iio/iio:deviceX/ ：它代表传感器及其通道
* /dev/iio:deviceX ：这是一个字符设备，可导出设备的事件和数据缓冲区

<img src="./images/10_1.png" alt="image" style="zoom:80%;" />



上图显示了如何在内核和用户空间之间组织IIO框架。 驱动程序使用IIO核心公开的一组功能和API管理硬件并向IIO核心报告处理。 然后，IIO子系统通过sysfs接口和字符设备将整个底层机制抽象到用户空间，在此之上用户可以执行系统调用。

IIO API分布在几个头文件中，如下所示：

```c
#include <linux/iio/iio.h> /* mandatory */
#include <linux/iio/sysfs.h> /* mandatory since sysfs is used */
#include <linux/iio/events.h> /* For advanced users, to manage iio events */
#include <linux/iio/buffer.h> /* mandatory to use triggered buffers */
#include <linux/iio/trigger.h>/* Only if you implement trigger in your driver (rarely used)*/
```

在本章中，我们将描述和处理IIO框架的每个概念，包括：

* 遍历其数据结构（设备，通道等）
* 触发的缓冲区支持和连续捕获及其sysfs接口
* 探索现有的IIO触发器
* 以单次模式或连续模式捕获数据
* 列出可帮助开发人员测试其设备的可用工具



### IIO数据结构

IIO设备在内核中表示为 ```struct iio_dev``` 的实例，并由 ```struct iio_info``` 结构描述。 所有重要的IIO结构都在include/linux/iio/iio.h 中定义。



#### iio_dev结构

该结构表示IIO设备，描述了设备和驱动程序。 它告诉我们：

* 设备上有多少个可用频道
* 设备可以在哪些模式下操作：单次触发缓冲器
* 该驱动程序有哪些钩子可用

```c
struct iio_dev {
    [...]
    int modes;
    int currentmode;
    struct device dev;
    
    struct iio_buffer *buffer;
    int scan_bytes;
    
    const unsigned long *available_scan_masks;
    const unsigned long *active_scan_mask;
    bool scan_timestamp;
    struct iio_trigger *trig;
    struct iio_poll_func *pollfunc;
    
    struct iio_chan_spec const *channels;
    int num_channels;
    const char *name;
    const struct iio_info *info;
    const struct iio_buffer_setup_ops *setup_ops;
    struct cdev chrdev;
};
```

完整的结构在 IIO 头文件中定义。 我们不感兴趣的字段在此处删除：

* ```modes``` ：这表示设备支持的不同模式。 支持的模式有：
  * ```INDIO_DIRECT_MODE```：表示设备提供sysfs类型的接口。
  * ```INDIO_BUFFER_TRIGGERED``` : 表示设备支持硬件触发器。 使用 ```iio_triggered_buffer_setup()``` 函数设置触发缓冲区时，此模式会自动添加到设备中。
  * ```INDIO_BUFFER_HARDWARE``` : 显示设备具有硬件缓冲区。
  * ```INDIO_ALL_BUFFER_MODES``` : 是前两个的并集。

* ```currentmode``` ：代表设备实际使用的模式。
* ```dev``` ：这表示IIO设备绑定到的struct设备（根据Linux设备模型）。

* ```buffer``` ：这是您的数据缓冲区，在使用触发缓冲区模式时被推送到用户空间。 当您使用```iio_triggered_buffer_setup```函数启用触发缓冲区支持时，它会自动分配并关联到您的设备。

* ```scan_bytes``` ：这是捕获的要馈送到缓冲区的字节数。 从用户空间使用触发缓冲区时，缓冲区的大小至少应为 indio-> scan_bytes 个字节。

* ```available_scan_masks``` ：这是允许的位掩码的可选数组。 使用触发缓冲区时，可以启用通道并捕获到IIO缓冲区中。 如果不想允许启用某些通道，则应仅在允许的通道中填充此数组。 以下是为加速度计（具有X，Y和Z通道）提供扫描掩码的示例：

  ```c
  /*
  * Bitmasks 0x7 (0b111) and 0 (0b000) are allowed.
  * It means one can enable none or all of them.
  * one can't for example enable only channel X and Y
  */
  static const unsigned long my_scan_masks[] = {0x7, 0};
  indio_dev->available_scan_masks = my_scan_masks;
  ```

* ```active_scan_mask``` ：这是已启用通道的位掩码。仅应将那些通道中的数据推入缓冲区。例如，对于一个八通道ADC转换器，如果仅启用前（0），第三（2）和最后（7）个通道，则位掩码将为0b10000101（0x85）。 active_scan_mask将设置为0x85。然后，驱动程序可以使用for_each_set_bit宏遍历每个设置位，根据通道获取数据，并填充缓冲区。

* ```scan_timestamp``` ：告诉我们是否将捕获时间戳记推送到缓冲区中。如果为true，则时间戳将被推入缓冲区的最后一个元素。时间戳为8个字节（64位）。

* ```trig``` ：这是当前的设备触发器（支持缓冲模式时）。

* ```pollfunc``` ：这是在接收到的触发器上运行的函数。

* ```channels``` ：这表示表通道规范结构，以描述设备具有的每个通道。

* ```num_channels``` ：这表示在通道中指定的通道数。

* ```name``` ：代表设备名称。

* ```info``` ：来自驱动程序的回调和常量信息。

* ```setup_ops``` ：启用/禁用缓冲区前后要调用的一组回调函数。 此结构在 include/linux/iio/iio.h 中定义，如下所示：

  ```c
  struct iio_buffer_setup_ops {
      int (* preenable) (struct iio_dev *);
      int (* postenable) (struct iio_dev *);
      int (* predisable) (struct iio_dev *);
      int (* postdisable) (struct iio_dev *);
      bool (* validate_scan_mask) (struct iio_dev *indio_dev,
                                   const unsigned long *scan_mask);
  };
  ```

* ```setup_ops``` ：如果未指定此选项，则IIO内核将使用定义在```drivers/iio/buffer/industrialio-triggered-buffer.c.``` 中的默认 ```iio_triggered_buffer_setup_ops``` 函数

* ```chrdev``` ：这是由IIO核心创建的关联字符设备

用于为IIO设备分配内存的函数是 ```iio_device_alloc()``` ：

```c
struct iio_dev *devm_iio_device_alloc(struct device *dev, int sizeof_priv)
```

dev 是为其分配 iio_dev 的设备，sizeof_priv 是用于为任何私有结构分配的内存空间。 这样，传递每个设备（私有）的数据结构非常简单。 如果分配失败，该函数将返回NULL：

```c
struct iio_dev *indio_dev;
struct my_private_data *data;
indio_dev = iio_device_alloc(sizeof(*data));
if (!indio_dev)
	return -ENOMEM;
/*data is given the address of reserved memory for private data */
data = iio_priv(indio_dev);
```

分配IIO设备内存后，下一步是填充不同的字段。 完成后，您必须使用 ```iio_device_register``` 函数向IIO子系统注册设备：

```c
int iio_device_register(struct iio_dev *indio_dev)
```

执行此功能后，设备将准备好接受来自用户空间的请求。 反向操作（通常在发布功能中完成）是 ```iio_device_unregister()``` ：

```c
void iio_device_unregister(struct iio_dev *indio_dev)
```

取消注册后，可以使用 ```iio_device_free``` 释放由 iio_device_alloc 分配的内存：

```c
void iio_device_free(struct iio_dev *iio_dev)
```

给定IIO设备作为参数，您可以通过以下方式检索私有数据：

```c
struct my_private_data *the_data = iio_priv(indio_dev);
```



#### iio_info结构

struct iio_info 结构用于声明IIO内核使用的挂钩函数，以便读取/写入通道/属性值：

```c
struct iio_info {
    struct module *driver_module;
    const struct attribute_group *attrs;

    int (*read_raw)(struct iio_dev *indio_dev,
                    struct iio_chan_spec const *chan,
                    int *val, int *val2, long mask);

    int (*write_raw)(struct iio_dev *indio_dev,
                     struct iio_chan_spec const *chan,
                     int val, int val2, long mask);
    [...]
};
```

我们不感兴趣的字段已被删除：

* ```driver_module``` ：这是用于确保正确拥有chrdevs的模块结构，通常设置为THIS_MODULE。
* ```attrs``` ：代表设备的属性。
* ```read_raw``` ：这是用户读取设备的 sysfs 文件属性时的回调运行。 mask 参数是一个位掩码，可让我们知道请求的是哪种类型的值。 channel 参数使我们知道有关的信道。 它可以是采样频率，用于将原始值转换为可用值的标度或原始值本身。
* ```write_raw``` ：这是用于将值写入设备的回调。 例如，您可以使用它来设置采样频率。

以下代码显示了如何设置struct iio_info结构：

```c
static const struct iio_info iio_dummy_info = {
    .driver_module = THIS_MODULE,
    .read_raw = &iio_dummy_read_raw,
    .write_raw = &iio_dummy_write_raw,
[...]
    
/*
* Provide device type specific interface functions and
* constant data.
*/
indio_dev->info = &iio_dummy_info;
```



#### IIO通道

通道代表一条采集线。 加速度计将具有例如三个通道（X，Y，Z），因为每个轴代表一条采集线。```struct iio_chan_spec``` 是表示和描述内核中单个通道的结构：

```c
struct iio_chan_spec {
    enum iio_chan_type type;
    int channel;
    int channel2;
    unsigned long address;
    int scan_index;
    struct {
        charsign;
        u8 realbits;
        u8 storagebits;
        u8 shift;
        u8 repeat;
        enum iio_endian endianness;
    } scan_type;
    long info_mask_separate;
    long info_mask_shared_by_type;
    long info_mask_shared_by_dir;
    long info_mask_shared_by_all;
    const struct iio_event_spec *event_spec;
    unsigned int num_event_specs;
    const struct iio_chan_spec_ext_info *ext_info;
    const char *extend_name;
    const char *datasheet_name;
    unsigned modified:1;
    unsigned indexed:1;
    unsigned output:1;
    unsigned differential:1;
};
```

以下是结构中每个元素的含义：

* ```type``` ：这指定通道进行的测量类型。如果进行电压测量，则应为IIO_VOLTAGE。对于光传感器，它是IIO_LIGHT。对于加速度计，使用IIO_ACCEL。所有可用的类型都在include / uapi / linux / iio / types.h中定义为枚举iio_chan_type。要为给定的转换器编写驱动程序，请查看该文件以查看每个通道所属的类型。
* ```channel``` ：当.indexed设置为1时，它指定通道索引。
* ```channel2``` ：当.modified设置为1时，它指定通道修饰符。
* ```modified``` ：这指定是否将修饰符应用于此通道属性名称。在这种情况下，修改器设置为.channel2。 （例如，IIO_MOD_X，IIO_MOD_Y，IIO_MOD_Z是围绕xyz轴的轴向传感器的修改器。）可用的修改器列表在内核IIO标头中定义为枚举 iio_modifier。修饰符仅破坏sysfs中的通道属性名称，而不破坏值。
* ```indexed``` ：指定通道属性名称是否具有索引。如果是，则在.channel字段中指定索引。
* ```scan_index``` 和 ```scan_type``` ：使用缓冲区触发器时，这些字段用于标识缓冲区中的元素。 scan_index设置捕获的通道在缓冲区内的位置。具有较低scan_index的通道将放置在具有较高索引的通道之前。将.scan_index设置为-1将防止通道缓冲捕获（即，在scan_elements目录中没有条目时）。

暴露给用户空间的通道sysfs属性以位掩码的形式指定。 根据它们的共享信息，可以将属性设置为以下掩码之一：

* ```info_mask_separate``` 将属性标记为特定于此通道。
* ```info_mask_shared_by_type``` 将属性标记为由相同类型的所有通道共享。 导出的信息由相同类型的所有通道共享。
* ```info_mask_shared_by_dir``` 将属性标记为由同一方向的所有通道共享。 导出的信息由相同方向的所有通道共享。

* ```info_mask_shared_by_all``` 将属性标记为所有通道共享，无论其类型或方向如何。 导出的信息由所有渠道共享。 枚举这些属性的位掩码都在 include/linux/iio/iio.h 中定义：

  ```c
  enum iio_chan_info_enum {
      IIO_CHAN_INFO_RAW = 0,
      IIO_CHAN_INFO_PROCESSED,
      IIO_CHAN_INFO_SCALE,
      IIO_CHAN_INFO_OFFSET,
      IIO_CHAN_INFO_CALIBSCALE,
      [...]
      IIO_CHAN_INFO_SAMP_FREQ,
      IIO_CHAN_INFO_FREQUENCY,
      IIO_CHAN_INFO_PHASE,
      IIO_CHAN_INFO_HARDWAREGAIN,
      IIO_CHAN_INFO_HYSTERESIS,
      [...]
  };
  ```

字节序字段应为以下之一：

```c
enum iio_endian {
    IIO_CPU,
    IIO_BE,
    IIO_LE,
};
```



#### 通道属性命名约定

属性名称由IIO内核自动生成，格式为 ```{direction}_{type}_{index}_{modifier}_{info_mask}``` ：

* ```direction``` 对应于 direction 属性，通过drivers/iio/industrialio-core.c 文件的 struct
  iio_direction 结构定义：

  ```c
  static const char * const iio_direction[] = {
      [0] = "in",
      [1] = "out",
  };
  ```

* ```type``` 对应于通道类型，通过 char 数组const iio_chan_type_name_spec 定义：

  ```c
  static const char * const iio_chan_type_name_spec[] = {
      [IIO_VOLTAGE] = "voltage",
      [IIO_CURRENT] = "current",
      [IIO_POWER] = "power",
      [IIO_ACCEL] = "accel",
      [...]
      [IIO_UVINDEX] = "uvindex",
      [IIO_ELECTRICALCONDUCTIVITY] = "electricalconductivity",
      [IIO_COUNT] = "count",
      [IIO_INDEX] = "index",
      [IIO_GRAVITY] = "gravity",
  };
  ```

* ```index``` 模式取决于是否设置了通道的 .indexed 字段。 如果设置，则将从.channel字段中获取索引，以替换{index}模式。

* ```modifier``` 模式取决于是否设置了通道的 .modified 字段。 如果设置，则修饰符将从.channel2字段获取，{modifier} 模式将根据 char数组struct iio_modifier_names 结构进行替换：

  ```c
  static const char * const iio_modifier_names[] = {
      [IIO_MOD_X] = "x",
      [IIO_MOD_Y] = "y",
      [IIO_MOD_Z] = "z",
      [IIO_MOD_X_AND_Y] = "x&y",
      [IIO_MOD_X_AND_Z] = "x&z",
      [IIO_MOD_Y_AND_Z] = "y&z",
      [...]
      [IIO_MOD_CO2] = "co2",
      [IIO_MOD_VOC] = "voc",
  };
  ```

* ```info_mask``` 取决于通道信息掩码（私有或共享），索引char数组 iio_chan_info_postfix 中的值：

  ```c
  /* relies on pairs of these shared then separate */
  static const char * const iio_chan_info_postfix[] = {
      [IIO_CHAN_INFO_RAW] = "raw",
      [IIO_CHAN_INFO_PROCESSED] = "input",
      [IIO_CHAN_INFO_SCALE] = "scale",
      [IIO_CHAN_INFO_CALIBBIAS] = "calibbias",
      [...]
      [IIO_CHAN_INFO_SAMP_FREQ] = "sampling_frequency",
      [IIO_CHAN_INFO_FREQUENCY] = "frequency",
      [...]
  };
  ```



#### 区分通道

每个通道类型有多个数据通道时，您可能会遇到麻烦。 难题是如何识别它们。 有两种解决方案：索引和修饰符。

**使用索引**：给定ADC设备具有一条通道线，则不需要索引。 其渠道定义为：

```c
static const struct iio_chan_spec adc_channels[] = {
    {
        .type = IIO_VOLTAGE,
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
    },
}
```

前一个通道产生的属性名称为 in_voltage_raw：/sys/bus/iio/iio:deviceX/in_voltage_raw

现在，假设转换器具有四个甚至八个通道。 我们如何识别它们？ 解决方案是使用索引。 将 .indexed 字段设置为1将会破坏通道属性名称，而 .channel 值将替换{index}模式：

```c
static const struct iio_chan_spec adc_channels[] = {
    {
        .type = IIO_VOLTAGE,
        .indexed = 1,
        .channel = 0,
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
    },
    {
        .type = IIO_VOLTAGE,
        .indexed = 1,
        .channel = 1,
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
    },
    {
        .type = IIO_VOLTAGE,
        .indexed = 1,
        .channel = 2,
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
    },
    {
        .type = IIO_VOLTAGE,
        .indexed = 1,
        .channel = 3,
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
    },
}
```

通道属性结果为：

```shell
/sys/bus/iio/iio:deviceX/in_voltage0_raw
/sys/bus/iio/iio:deviceX/in_voltage1_raw
/sys/bus/iio/iio:deviceX/in_voltage2_raw
/sys/bus/iio/iio:deviceX/in_voltage3_raw
```



**使用修饰符**：给定一个具有两个通道的光传感器，一个用于红外光，一个用于红外和可见光，没有索引或修饰符，则属性名称为 in_intensity_raw。 在这里使用索引可能容易出错，因为拥有 in_intensity0_ir_raw 和 in_intensity1_ir_raw 没有意义。 使用修饰符将有助于提供有意义的属性名称。 通道的定义如下所示：

```c
static const struct iio_chan_spec mylight_channels[] = {
    {
        .type = IIO_INTENSITY,
        .modified = 1,
        .channel2 = IIO_MOD_LIGHT_IR,
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
        .info_mask_shared = BIT(IIO_CHAN_INFO_SAMP_FREQ),
    },
    {
        .type = IIO_INTENSITY,
        .modified = 1,
        .channel2 = IIO_MOD_LIGHT_BOTH,
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
        .info_mask_shared = BIT(IIO_CHAN_INFO_SAMP_FREQ),
    },
    {
        .type = IIO_LIGHT,
        .info_mask_separate = BIT(IIO_CHAN_INFO_PROCESSED),
        .info_mask_shared = BIT(IIO_CHAN_INFO_SAMP_FREQ),
    },
}
```

结果属性将是：

* ```/sys/bus/iio/iio:deviceX/in_intensity_ir_raw``` 用于通道，测量IR强度
* ```/sys/bus/iio/iio:deviceX/in_intensity_both_raw``` 用于通道，同时测量红外光和可见光
* ```/sys/bus/iio/iio:deviceX/in_illuminance_input``` 用于处理的数据
* ```/sys/bus/iio/iio:deviceX/sampling_frequency``` 为所有共享的采样频率

这也适用于加速度计，我们将在案例研究中进一步了解。 现在，让我们总结一下到目前为止在虚拟 IIO驱动程序中讨论过的内容。



### 放在一起

让我们总结一下到目前为止在一个简单的虚拟驱动器中看到的内容，该驱动器将暴露四个电压通道。 我们将忽略read() 和 write() 函数：

```c
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/platform_device.h>
#include <linux/interrupt.h>
#include <linux/of.h>
#include <linux/iio/iio.h>
#include <linux/iio/sysfs.h>
#include <linux/iio/events.h>
#include <linux/iio/buffer.h>

#define FAKE_VOLTAGE_CHANNEL(num) \
    { \
        .type = IIO_VOLTAGE, \
        .indexed = 1, \
        .channel = (num), \
        .address = (num), \
        .info_mask_separate = BIT(IIO_CHAN_INFO_RAW), \
        .info_mask_shared_by_type = BIT(IIO_CHAN_INFO_SCALE) \
    }

struct my_private_data {
    int foo;
    int bar;
    struct mutex lock;
};

static int fake_read_raw(struct iio_dev *indio_dev,
                         struct iio_chan_spec const *channel, int *val,
                         int *val2, long mask)
{
	return 0;
}

static int fake_write_raw(struct iio_dev *indio_dev,
                          struct iio_chan_spec const *chan,
                          int val, int val2, long mask)
{
	return 0;
}

static const struct iio_chan_spec fake_channels[] = {
    FAKE_VOLTAGE_CHANNEL(0),
    FAKE_VOLTAGE_CHANNEL(1),
    FAKE_VOLTAGE_CHANNEL(2),
    FAKE_VOLTAGE_CHANNEL(3),
};

static const struct of_device_id iio_dummy_ids[] = {
    { .compatible = "packt,iio-dummy-random", },
    { /* sentinel */ }
};

static const struct iio_info fake_iio_info = {
    .read_raw = fake_read_raw,
    .write_raw = fake_write_raw,
    .driver_module = THIS_MODULE,
};

static int my_pdrv_probe (struct platform_device *pdev)
{
    struct iio_dev *indio_dev;
    struct my_private_data *data;
    
    indio_dev = devm_iio_device_alloc(&pdev->dev, sizeof(*data));
    if (!indio_dev) {
        dev_err(&pdev->dev, "iio allocation failed!\n");
        return -ENOMEM;
	}
    
    data = iio_priv(indio_dev);
    mutex_init(&data->lock);
    indio_dev->dev.parent = &pdev->dev;
    indio_dev->info = &fake_iio_info;
    indio_dev->name = KBUILD_MODNAME;
    indio_dev->modes = INDIO_DIRECT_MODE;
    indio_dev->channels = fake_channels;
    indio_dev->num_channels = ARRAY_SIZE(fake_channels);
    indio_dev->available_scan_masks = 0xF;
    
    iio_device_register(indio_dev);
    platform_set_drvdata(pdev, indio_dev);
    return 0;
}

static void my_pdrv_remove(struct platform_device *pdev)
{
    struct iio_dev *indio_dev = platform_get_drvdata(pdev);
    iio_device_unregister(indio_dev);
}

static struct platform_driver mypdrv = {
    .probe = my_pdrv_probe,
    .remove = my_pdrv_remove,
    .driver = {
        .name = "iio-dummy-random",
        .of_match_table = of_match_ptr(iio_dummy_ids),
        .owner = THIS_MODULE,
    },
};

module_platform_driver(mypdrv);
MODULE_AUTHOR("John Madieu <john.madieu@gmail.com>");
MODULE_LICENSE("GPL");
```

加载此模块后，我们将获得以下输出，显示我们的设备确实与我们已注册的平台设备相对应：

```shell
~# ls -l /sys/bus/iio/devices/
lrwxrwxrwx 1 root root 0 Jul 31 20:26 iio:device0 ->
../../../devices/platform/iio-dummy-random.0/iio:device0
lrwxrwxrwx 1 root root 0 Jul 31 20:23 iio_sysfs_trigger ->
../../../devices/iio_sysfs_trigger
```

以下清单显示了此设备具有的通道及其名称，它们与我们在驱动程序中描述的内容完全对应：

```shell
~# ls /sys/bus/iio/devices/iio\:device0/
dev in_voltage2_raw name uevent
in_voltage0_raw in_voltage3_raw power
in_voltage1_raw in_voltage_scale subsystem
~# cat /sys/bus/iio/devices/iio:device0/name
iio_dummy_random
```



### 触发缓冲区支持

在许多数据分析应用程序中，能够基于某些外部信号（触发）捕获数据非常有用。 这些触发器可能是：
数据就绪信号

* 连接到某个外部系统（GPIO或其他东西）的IRQ线
* 处理器上的定期中断
* 用户空间在sysfs中读取/写入特定文件

IIO设备驱动程序与触发器完全无关。 触发器可以初始化一个或多个设备上的数据捕获。 这些触发器用于填充缓冲区，这些缓冲区作为字符设备暴露给用户空间。

您可以开发自己的触发器驱动程序，但这超出了本书的范围。 我们将尝试仅关注现有的内容。 这些是：

* iio-trig-interrupt：这提供了将任何IRQ用作IIO触发器的支持。 在旧的内核版本中，它以前是iio-trig-gpio。 启用此触发模式的内核选项为CONFIG_IIO_INTERRUPT_TRIGGER。 如果构建为模块，则该模块将称为iio-trig-interrupt。
* iio-trig-hrtimer：这提供了一个基于频率的IIO触发器，使用HRT作为中断源（自内核v4.5起）。 在较早的内核版本中，它以前是iio-trig-rtc。 负责此触发模式的内核选项是IIO_HRTIMER_TRIGGER。 如果构建为模块，则该模块将称为iiotrig-hrtimer。
* iio-trig-sysfs：这使我们可以使用sysfs条目触发数据捕获。 CONFIG_IIO_SYSFS_TRIGGER是用于添加对此触发模式的支持的内核选项。
* iio-trig-bfin-timer：这使我们可以将Blackfin定时器用于IIO触发（仍处于暂存状态）。

IIO公开了API，因此我们可以：

* 声明任意给定数量的触发器
* 选择将哪些通道的数据推入缓冲区

当您的IIO设备提供对触发器缓冲区的支持时，您必须设置iio_dev.pollfunc，该触发器在触发器触发时执行。 该处理程序负责通过indio_dev-> active_scan_mask查找启用的通道，检索其数据，并使用iio_push_to_buffers_with_timestamp 函数将其馈入 indio_dev-> buffer。 因此，缓冲区和触发器在IIO子系统中连接非常紧密。

IIO核心提供了一组帮助器函数来设置触发的缓冲区，您可以在driver / iio / industrialio-triggered-buffer.c中找到该缓冲区。

以下是从驱动程序内部支持触发缓冲区的步骤：

1. 如果需要，填充一个iio_buffer_setup_ops结构：

   ```c
   const struct iio_buffer_setup_ops sensor_buffer_setup_ops = {
       .preenable = my_sensor_buffer_preenable,
       .postenable = my_sensor_buffer_postenable,
       .postdisable = my_sensor_buffer_postdisable,
       .predisable = my_sensor_buffer_predisable,
   };
   ```

2. 编写与触发器关联的上半部分。 在99％的情况下，您只需要提供与捕获相关联的时间戳记即可：

   ```c
   irqreturn_t sensor_iio_pollfunc(int irq, void *p)
   {
       pf->timestamp = iio_get_time_ns((struct indio_dev *)p);
       return IRQ_WAKE_THREAD;
   }
   ```

3. 编写触发器的下半部分，它将从每个启用的通道中获取数据，并将其馈送到缓冲区中：

   ```c
   irqreturn_t sensor_trigger_handler(int irq, void *p)
   {
       u16 buf[8];
       int bit, i = 0;
       struct iio_poll_func *pf = p;
       struct iio_dev *indio_dev = pf->indio_dev;
   
       /* one can use lock here to protect the buffer */
       /* mutex_lock(&my_mutex); */
   
       /* read data for each active channel */
       for_each_set_bit(bit, indio_dev->active_scan_mask,
                        indio_dev->masklength)
           buf[i++] = sensor_get_data(bit)
   
       /*
       * If iio_dev.scan_timestamp = true, the capture timestamp
       * will be pushed and stored too, as the last element in the
       * sample data buffer before pushing it to the device buffers.
       */
       iio_push_to_buffers_with_timestamp(indio_dev, buf, timestamp);
   
       /* Please unlock any lock */
       /* mutex_unlock(&my_mutex); */
   
       /* Notify trigger */
       iio_trigger_notify_done(indio_dev->trig);
       return IRQ_HANDLED;
   }
   ```

4. 最后，在 probe 函数中，您必须先设置缓冲区本身，然后才能使用iio_device_register() 注册设备：

   ```c
   iio_triggered_buffer_setup(indio_dev, sensor_iio_polfunc,
                              sensor_trigger_handler,
                              sensor_buffer_setup_ops);
   ```

这里神奇的函数是 ```iio_triggered_buffer_setup``` 。 这还将为您的设备提供 INDIO_DIRECT_MODE 功能。 当触发器（从用户空间）触发到设备时，您将无法知道何时触发捕获。

在连续缓冲捕获处于活动状态时，应避免驱动程序（通过返回错误）执行sysfs每通道数据捕获（由read_raw() 挂钩执行），以避免不确定的行为，因为触发器处理程序和read_raw() 钩子将尝试同时访问设备。 用于检查是否实际使用缓冲模式的函数是iio_buffer_enabled() 。 该钩子将如下所示：

```c
static int my_read_raw(struct iio_dev *indio_dev,
                       const struct iio_chan_spec *chan,
                       int *val, int *val2, long mask)
{
    [...]
    switch (mask) {
    case IIO_CHAN_INFO_RAW:
    	if (iio_buffer_enabled(indio_dev))
    	return -EBUSY;
    [...]
}
```

```iio_buffer_enabled() ``` 函数只是测试是否为给定的IIO设备启用了缓冲区。

让我们描述上一节中使用的一些重要事项：

* iio_buffer_setup_ops提供了在缓冲区配置序列的固定步骤（启用/禁用之前/之后）调用的缓冲区设置功能。 如果未指定，则默认 Iio_triggered_buffer_setup_ops将由IIO内核提供给您的设备。
* sensor_iio_pollfunc 是触发器的上半部分。 与上半部分一样，它在中断上下文中运行，并且必须进行尽可能少的处理。 在99％的情况下，您只需要提供与捕获相关的时间戳即可。 再一次，您可以使用默认的IIO iio_pollfunc_store_time函数。
* sensor_trigger_handler 是下半部分，它在内核线程中运行，使我们能够进行任何处理，包括获取互斥量或睡眠。 繁重的处理应在此处进行。 它通常从设备读取数据，并将其与记录在上半部分的时间戳一起存储在内部缓冲区中，并将其推入IIO设备缓冲区。

> 对于触发的缓冲，必须使用触发器。 它告诉驱动程序何时从设备读取样本并将其放入缓冲区。 编写IIO设备驱动程序不是必须使用触发缓冲。 通过读取通道的原始属性，您也可以通过sysfs使用singleshot捕获，它将仅执行一次转换（对于正在读取的通道属性）。 缓冲模式允许连续转换，因此可以一次捕获多个通道。



#### IIO触发器和sysfs（用户空间）

sysfs中有两个与触发器相关的位置：

* /sys/bus/iio/devices/triggerY/，一旦在IIO内核上注册了IIO触发器并与索引 Y的触发器相对应，就会创建该文件。目录中至少有一个属性：
  * ```name``` ，这是触发器名称，以后可用于与设备关联

* 如果您的设备支持触发的缓冲区，则会自动创建 /sys/bus/iio/devices/iio:deviceX/trigger/* 目录。 您可以通过在 current_trigger 文件中写入触发器的名称来将触发器与我们的设备关联。

