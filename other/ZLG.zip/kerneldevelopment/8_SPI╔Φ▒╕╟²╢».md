# SPI 设备驱动

SPI（串行外围设备接口）（至少）是四线总线：主输入从输出（MISO）、主输出从动输入（MOSI）、串行时钟（SCK）、和片选（CS），用于连接串行闪存 AD/DA 转换器。 主机总是产生时钟。 即使没有实际速度限制，它的速度也可以达到80 MHz（也比 I2C 快得多）。 CS线也是如此，它始终由主站管理。

这些信号名称中的每一个都有一个同义词：

* 每当您看到SIMO，SDI，DI或SDA时，它们就是指MOSI。
* SOMI，SDO，DO和SDA将引用MISO。
* SCK，CLK和SCL将指代SCK。
* S̅S̅是从选择线，也称为CS。 可以使用CSx（其中x是索引，CS0，CS1）； 也可以使用EN和ENB，这意味着启用。 CS通常是低电平有效信号：

<img src="./images/8_1.png" alt="image" style="zoom:100%;" />

本章将介绍SPI驱动程序的概念，例如：

* SPI总线说明
* 驱动程序体系结构和数据结构说明
* 半双工和全双工发送和接收数据
* 从设备树（DT）声明SPI设备
* 从用户空间以半双工和全双工访问SPI设备



### 驱动架构

Linux内核中SPI填充所需的标头是 ```<linux/spi/spi.h>```。 在讨论驱动程序结构之前，让我们看一下如何在内核中定义SPI设备。 SPI设备在内核中表示为spi_device的实例。 管理它们的驱动的实例是 ```struct spi_driver```结构。



#### 设备结构

```struct spi_device``` 结构代表一个SPI设备，并在 ```include/linux/spi/spi.h``` 中定义：

```c
struct spi_device {
    struct devicedev;
    struct spi_master*master;
    u32 max_speed_hz;
    u8 chip_select;
    u8 bits_per_word;
    u16 mode;
    int irq;
    [...]
    int cs_gpio; 		/* chip select gpio */
};
```

一些对我们没有意义的字段已被删除。以下是结构中元素的含义：

* ```master``` ：这表示设备连接到的SPI控制器（总线）。
* ```max_speed_hz``` ：这是此芯片（当前板上）要使用的最大时钟速率；可以从驱动程序内部更改此参数。您可以为每个传输使用 ```spi_transfer.speed_hz``` 覆盖该参数。稍后我们将讨论SPI传输。
* ```chip_select``` ：这使您能够启用需要与之对话的芯片，从而区分由主设备处理的芯片。默认情况下，chip_select设置为低。可以通过添加SPI_CS_HIGH标志在模式下更改此行为。
  模式：这定义了数据应如何计时。设备驱动程序可以更改此设置。默认情况下，对于传输中的每个字，数据时钟优先是最高有效位（MSB）。通过指定SPI_LSB_FIRST可以覆盖此行为。
* ```irq``` ：这代表您应该传递给 ```request_irq()```以便从该设备接收中断的中断号（已在板初始化文件中或通过DT注册为设备资源）。



关于SPI模式的一句话； 它们是使用两个特征构建的：

* CPOL：这是初始时钟极性：
  * 0：初始时钟状态为低电平，并且第一个边沿上升
  * 1：初始时钟状态为高，而第一状态为下降
* CPHA：这是时钟相位，选择在哪个边缘采样数据：
  * 0：数据在下降沿锁存（从高到低过渡），而输出在上升沿变化
  * 1：数据在上升沿锁存（从低到高过渡），并在下降沿输出



这允许四种SPI模式，这些模式是在内核中根据 ```include/linux/spi/spi.h``` 中的以下宏定义的：

```c
#define SPI_CPHA 0x01
#define SPI_CPOL 0x02
```

然后，您可以产生以下数组来汇总内容：

| Mode | CPOL | CPHA | Kernel macro                                 |
| ---- | ---- | ---- | -------------------------------------------- |
| 0    | 0    | 0    | #define SPI_MODE_0    (0 \| 0)               |
| 1    | 0    | 1    | #define SPI_MODE_1    (0 \| SPI_CPHA)        |
| 2    | 1    | 0    | #define SPI_MODE_2    (SPI_CPOL \| 0)        |
| 3    | 1    | 1    | #define SPI_MODE_3    (SPI_CPOL \| SPI_CPHA) |

以下是在前面的阵列中定义的每种SPI模式的表示。 仅表示了MOSI线，但是MISO的原理是相同的：

<img src="./images/8_2.png" alt="images" style="zoom:25%;" />

常用模式为 SPI_MODE_0 和 SPI_MODE_3 。



#### spi_driver 结构体

struct spi_driver 代表您开发用于管理SPI设备的驱动程序。 其结构如下：

```c
struct spi_driver {
    const struct spi_device_id *id_table;
    int (*probe)(struct spi_device *spi);
    int (*remove)(struct spi_device *spi);
    void (*shutdown)(struct spi_device *spi);
    struct device_driver driver;
};
```



#### probe() 函数

其原型如下：

```c
static int probe(struct spi_device *spi)
```

您可以参考第7章，I2C客户端驱动程序，以了解在探测功能中要执行的操作。 同样的步骤在这里适用。 因此，与I2C 驱动程序不同，它无法在运行时更改控制器总线参数（CS状态，每字位，时钟），而SPI驱动程序可以。 您可以根据设备属性设置总线。

典型的SPI探针功能如下所示：

```c
static int my_probe(struct spi_device *spi)
{
    [...] /* declare your variable/structures */
    /* bits_per_word cannot be configured in platform data */
    spi->mode = SPI_MODE_0; /* SPI mode */
    spi->max_speed_hz = 20000000; /* Max clock for the device */
    spi->bits_per_word = 16; /* device bit per word */
    ret = spi_setup(spi);
    ret = spi_setup(spi);
    if (ret < 0)
    return ret;
    [...] /* Make some init */
    [...] /* Register with appropriate framework */
    return ret;
}
```

```struct spi_device *``` 是内核提供给 ```probe``` 函数的输入参数。 它代表您要探测的设备。 从您的 ```probe``` 函数中，您可以使用```spi_get_device_id```（在id_table匹配的情况下）获取触发了匹配的 ```spi_device_id``` 并提取驱动程序数据：

```c
const struct spi_device_id *id = spi_get_device_id(spi);
my_private_data = array_chip_info[id->driver_data];
```



#### 每个设备数据

在 probe 函数中，跟踪模块寿命期间要使用的私有（每设备）数据是一项常见任务。 第7章，I2C客户端驱动程序中对此进行了讨论。
以下是用于设置/获取每个设备数据的功能的原型：

```c
/* set the data */
void spi_set_drvdata(struct *spi_device, void *data);
/* Get the data back */
void *spi_get_drvdata(const struct *spi_device);
```

以下为示例：

```c
struct mc33880 {
	struct mutex lock;
    u8 bar;
    struct foo chip;
    struct spi_device *spi;
};

static int mc33880_probe(struct spi_device *spi)
{
    struct mc33880 *mc;
    [...] /* Device set up */
    
    mc = devm_kzalloc(&spi->dev, sizeof(struct mc33880), GFP_KERNEL);
    
    if (!mc)
    	return -ENOMEM;
    
    mutex_init(&mc->lock);
    spi_set_drvdata(spi, mc);
    
    mc->spi = spi;
    mc->chip.label = DRIVER_NAME,
    mc->chip.set = mc33880_set;
    /* Register with appropriate framework */
    [...]
}
```



#### remove() 函数

```remove``` 函数必须释放探测功能中获取的所有资源。 其结构如下：

```c
static int my_remove(struct spi_device *spi);
```

一个典型的 remove 函数示例：

```c
static int mc33880_remove(struct spi_device *spi)
{
    struct mc33880 *mc;
    mc = spi_get_drvdata(spi); /* Get our data back */
    if (!mc)
    	return -ENODEV;
    
    /*
     * unregister from frameworks with which we registered in the
     * probe function
     */
    [...]
    mutex_destroy(&mc->lock);
    return 0;
}
```



#### 驱动程序初始化和注册

对于位于无论是物理总线还是伪平台总线上的设备，大多数情况下，几乎所有操作都在 ```probe``` 函数 中完成。 init和exit函数仅用于在总线核心中注册/注销驱动程序：

```c
static int __init foo_init(void)
{
    [...] /*My init code */
    return spi_register_driver(&foo_driver);
}
module_init(foo_init);

static void __exit foo_cleanup(void)
{
    [...] /* My clean up code */
    spi_unregister_driver(&foo_driver);
}
module_exit(foo_cleanup);
```

如果您除了注册/注销驱动程序外什么都不做，内核会提供一个宏：

```c
module_spi_driver(foo_driver);
```

这将在内部调用spi_register_driver和spi_unregister_driver。 这与上一章中看到的完全一样。



### 驱动程序和设备配置

由于我们需要 I2C 设备的 ```i2c_device_id``` ，因此必须为 SPI 设备使用 ```spi_device_id``` ，以便提供一个```device_id``` 数组来匹配我们的设备。 它在 ```include/linux/mod_devicetable.h``` 中定义：

```c
struct spi_device_id {
    char name[SPI_NAME_SIZE];
    kernel_ulong_t driver_data; /* Data private to the driver */
};
```

我们需要将数组嵌入到 ```spi_device_id``` 结构中，以便将需要在驱动程序中管理的设备 ID 通知 SPI 内核，并在驱动程序结构上调用 **MODULE_DEVICE_TABLE** 宏。 当然，宏的第一个参数是设备所在总线的名称。 在我们的例子中是SPI：

```c
#define ID_FOR_FOO_DEVICE 0
#define ID_FOR_BAR_DEVICE 1

static struct spi_device_id foo_idtable[] = {
    { "foo", ID_FOR_FOO_DEVICE },
    { "bar", ID_FOR_BAR_DEVICE },
    { }
};
MODULE_DEVICE_TABLE(spi, foo_idtable);

static struct spi_driver foo_driver = {
    .driver = {
    	.name = "KBUILD_MODULE",
    },
    .id_table = foo_idtable,
    .probe = foo_probe,
    .remove = foo_remove,
};
module_spi_driver(foo_driver);
```



#### 用旧的方法实例化板配置文件中的SPI设备【不推荐】

仅在系统不支持DT的情况下，才应在电路板文件中实例化设备。 由于已经出现了DT，因此不建议使用这种实例化方法。 因此，让我们只记得该Board文件位于 ```arch/``` 目录中。 用于表示 SPI 设备的结构是```struct spi_board_info``` ，而不是我们在驱动程序中使用的struct spi_device。 只有当您使用 ```spi_register_board_info``` 函数填充并注册了 ```struct spi_board_info``` 时，内核才会构建``` struct spi_device```（将传递给驱动程序并在SPI内核中注册）。

随时查看 ```include/linux/spi/spi.h``` 中的 ```struct spi_board_info``` 字段。 ```spi_register_board_info``` 的定义可以在 ```drivers/spi/spi.c``` 中找到。 现在，让我们看一下board文件中的SPI设备注册：

```c
/**
 * Our platform data
 */
struct my_platform_data {
    int foo;
    bool bar;
};
static struct my_platform_data mpfd = {
    .foo = 15,
    .bar = true,
};

static struct spi_board_info
my_board_spi_board_info[] __initdata = {
	{
        /* the modalias must be same as spi device driver name */
        .modalias = "ad7887", /* Name of spi_driver for this device */
        .max_speed_hz = 1000000, /* max spi clock (SCK) speed in HZ */
        .bus_num = 0, /* Framework bus number */
        .irq = GPIO_IRQ(40),
        .chip_select = 3, /* Framework chip select */
        .platform_data = &mpfd,
        .mode = SPI_MODE_3,
    },{
        .modalias = "spidev",
        .chip_select = 0,
        .max_speed_hz = 1 * 1000 * 1000,
        .bus_num = 1,
        .mode = SPI_MODE_3,
    },
};
static int __init board_init(void)
{
    [...]
    spi_register_board_info(my_board_spi_board_info,
    ARRAY_SIZE(my_board_spi_board_info));
    [...]
    return 0;
}
[...]
```



#### SPI和设备树

与I2C设备一样，SPI设备属于DT中的非内存映射设备系列，但也可寻址。 在此，地址是指分配给控制器（主机）的CS列表（从0开始）中的CS索引。 例如，我们可能有三个不同的SPI设备位于SPI总线上，每个设备都有其CS线。 主机将获得**通用输入/输出（GPIO）**集，每个代表输入CS来激活设备。 如果设备X使用第二条GPIO线作为CS，则必须在reg属性中将其地址设置为1（因为我们总是从0开始）。

以下是SPI设备的真实DT列表：

```dtd
ecspi1 {
    fsl,spi-num-chipselects = <3>;
    cs-gpios = <&gpio5 17 0>, <&gpio5 17 0>, <&gpio5 17 0>;
    pinctrl-0 = <&pinctrl_ecspi1 &pinctrl_ecspi1_cs>;
    #address-cells = <1>;
    #size-cells = <0>;
    compatible = "fsl,imx6q-ecspi", "fsl,imx51-ecspi";
    reg = <0x02008000 0x4000>;
    status = "okay";
    ad7606r8_0: ad7606r8@0 {
        compatible = "ad7606-8";
        reg = <0>;
        spi-max-frequency = <1000000>;
        interrupt-parent = <&gpio4>;
        interrupts = <30 0x0>;
};
label: fake_spi_device@1 {
    compatible = "packtpub,foobar-device";
    reg = <1>;
    a-string-param = "stringvalue";
    spi-cs-high;
};
mcp2515can: can@2 {
    compatible = "microchip,mcp2515";
    reg = <2>;
    spi-max-frequency = <1000000>;
    clocks = <&clk8m>;
    interrupt-parent = <&gpio4>;
    interrupts = <29 IRQ_TYPE_LEVEL_LOW>;
    };
};
```

SPI设备节点中引入了一个新属性：```spi-max-frequency``` 。 它表示设备的最大SPI时钟速度，单位为Hz。 每当您访问设备时，总线控制器驱动程序都会确保时钟不超过此限制。 常用的其他属性有：

* spi-cpol：这是一个布尔值（空属性），指示设备需要反向时钟极性模式。 它对应于CPOL。
* spi-cpha：这是一个空属性，指示设备需要移位时钟相位模式。 它对应于CPHA。
* spi-cs-high：默认情况下，SPI设备要求CS低才能激活。 这是一个布尔型属性，指示器件要求CS高才能激活。

有关SPI绑定元素的完整列表，请参考内核源码的： Documentation/devicetree/bindings/spi/spi-bus.txt



#### 在设备树中实例化SPI设备–新方法

通过在DT中正确填充设备节点，内核将为我们构建一个 ```struct spi_device``` ，并将其作为SPI核心函数的参数。 以下只是先前定义的SPI DT清单的摘录：

```dtd
&ecspi1 {
        status = "okay";
        label: fake_spi_device@1 {
        compatible = "packtpub,foobar-device";
        reg = <1>;
        a-string-param = "stringvalue";
        spi-cs-high;
    };
};
```



#### 定义并注册SPI驱动程序

同样，该原理与I2C驱动程序的原理相同。 我们需要定义一个结构of_device_id以匹配DT中的设备，并调用**MODULE_DEVICE_TABLE** 宏向 OF内核注册：

```c
static const struct of_device_id foobar_of_match[] = {
    { .compatible = "packtpub,foobar-device" },
    { .compatible = "packtpub,barfoo-device" },
    {}
};
MODULE_DEVICE_TABLE(of, foobar_of_match);
```

然后，我们定义 ```spi_driver``` 如下：

```c
static struct spi_driver foo_driver = {
    .driver = {
        .name = "foo",
        /* The following line adds Device tree */
        .of_match_table = of_match_ptr(foobar_of_match),
    },
    .probe = my_spi_probe,
    .id_table = foo_id,
};
```

你可以通过如下方式改进 ```probe``` 函数：

```c
static int my_spi_probe(struct spi_device *spi)
{
    const struct of_device_id *match;
    match = of_match_device(of_match_ptr(foobar_of_match), &spi->dev);
    if (match) {
     /* Device tree code goes here */
    } else {
    /*
     * Platform data code comes here.
     * One can use
     * pdata = dev_get_platdata(&spi->dev);
     *
     * or *id*, which is a pointer on the *spi_device_id* entry that originated
     * the match, in order to use *id->driver_data* to extract the device
     * specific data, as described in Chapter 5, Platform Device Drivers.
     */
    }
    [...]
}
```



与客户端的信息流
SPI I/O模型由一组消息队列组成。 我们提交一个或多个 ```struct spi_message``` 结构，这些结构可以同步或异步处理和完成。 单个消息由一个或多个 ```struct spi_transfer``` 对象组成，每个对象都代表全双工SPI传输。 这是在驱动程序和设备之间交换数据的两个主要结构。 它们都在```include/linux/spi/spi.h``` 中定义：

<img src="./images/8_3.png" alt="images" style="zoom:100%;" />

```struct spi_transfer``` 表示全双工SPI传输：

```c
struct spi_transfer {
    const void *tx_buf;
    void *rx_buf;
    unsigned len;
    dma_addr_t tx_dma;
    dma_addr_t rx_dma;
    unsigned cs_change:1;
    unsigned tx_nbits:3;
    unsigned rx_nbits:3;
#define SPI_NBITS_SINGLE 0x01 	/* 1 bit transfer */
#define SPI_NBITS_DUAL 0x02 	/* 2 bits transfer */
#define SPI_NBITS_QUAD 0x04 	/* 4 bits transfer */
    u8 bits_per_word;
    u16 delay_usecs;
    u32 speed_hz;
};
```

以下是结构体成员的含义：

* ```tx_buf``` ：此缓冲区包含要写入的数据。对于只读事务，它应该为NULL或保留为空白。如果您需要通过直接内存访问（DMA）执行SPI事务，则它应该是dma安全的。
* ```rx_buf```：这是用于读取数据的缓冲区（具有与tx_buf相同的属性），或者在只写事务中为NULL。
* ```tx_dma``` ：在spi_message.is_dma_mapped设置为1的情况下，这是tx_buf的DMA地址。在第12章DMA –直接内存访问中讨论了DMA。
* ```rx_dma```：这与tx_dma相同，但对于rx_buf。
* ```len```：表示rx和tx缓冲区的大小（以字节为单位），这意味着如果同时使用它们，则它们必须具有相同的大小。
* ```speed_hz```：这将覆盖spi_device.max_speed_hz中指定的默认速度，但仅适用于当前传输。如果为0，则使用默认值（在struct spi_device结构中提供）。
* ```bits_per_word```：数据传输涉及一个或多个字。字是数据的单位，其位大小可能会根据需要而变化。此处，bits_per_word表示此SPI传输的字大小（以位为单位）。这将覆盖spi_device.bits_per_word中提供的默认值。如果为0，则使用默认值（来自spi_device）。
* ```cs_change```：确定此传输完成后chip_select线的状态。
* ```delay_usecs```：表示此传输之后（可选）更改chip_select状态，然后开始下一次传输或完成此spi_message的延迟（以微秒为单位）。

另一方面，原子地使用 ```spi_message```结构来包装一个或多个SPI传输。 驱动程序将占用所使用的 SPI 总线，直到构成消息的每次传输完成为止。 SPI消息结构也在 ```include/linux/spi/spi.h``` 中定义：

```c
struct spi_message {
    struct list_head transfers;
    struct spi_device *spi;
    unsigned is_dma_mapped:1;
    /* completion is reported through a callback */
    void (*complete)(void *context);
    void *context;
    unsigned frame_length;
    unsigned actual_length;
    int status;
};
```

前面的代码解释如下：

* ```transfers```：这是构成消息的传输列表。 稍后我们将看到如何将转移添加到此列表。
* ```is_dma_mapped```：这通知控制器是否使用DMA执行事务。 然后，您的代码负责为每个传输缓冲区提供DMA和CPU虚拟地址。
* ```complete```：这是在事务完成时调用的回调，而context是要赋予该回调的参数。
* ```frame_length```：它将自动设置为消息中的字节总数。
* ```actual_length```：这是所有成功传输的字节数
* ```segment.status```：此报告传输状态。 成功则为0，否则为-errno。

> 消息中的spi_transfer元素以FIFO顺序处理。 在消息完成之前，您必须确保不使用传输缓冲区，以避免数据损坏。 您拨打完成电话以确保可以。

在将消息提交到总线之前，必须使用 ```void spi_message_init(struct spi_message * message)``` 对其进行初始化，这会将结构中的每个元素清零并初始化传输列表。 对于要添加到消息中的每个传输，您应该在该传输上调用 ```void spi_message_add_tail(struct spi_transfer * t，struct spi_message * m)``` ，这将导致该传输进入传输列表。 完成后，您有两种选择来启动事务：

* 同步使用 ```int spi_sync(struct spi_device *spi, struct spi_message *message)``` 函数，该函数可能处于休眠状态，并且不能在中断上下文中使用。 此处不需要完成回调。 此函数是第二个函数 ```(spi_async())``` 的封装。
* 异步使用 ```spi_async()``` 函数，该函数也可以在原子上下文中使用，其原型为 ```int spi_async(struct spi_device *spi, struct spi_message *message)```。 最好在此处提供一个回调，因为它将在消息完成后执行。

以下是单个传输SPI消息事务的示例：

```c
char tx_buf[] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0x40, 0x00, 0x00, 0x00,
    0x00, 0x95, 0xEF, 0xBA, 0xAD,
    0xF0, 0x0D,
};

char rx_buf[10] = {0,};
int ret;
struct spi_message single_msg;
struct spi_transfer single_xfer;

single_xfer.tx_buf = tx_buf;
single_xfer.rx_buf = rx_buf;
single_xfer.len = sizeof(tx_buff);
single_xfer.bits_per_word = 8;

spi_message_init(&msg);
spi_message_add_tail(&xfer, &msg);
ret = spi_sync(spi, &msg);
```

现在，让我们编写一次多传输消息事务：

```c
struct {
    char buffer[10];
    char cmd[2]
    int foo;
} data;
struct data my_data[3];
initialize_data(my_data, ARRAY_SIZE(my_data));

struct spi_transfer multi_xfer[3];
struct spi_message single_msg;
int ret;

multi_xfer[0].rx_buf = data[0].buffer;
multi_xfer[0].len = 5;
multi_xfer[0].cs_change = 1;
/* command A */
multi_xfer[1].tx_buf = data[1].cmd;
multi_xfer[1].len = 2;
multi_xfer[1].cs_change = 1;
/* command B */
multi_xfer[2].rx_buf = data[2].buffer;
multi_xfer[2].len = 10;

spi_message_init(single_msg);
spi_message_add_tail(&multi_xfer[0], &single_msg);
spi_message_add_tail(&multi_xfer[1], &single_msg);
spi_message_add_tail(&multi_xfer[2], &single_msg);
ret = spi_sync(spi, &single_msg);
```

还有其他辅助功能，都是围绕 ```spi_sync()``` 构建的。 他们之中有一些是：

```c
int spi_read(struct spi_device *spi, void *buf, size_t len)
int spi_write(struct spi_device *spi, const void *buf, size_t len)
int spi_write_then_read(struct spi_device *spi, const void *txbuf, unsigned n_tx, void *rxbuf, unsigned n_rx)
```

请查看 ```include/linux/spi/spi.h``` 以查看完整列表。 这些包装程序应与少量数据一起使用。



### 放在一起

编写SPI客户端驱动程序所需的步骤如下：

1. 声明驱动程序支持的设备ID。您可以使用spi_device_id进行此操作。如果支持DT，则也使用of_device_id。您可以独占使用DT。
2. 调用MODULE_DEVICE_TABLE（spi，my_id_table）;为了将驱动程序及其SPI设备表ID公开给用户空间。如果支持DT，则必须调用MODULE_DEVICE_TABLE(of，your_of_match_table) ;为了向用户空间公开OF（设备树）相关的模块别名。前面对 MODULE_DEVICE_TABLE 的调用将导出由depmod收集的信息，以更新modules.alias文件，因此，如果将驱动程序作为模块构建，则可以自动找到并加载该驱动程序。
3. 根据各自的原型编写探针并删除功能。探测功能必须标识您的设备，对其进行配置，定义每个设备（专用）数据，使用spi_setup函数在需要时配置总线（SPI模式等），并向适当的内核框架注册。在删除功能中，只需撤销探测功能中完成的所有操作即可。
4. 声明并填充一个struct spi_driver结构，使用您创建的ID数组设置id_table字段。使用已编写的相应函数的名称设置.probe和.remove字段。在.driver子结构中，将.owner字段设置为THIS_MODULE，设置驱动程序名称，最后，如果支持DT，则使用of_device_id数组设置.of_match_table字段。
5. 使用刚在module_spi_driver（serial_eeprom_spi_driver）之前填写的spi_driver结构调用module_spi_driver函数；为了向内核注册您的驱动程序。



### SPI用户模式驱动程序

有两种使用用户模式SPI设备驱动程序的方法。 为此，您需要使用spidev驱动程序启用设备。 一个例子如下：

```dtd
spidev@0x00 {
    compatible = "spidev";
    spi-max-frequency = <800000>; /* It depends on your device */
    reg = <0>; /* correspond to chip select 0 */
};
```

您可以调用 read/write 或者 ioctl 函数。 通过调用 read/write，您一次只能读取或写入。 如果需要全双工读取和写入，则必须使用输入输出控制（ioctl）命令。 提供了两个示例。 这是读/写示例。 您可以使用平台的交叉编译器或开发板上的本机编译器进行编译：

```c
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>
int main(int argc, char **argv)
{
    int i,fd;
    char wr_buf[]={0xff,0x00,0x1f,0x0f};
    char rd_buf[10];
    if (argc<2) {
        printf("Usage:\n%s [device]\n", argv[0]);
        exit(1);
    }
    fd = open(argv[1], O_RDWR);
    if (fd<=0) {
        printf("Failed to open SPI device %s\n",argv[1]);
        exit(1);
    }
    if (write(fd, wr_buf, sizeof(wr_buf)) != sizeof(wr_buf))
    	perror("Write Error");
    	
    if (read(fd, rd_buf, sizeof(rd_buf)) != sizeof(rd_buf))
    	perror("Read Error");
    else
    	for (i = 0; i < sizeof(rd_buf); i++)
    		printf("0x%02X ", rd_buf[i]);
    		
    close(fd);
    return 0;
}
```



#### 使用IOCTL

使用IOCTL的优点是您可以全双工工作。 当然，您可以找到的最佳示例是内核源代码树中的```documentation/spi/spidev_test.c``` 。
前面使用读/写的示例未更改任何SPI配置。 但是，内核向用户空间提供了一组IOCTL命令，您可以使用这些命令来根据需要设置总线，就像在DT中所做的一样。 以下示例显示了如何更改总线设置：

```c
#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include <linux/spi/spidev.h>

static int pabort(const char *s)
{
    perror(s);
    return -1;
}

static int spi_device_setup(int fd)
{
    int mode, speed, a, b, i;
    int bits = 8;
    /*
    * spi mode: mode 0
    */
    mode = SPI_MODE_0;
    a = ioctl(fd, SPI_IOC_WR_MODE, &mode); /* write mode */
    b = ioctl(fd, SPI_IOC_RD_MODE, &mode); /* read mode */
    if ((a < 0) || (b < 0)) {
    	return pabort("can't set spi mode");
	}
    /*
    * Clock max speed in Hz
    */
    speed = 8000000; /* 8 MHz */
    a = ioctl(fd, SPI_IOC_WR_MAX_SPEED_HZ, &speed); /* Write speed */
    b = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &speed); /* Read speed */
    if ((a < 0) || (b < 0)) {
    	return pabort("fail to set max speed hz");
    }
    /*
    * setting SPI to MSB first.
    * Here, 0 means "not to use LSB first".
    * In order to use LSB first, argument should be > 0
    */
    i = 0;
    a = ioctl(dev, SPI_IOC_WR_LSB_FIRST, &i);
    b = ioctl(dev, SPI_IOC_RD_LSB_FIRST, &i);
    if ((a < 0) || (b < 0)) {
    	pabort("Fail to set MSB first\n");
    }
    /*
    * setting SPI to 8 bits per word
    */
    bits = 8;
    a = ioctl(dev, SPI_IOC_WR_BITS_PER_WORD, &bits);
    b = ioctl(dev, SPI_IOC_RD_BITS_PER_WORD, &bits);
    if ((a < 0) || (b < 0)) {
    	pabort("Fail to set bits per word\n");
    }
    return 0;
}
```

您可以查看 ```Documentation/spi/spidev``` 以获取有关 ```spidev ioctl``` 命令的更多信息。 在通过总线发送数据时，可以使用 ```SPI_IOC_MESSAGE(N)```请求，该请求提供全双工访问，并且无需芯片选择停用即可执行复合操作，从而提供多传输支持。 它等效于内核的 ```spi_sync()```。 在这里，传输被表示为 ```struct spi_ioc_transfer``` 的实例，它等同于内核的 ```struct spi_transfer```，其定义可以在```include/uapi/linux/spi/spidev.h```中找到。 以下是其用法示例：

```c
static void do_transfer(int fd)
{
    int ret;
    char txbuf[] = {0x0B, 0x02, 0xB5};
    char rxbuf[3] = {0, };
    char cmd_buff = 0x9f;
    struct spi_ioc_transfer tr[2] = {
        0 = {
            .tx_buf = (unsigned long)&cmd_buff,
            .len = 1,
            .cs_change = 1; /* We need CS to change */
            .delay_usecs = 50, /* wait after this transfer */
            .bits_per_word = 8,
        },
        [1] = {
            .tx_buf = (unsigned long)tx,
            .rx_buf = (unsigned long)rx,
            .len = txbuf(tx),
            .bits_per_word = 8,
        },
    };
    
    ret = ioctl(fd, SPI_IOC_MESSAGE(2), &tr);
    if (ret == 1){
        perror("can't send spi message");
        exit(1);
    }
    
    for (ret = 0; ret < sizeof(tx); ret++)
    	printf("%.2X ", rx[ret]);
    printf("\n");
}

int main(int argc, char **argv)
{
    char *device = "/dev/spidev0.0";
    int fd;
    int error;
    fd = open(device, O_RDWR);
    if (fd < 0)
    	return pabort("Can't open device ");
    error = spi_device_setup(fd);
    if (error)
    	exit (1);
    	
    do_transfer(fd);
    close(fd);
    return 0;
}
```





摘要
我们只处理了SPI驱动程序，现在可以利用这种更快的串行（和全双工）总线。 我们介绍了通过SPI进行数据传输的过程，这是最重要的部分。 您可能需要更多抽象，以免打扰 SPI 或 I2C API。 下一章将介绍regmap API，它提供了更高且统一的抽象级别，因此SPI（或I2C）命令对您而言将变得透明。

