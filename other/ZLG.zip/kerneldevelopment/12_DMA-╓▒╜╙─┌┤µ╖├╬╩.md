# DMA-直接内存访问

DMA是计算机系统的一项功能，该功能允许设备在无需CPU干预的情况下访问主系统内存RAM，然后使它们可以专注于其他任务。 通常使用它来加快网络流量，但是它支持任何类型的副本。

DMA控制器是负责DMA管理的外围设备。 人们大多在现代处理器和微控制器中找到它。 DMA是一项用于执行内存读取和写入操作而不会占用CPU周期的功能。 当需要传输数据块时，处理器将源地址和目标地址以及字节总数提供给DMA控制器。 然后，DMA控制器自动将数据从源传输到目标，而不会占用CPU周期。 当剩余字节数达到零时，块传输结束。

在本章中，我们将介绍以下主题：

* 相干和非相干DMA映射以及相干问题
* DMA引擎API
* DMA和DT绑定



### 设置DMA映射

对于任何类型的DMA传输，都需要提供源地址和目标地址以及要传输的字数。 对于外设DMA，外设的FIFO用作源或目的地。 当外围设备用作源时，存储位置（内部或外部）用作目标地址。 当外围设备用作目的地时，存储位置（内部或外部）用作源地址。

对于外设DMA，我们根据传输方向指定源或目的地。 换句话说，DMA传输需要适当的内存映射。 这是我们将在以下各节中讨论的内容。



### 缓存一致性和DMA

如第11章“内核内存管理”中所述，最近访问的内存区域的副本存储在缓存中。 这也适用于DMA存储器。 现实情况是，两个独立设备之间共享的内存通常是缓存一致性问题的根源。 缓存不一致性是一个问题，原因是其他设备可能不知道来自写入设备的更新。 另一方面，高速缓存一致性可确保每个写操作看起来都是瞬间发生的，因此共享同一内存区域的所有设备都可以看到完全相同的更改序列。

LDD3的以下摘录说明了一个很好解释的一致性问题方案：

> 让我们想象一下配备了缓存和外部存储器的CPU，这些存储器可以由使用DMA的设备直接访问。 当CPU访问内存中的位置X时，当前值将存储在高速缓存中。 在X上进行的后续操作将更新X的缓存副本，但不会更新X的外部存储器版本（假设有回写缓存）。 如果在下一次设备尝试访问X之前未将缓存刷新到内存，则该设备将收到过时的X值。类似地，如果当设备向X写入新值时X的缓存副本没有失效。 内存，然后CPU将以过时的X值运行。

实际上，有两种方法可以解决此问题：

* 基于硬件的解决方案。 这样的系统是相干系统。
* 一种基于软件的解决方案，其中OS负责确保缓存一致性。 人们称这种系统为非相干系统。



### DMA映射

任何合适的DMA传输都需要合适的内存映射。 DMA映射包括分配DMA缓冲区并为其生成总线地址。 设备实际上使用总线地址。 总线地址是dma_addr_t类型的每个实例。

一种区分两种类型的映射：相干DMA映射和流DMA映射。 一个人可以在多次传输中使用前者，后者可以自动解决缓存一致性问题。 因此，它太昂贵了。 流映射有很多约束，并且不能自动解决一致性问题，尽管有一种解决方案，它由每次传输之间的多个函数调用组成。 在驱动程序的生命周期内通常存在一致性映射，而一旦DMA传输完成，通常就不会映射流映射。

一个人可以使用流映射，而一个必须使用流映射。

返回代码； 主标头应包括以下内容以处理DMA映射： ```#include <linux/dma-mapping.h>``` 



#### 相干映射

以下函数设置了一个连贯的映射：

```c
void *dma_alloc_coherent(struct device *dev, size_t size,
                         dma_addr_t *dma_handle, gfp_t flag)
```

该函数处理缓冲区的分配和映射，并返回该缓冲区的内核虚拟地址，该地址的大小为字节宽，可由CPU访问。 dev是您的设备结构。 第三个参数是指向关联总线地址的输出参数。 确保为映射分配的内存在物理上是连续的，并且flag确定应如何分配内存，这通常由GFP_KERNEL或GFP_ATOMIC（如果我们在原子上下文中）进行。

请注意，此映射据说是：

* 一致（一致），因为它为设备分配了未缓存的未缓冲内存以执行DMA
* 同步，因为设备或CPU的写操作均可立即读取，而无需担心缓存的一致性

为了释放映射，你可以使用以下函数：

```c
void dma_free_coherent(struct device *dev, size_t size,
                       void *cpu_addr, dma_addr_t dma_handle);
```

在这里，```cpu_addr``` 对应于 ```dma_alloc_coherent()``` 返回的内核虚拟地址。 该映射非常昂贵，并且它可以分配的最小数量是一个页面。 实际上，它仅分配2的幂的页面数。页面顺序是通过 ```int order = get_order(size)``` 获得的。 应当将这种映射用于可以延长设备寿命的缓冲区。



#### 流DMA映射

流映射具有更多约束，并且由于以下原因与相干映射不同：

* 映射需要使用已经分配的缓冲区。
* 映射可以接受几个不连续且分散的缓冲区。
* 映射的缓冲区不再属于设备，而不再属于CPU。 在CPU使用缓冲区之前，应先将其取消映射（在dma_unmap_single（）或dma_unmap_sg（）之后）。 这是出于缓存目的。
* 对于写事务（CPU到设备），驱动程序应在映射之前将数据放入缓冲区。
* 必须指定数据应移动的方向，并且只能根据该方向使用数据。



有人可能想知道为什么不对缓冲区进行映射后才访问缓冲区。 原因很简单：CPU映射是可缓存的。 用于流映射的```dma_map_*()```  系列函数将首先清除/使与缓冲区有关的缓存无效，然后依靠CPU直到相应的 ```dma_unmap_*()``` 才访问它。 然后，在此期间发生任何推测性提取的情况下，在CPU可以读取设备写入内存的任何数据之前，这将再次使缓存无效（如有必要）。 现在，CPU可以访问缓冲区了。

流映射实际上有两种形式：

* 单缓冲区映射，仅允许一页映射
* 分散/聚集映射，允许传递多个缓冲区（分散在内存中）



对于任何一种映射，方向都应通过在 ```<include/linux/dma-direction.h>``` 中定义的```enum dma_data_direction``` 类型的符号来指定：

```c
enum dma_data_direction {
    DMA_BIDIRECTIONAL = 0,
    DMA_TO_DEVICE = 1,
    DMA_FROM_DEVICE = 2,
    DMA_NONE = 3,
};
```



#### 单缓冲区映射

这是用于偶尔的映射。 可以使用以下方法设置单个缓冲区：

```c
dma_addr_t dma_map_single(struct device *dev, void *ptr,
                          size_t size, enum dma_data_direction direction);
```

方向应为DMA_TO_DEVICE，DMA_FROM_DEVICE或DMA_BIDIRECTIONAL，如前面的代码中所述。 ptr是缓冲区的内核虚拟地址，而dma_addr_t是设备返回的总线地址。 确保使用真正适合您需求的方向，而不仅仅是DMA_BIDIRECTIONAL。

应该使用以下方法释放映射：

```c
void dma_unmap_single(struct device *dev, dma_addr_t dma_addr,
                      size_t size, enum dma_data_direction direction);
```



#### 分散/聚集映射

分散/聚集映射是一种特殊类型的流DMA映射，其中可以在单个快照中传输多个缓冲区，而不是分别映射每个缓冲区并一个接一个地传输它们。 假设您有几个缓冲区在物理上可能不是连续的，所有这些缓冲区都需要同时传输到设备或从设备传输出去。 由于以下原因，可能会发生这种情况：

* readv或writev系统调用
* 磁盘I / O请求
* 或者，只是映射的内核I / O缓冲区中的页面列表

内核将分散列表表示为一个连贯的结构，即 struct scatterlist：

```c
struct scatterlist {
    unsigned long page_link;
    unsigned int offset;
    unsigned int length;
    dma_addr_t dma_address;
    unsigned int dma_length;
};
```

为了建立分散列表映射，应该：

* 分配分散的缓冲区。
* 创建分散列表的数组，并使用 ```sg_set_buf()``` 用分配的内存填充它。 请注意，分散列表条目必须具有页面大小（末尾除外）。
* 在分散列表上调用 ```dma_map_sg()``` 。
* 使用DMA完成后，调用 ```dma_unmap_sg()``` 取消映射散列表。

通过分别映射每个缓冲区，可以一次通过DMA发送多个缓冲区的内容，而分散/收集可以通过将指向分散列表的指针发送到设备以及长度（即长度）来一次全部发送。 列表中的条目数：

```c
u32 *wbuf, *wbuf2, *wbuf3;
wbuf = kzalloc(SDMA_BUF_SIZE, GFP_DMA);
wbuf2 = kzalloc(SDMA_BUF_SIZE, GFP_DMA);
wbuf3 = kzalloc(SDMA_BUF_SIZE/2, GFP_DMA);

struct scatterlist sg[3];
sg_init_table(sg, 3);
sg_set_buf(&sg[0], wbuf, SDMA_BUF_SIZE);
sg_set_buf(&sg[1], wbuf2, SDMA_BUF_SIZE);
sg_set_buf(&sg[2], wbuf3, SDMA_BUF_SIZE/2);
ret = dma_map_sg(NULL, sg, 3, DMA_MEM_TO_MEM);
```

单缓冲区映射部分中描述的相同规则适用于分散/聚集映射：

<img src="./images/12_1.png" alt="images" style="zoom:90%;" />

```dma_map_sg()``` 和 ```dma_unmap_sg()``` 负责缓存一致性。 但是，如果需要使用相同的映射来访问（读/写）DMA传输之间的数据，则如果CPU需要访问缓冲区，则必须通过 ```dma_sync_sg_for_cpu()``` 以适当的方式在每次传输之间同步缓冲区。 如果是设备，则为 ```dma_sync_sg_for_device()``` 。 单个区域映射的类似功能是 ```dma_sync_single_for_cpu()``` 和 ```dma_sync_single_for_device()``` ：

```c
void dma_sync_sg_for_cpu(struct device *dev,
                         struct scatterlist *sg,
                         int nents,
                         enum dma_data_direction direction);

void dma_sync_sg_for_device(struct device *dev,
                            struct scatterlist *sg, int nents,
                            enum dma_data_direction direction);

void dma_sync_single_for_cpu(struct device *dev, dma_addr_t addr,
                             size_t size,
                             enum dma_data_direction dir)

void dma_sync_single_for_device(struct device *dev,
                                dma_addr_t addr, size_t size,
                                enum dma_data_direction dir)
```

取消映射缓冲区后，无需再次调用前面的函数。 您可以阅读内容。



### completion 的概念

本节将简要描述DMA传输使用的API的完成和必要部分。 有关完整的描述，请随时查看 ```Documentation/scheduler/completion.txt``` 上的内核文档。 内核编程中的常见模式包括在当前线程之外启动某些活动，然后等待该活动完成。

当等待使用缓冲区时，completion 是 ```sleep()``` 的好选择。 它适合于检测数据，这正是DMA回调的作用。

调用 completion 需要以下头文件：

```c
#include <linux/completion.h>
```

像其他内核工具数据结构一样，可以静态或动态创建 ```struct completion```结构的实例：

* 静态声明和初始化如下所示：

  ```c
  DECLARE_COMPLETION(my_comp);
  ```

* 动态分配如下所示：

  ```c
  struct completion my_comp;
  init_completion(&my_comp);
  ```

当驱动程序开始一些必须等待完成的工作（在我们的例子中是DMA事务）时，它只需要将完成事件传递给 ```wait_for_completion()``` 函数：

```c
void wait_for_completion(struct completion *comp);
```

当代码的其他部分确定完成已经发生（事务完成）时，它可以唤醒正在等待以下其中一项的任何人（实际上是需要访问DMA缓冲区的代码）：

```c
void complete(struct completion *comp);
void complete_all(struct completion *comp);
```

可以猜到，```complete()``` 仅唤醒一个等待的进程，而 ```complete_all()``` 将唤醒等待该事件的每个进程。 完成的实现方式是，即使在 ```wait_for_completion()``` 之前调用 ```complete()``` ，它们也可以正常工作。

通过下一部分中使用的代码示例，我们将更好地了解其工作原理。



### DMA引擎API

DMA 引擎是用于开发 DMA 控制器驱动程序的通用内核框架。 DMA 的主要目标是在复制内存时减轻 CPU 负担。 通过使用通道，将事务（I/O 数据传输）委托给 DMA 引擎。 DMA 引擎通过其驱动程序/ API公开了一组可由其他设备（从机）使用的通道。 下图显示了DMA引擎的布局：

<img src="./images/12_2.png" alt="image" style="zoom:90%;" />

在这里，我们将简单地介绍（从）API，该 API 仅适用于从 DMA。 此处的必需头文件如下：

```c
#include <linux/dmaengine.h>
```

使用从DMA非常简单，包括以下步骤：

1. 分配一个DMA从通道。
2. 设置从站和控制器特定的参数。
3. 获取事务的描述符。
4. 提交交易。
5. 发出未决请求并等待回调通知。

>  可以将DMA通道视为 I/O 数据传输的高速公路。



#### 分配DMA从通道

使用 ```dma_request_channel()``` 请求一个频道。 其原型如下：

```c
struct dma_chan *dma_request_channel(const dma_cap_mask_t *mask, 
                                     dma_filter_fn fn, void *fn_param);
```

mask，是一个位图常数，代表通道必须满足的功能。正确，使用它来指定驱动程序需要执行的传输类型：

```c
enum dma_transaction_type {
    DMA_MEMCPY, /* Memory to memory copy */
    DMA_XOR, /* Memory to memory XOR*/
    DMA_PQ, /* Memory to memory P+Q computation */
    DMA_XOR_VAL, /* Memory buffer parity check using XOR */
    DMA_PQ_VAL, /* Memory buffer parity check using P+Q */
    DMA_INTERRUPT, /* The device is able to generate dummy transfer that
    will generate interrupts */
    DMA_SG, /* Memory to memory scatter gather */
    DMA_PRIVATE, /* channels are not to be used for global memcpy.
    Usually used with DMA_SLAVE */
    DMA_SLAVE, /* Memory to device transfers */
    DMA_CYCLIC, /* Device is able to handle cyclic transfers */
    DMA_INTERLEAVE, /* Memory to memory interleaved transfer */
}
```

```dma_cap_zero()``` 和 ```dma_cap_set()``` 函数用于清除掩码并设置所需的功能。 例如：

```c
dma_cap_mask my_dma_cap_mask;
struct dma_chan *chan;
dma_cap_zero(my_dma_cap_mask);
dma_cap_set(DMA_MEMCPY, my_dma_cap_mask); /* Memory to memory copy */
chan = dma_request_channel(my_dma_cap_mask, NULL, NULL);
```

在前面的摘录中，dma_filter_fn 的定义如下：

```c
typedef bool (*dma_filter_fn)(struct dma_chan *chan, void *filter_param);
```

如果 filter_fn 参数（可选）为NULL，则 ```dma_request_channel()``` 将仅返回满足功能掩码的第一个通道。 否则，当 mask 参数不足以指定必要的通道时，可以使用 filter_fn 例程作为系统中可用通道的过滤器。 内核为系统中的每个空闲通道调用一次 filter_fn 例程。 看到合适的通道后，filter_fn 应该返回 DMA_ACK，它将给定通道标记为 ```dma_request_channel()``` 的返回值。

通过此接口分配的通道是调用方专有的，直到调用 ```dma_release_channel()``` 为止：

```c
void dma_release_channel(struct dma_chan *chan)
```

