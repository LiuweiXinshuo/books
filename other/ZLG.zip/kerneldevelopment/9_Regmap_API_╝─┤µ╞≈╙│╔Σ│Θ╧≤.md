# Regmap API-寄存器映射抽象

在开发regmap API之前，存在用于SPI内核，I2C内核或两者的设备驱动程序的冗余代码。 原理是相同的：访问寄存器以进行读/写操作。 下图显示了在将regmap引入内核之前，SPI或I2C API是如何独立的：

<img src="./images/9_1.png" alt="images" style="zoom:90%;" />

regmap API在内核的版本3.1中引入，以分解和统一内核开发人员访问SPI / I2C设备的方式。 然后，仅需如何初始化和配置regmap以及如何流畅地处理任何读/写/修改操作（无论是SPI还是I2C）就可以了：

<img src="./images/9_2.png" alt="image2" style="zoom:90%;" />

本章将逐步介绍regmap框架，如下所示：

* 介绍regmap框架中使用的主要数据结构
* 遍历regmap配置
* 使用regmap API访问设备
* 引入regmap缓存系统
* 提供一个完整的驱动程序，总结以前学到的概念



### 使用regmap API进行编程

regmap API非常简单。 只有少数结构需要了解。 该 API 的两个最重要的结构是 ```struct regmap_config```（代表regmap的配置）和 ```struct regmap```（即regmap实例本身）。 所有regmap数据结构都在 ```include/linux/regmap.h``` 中定义。



#### regmap_config 结构体

```struct regmap_config``` 在驱动程序的生存期内存储 regmap 的配置。 您在此处设置的内容会影响读/写操作。 它是 regmap API 中最重要的结构。 其结构是这样：

```c
struct regmap_config {
    const char *name;
    int reg_bits;
    int reg_stride;
    int pad_bits;
    int val_bits;
    
    bool (*writeable_reg)(struct device *dev, unsigned int reg);
    bool (*readable_reg)(struct device *dev, unsigned int reg);
    bool (*volatile_reg)(struct device *dev, unsigned int reg);
    bool (*precious_reg)(struct device *dev, unsigned int reg);
    regmap_lock lock;
    regmap_unlock unlock;
    void *lock_arg;
    
    int (*reg_read)(void *context, unsigned int reg, unsigned int *val);
    int (*reg_write)(void *context, unsigned int reg, unsigned int val);
    
    bool fast_io;
    
    unsigned int max_register;
    const struct regmap_access_table *wr_table;
    const struct regmap_access_table *rd_table;
    const struct regmap_access_table *volatile_table;
    const struct regmap_access_table *precious_table;
    const struct reg_default *reg_defaults;
    unsigned int num_reg_defaults;
    enum regcache_type cache_type;
    const void *reg_defaults_raw;
    unsigned int num_reg_defaults_raw;
    u8 read_flag_mask;
    u8 write_flag_mask;
    
    bool use_single_rw;
    bool can_multi_write;
    
    enum regmap_endian reg_format_endian;
    enum regmap_endian val_format_endian;
    const struct regmap_range_cfg *ranges;
    unsigned int num_ranges;
}

```

前面的代码可以解释如下：

* ```reg_bits```：此必填字段是寄存器地址中的位数。

* ```val_bits```：表示用于存储寄存器值的位数。 这是必填字段。

* ```writeable_reg```：这是一个可选的回调函数。 如果提供，则当需要写入寄存器时，regmap子系统将使用它。 在写入寄存器之前，将自动调用此函数以检查是否可以写入寄存器：

  ```c
  static bool foo_writeable_register(struct device *dev,unsigned int reg)
  {
      switch (reg) {
      case 0x30 ... 0x38:
      case 0x40 ... 0x45:
      case 0x50 ... 0x57:
      case 0x60 ... 0x6e:
      case 0x70 ... 0x75:
      case 0x80 ... 0x85:
      case 0x90 ... 0x95:
      case 0xa0 ... 0xa5:
      case 0xb0 ... 0xb2:
      	return true;
      default:
      	return false;
      }
  }
  ```

* visible_reg：与writeable_reg相同，但是对于每个寄存器读取操作。

* volatile_reg：这是每次需要通过regmap缓存读取或写入寄存器时调用的回调函数。 如果寄存器是易失性的，则该函数应返回true。 然后直接在寄存器上进行读/写。 如果返回false，则表示该寄存器是可缓存的。 在这种情况下，缓存将用于读取操作，而在写入操作的情况下将写入缓存：

  ```c
  static bool foo_volatile_register(struct device *dev,unsigned int reg)
  {
      switch (reg) {
      case 0x24 ... 0x29:
      case 0xb6 ... 0xb8:
      	return true;
      default:
      	return false;
      }
  }
  ```

* ```wr_table```：您可以提供一个regmap_access_table，而不是提供writeable_reg回调，该结构包含yes_range和no_range字段，这两个指针均指向regmap_range结构。 属于yes_range条目的任何寄存器均被视为可写，如果属于no_range则被视为不可写。

* ```rd_table```：与wr_table相同，但用于任何读取操作。

* ```volatile_table```：您可以提供 volatile_table 而不是 volatile_reg。 然后，该原理与 wr_table 或 rd_table 相同，只是用于缓存机制。

* ```max_register```：这是可选的； 它指定最大有效寄存器地址，不允许对其进行任何操作。

* ```reg_read```：您的设备可能不支持简单的I2C / SPI读取操作。 然后，您别无选择，只能编写自己的自定义读取函数。 reg_read然后应指向该函数。 也就是说，大多数设备都不需要这样做。

* ```reg_write```：与reg_read相同，但用于写操作。



我强烈建议你查看include / linux / regmap.h，以获取每个元素的更多详细信息。

以下是regmap_config的一种初始化：

```c
static const struct regmap_config regmap_config = {
    .reg_bits = 8,
    .val_bits = 8,
    .max_register = LM3533_REG_MAX,
    .readable_reg = lm3533_readable_register,
    .volatile_reg = lm3533_volatile_register,
    .precious_reg = lm3533_precious_register,
};
```



#### regmap初始化

如前所述，regmap API支持SPI和I2C协议。 根据您的驱动程序需要支持的协议，您将不得不在探测函数中调用```regmap_init_i2c()``` 或 ```regmap_init_spi()``` 。 要编写通用驱动程序，regmap是最佳选择。
regmap API是通用且同质的。 只有初始化在总线类型之间改变。 其他功能相同。

> 始终在 ```probe``` 函数中初始化 regmap 是一个好习惯，并且在初始化 regmap之前，必须始终填充regmap_config元素。

无论您分配了I2C还是SPI寄存器映射，都可以使用regmap_exit函数释放它：

```c
void regmap_exit(struct regmap *map)
```

该功能仅释放先前分配的寄存器映射。



##### SPI初始化

Regmap SPI 初始化包括设置 regmap，以便任何设备访问都将在内部转换为SPI命令。 执行此功能的函数是```regmap_init_spi()```。

```c
struct regmap * regmap_init_spi(struct spi_device *spi, const struct regmap_config);
```

它使用指向结构spi_device结构的有效指针作为参数（该参数是将与之交互的SPI设备），以及一个结构```regmap_config```，该结构代表 regmap 的配置。 该函数在成功时返回指向分配的结构 regmap 的指针，或者在错误时返回为 ```ERR_PTR()```的值。

完整的示例如下：

```c
static int foo_spi_probe(struct spi_device *client)
{
    int err;
    struct regmap *my_regmap;
    struct regmap_config bmp085_regmap_config;
    /* fill bmp085_regmap_config somewhere */
    [...]
    client->bits_per_word = 8;
    my_regmap = regmap_init_spi(client,&bmp085_regmap_config);
    
    if (IS_ERR(my_regmap)) {
    	err = PTR_ERR(my_regmap);
    	dev_err(&client->dev, "Failed to init regmap: %d\n", err);
    	return err;
    }
    [...]
}
```



##### I2C初始化

另一方面，I2C regmap 初始化包括在regmap配置上调用 ```regmap_init_i2c()```，它将配置regmap，以便任何设备访问都将在内部转换为I2C命令：

```c
struct regmap * regmap_init_i2c(struct i2c_client *i2c, const struct regmap_config);
```

该函数将 ```struct i2c_client``` 结构作为参数（这是将用于交互的I2C设备），以及指向 ```struct regmap_config``` 的指针，该指针表示 regmap 的配置。 该函数在成功时返回指向分配的结构regmap的指针，或者在错误时返回为 ```ERR_PTR()``` 的值。

一个完整的例子是：

```c
static int bar_i2c_probe(struct i2c_client *i2c, const struct i2c_device_id *id)
{
    struct my_struct * bar_struct;
    struct regmap_config regmap_cfg;
    
    /* fill regmap_cfgsome where */
    [...]
    bar_struct = kzalloc(&i2c->dev,
    sizeof(*my_struct), GFP_KERNEL);
    
    if (!bar_struct)
    	return -ENOMEM;
    i2c_set_clientdata(i2c, bar_struct);
    bar_struct->regmap = regmap_init_i2c(i2c, &regmap_config);

	if (IS_ERR(bar_struct->regmap))
    	return PTR_ERR(bar_struct->regmap);
    	
    bar_struct->dev = &i2c->dev;
    bar_struct->irq = i2c->irq;
    [...]
}
```



#### 设备访问功能

该API处理数据解析，格式化和传输。 在大多数情况下，使用regmap_read，regmap_write和regmap_update_bits执行设备访问。 在将数据存储到设备中或从设备中获取数据时，您应该始终记住这三个最重要的功能。 它们各自的原型是：

```c
int regmap_read(struct regmap *map, unsigned int reg, unsigned int *val);
int regmap_write(struct regmap *map, unsigned int reg, unsigned int val);
int regmap_update_bits(struct regmap *map, unsigned int reg, unsigned int mask, unsigned int val);
```

* ```regmap_write```：这会将数据写入设备。 如果在regmap_config中设置了max_register，则它将用于检查寄存器地址是否有效。 如果传递的寄存器地址小于或等于max_register，则将执行写操作；否则，将执行写操作。 否则，regmap核心将返回无效的I / O错误（-EIO）。 之后，立即调用writeable_reg回调。 在继续下一步之前，回调必须返回true。 如果返回false，则返回-EIO并停止写操作。 如果设置了wr_table而不是writeable_reg，则：
  * 如果寄存器地址在no_range内，则返回-EIO。
  * 如果寄存器地址在yes_range内，则执行下一步。
  * 如果寄存器地址既不在yes_range范围内也不在no_range范围内，则返回-EIO并终止操作。
  * 如果cache_type != REGCACHE_NONE，则启用缓存。 在这种情况下，首先更新缓存条目，然后执行对硬件的写入操作； 否则，不执行任何缓存操作。
  * 如果提供了reg_write回调，则该回调用于执行写操作； 否则，将执行通用regmap写入功能。

* ```regmap_read```：这将从设备读取数据。 它与带有适当数据结构（reg_reg 和 rd_table）的 regmap_write 完全一样。 因此，如果提供，则reg_read用于执行读取操作。 否则，将执行通用重映射读取功能。



##### regmap_update_bits 函数

regmap_update_bits 是三合一功能。 其原型如下：

```c
int regmap_update_bits(struct regmap *map, unsigned int reg,
							unsigned int mask, unsigned int val)
```

它在寄存器映射上执行读/修改/写周期。 它是 _regmap_update_bits 的封装，如下所示：

```c
static int _regmap_update_bits(struct regmap *map,
							unsigned int reg, unsigned int mask,
							unsigned int val, bool *change)
{
    int ret;
    unsigned int tmp, orig;
    
    ret = _regmap_read(map, reg, &orig);
    if (ret != 0)
    return ret;
    
    tmp = orig& ~mask;
    tmp |= val & mask;
    
    if (tmp != orig) {
        ret = _regmap_write(map, reg, tmp);
        *change = true;
    } else {
    	*change = false;
    }
    
    return ret;
}
```

这样，必须在掩码中将需要更新的位设置为1，并将对应的位设置为需要在val中赋予它们的值。

例如，要将第一位和第三位设置为1，掩码应为0b00000101，值应为0bxxxxx1x1。 要清除第七位，掩码必须为0b01000000，值应为0bx0xxxxxx，依此类推。



##### 特殊的regmap_multi_reg_write函数

```regmap_multi_reg_write() ``` 函数的目的是将多个寄存器写入设备。 其原型如下所示：

```c
int regmap_multi_reg_write(struct regmap *map, const struct reg_sequence *regs, int num_regs)
```

要查看如何使用该功能，你需要知道什么是reg_sequence结构：

```c
/**
 * Register/value pairs for sequences of writes with an optional delay in
 * microseconds to be applied after each write.
 *
 * @reg: Register address.
 * @def: Register value.
 * @delay_us: Delay to be applied after the register write in microseconds
 */
struct reg_sequence {
    unsigned int reg;
    unsigned int def;
    unsigned int delay_us;
};
```

下面是它们如何使用：

```c
static const struct reg_sequence foo_default_regs[] = {
    { FOO_REG1, 0xB8 },
    { BAR_REG1, 0x00 },
    { FOO_BAR_REG1, 0x10 },
    { REG_INIT, 0x00 },
    { REG_POWER, 0x00 },
    { REG_BLABLA, 0x00 },
};
static int probe ( ...)
{
    [...]
    ret = regmap_multi_reg_write(my_regmap, foo_default_regs,ARRAY_SIZE(foo_default_regs));
    [...]
}
```



#### 其他设备访问功能

```regmap_bulk_read()``` 和 ```regmap_bulk_write() ```用于从/向设备读取/写入多个寄存器。 将它们与大数据块一起使用：

```c
int regmap_bulk_read(struct regmap *map, unsigned int reg, void *val, size_tval_count);
int regmap_bulk_write(struct regmap *map, unsigned int reg, const void *val, size_t val_count);
```

随时查看内核源代码中的regmap头文件，以了解您有什么选择。



#### regmap和缓存

显然，regmap 支持缓存。 是否使用缓存系统取决于 ```regmap_config``` 中 ```cache_type``` 字段的值。 查看 ```include/linux/regmap.h``` ，可接受的值为：

```c
/* Anenum of all the supported cache types */
enum regcache_type {
    REGCACHE_NONE,
    REGCACHE_RBTREE,
    REGCACHE_COMPRESSED,
    REGCACHE_FLAT,
};
```

默认情况下将其设置为 REGCACHE_NONE，这意味着禁用缓存。 其他值仅定义缓存的存储方式。

你的设备在某些寄存器中可能具有预定义的上电复位值。 这些值可以存储在数组中，以便任何读取操作都可以返回数组中包含的值。 但是，任何写操作都会影响设备中的实际寄存器并更新阵列中的内容。 这是一种缓存，我们可以用来加快对设备的访问。 该数组是reg_defaults。 其结构在源代码中如下所示：

```c
/**
 * Default value for a register. We use an array of structs rather
 * than a simple array as many modern devices have very sparse
 * register maps.
 *
 * @reg: Register address.
 * @def: Register default value.
 */
struct reg_default {
    unsigned int reg;
    unsigned int def;
};
```

> 如果将cache_type设置为none，则reg_defaults将被忽略。 如果未设置default_reg但仍启用缓存，则将为您创建相应的缓存结构。

使用起来非常简单。 只需声明它，并将其作为参数传递给 regmap_config 结构。 让我们看看 ```drivers/regulator/ltc3589.c``` 中的LTC3589调节器驱动程序：

```c
static const struct reg_default ltc3589_reg_defaults[] = {
    { LTC3589_SCR1, 0x00 },
    { LTC3589_OVEN, 0x00 },
    { LTC3589_SCR2, 0x00 },
    { LTC3589_VCCR, 0x00 },
    { LTC3589_B1DTV1, 0x19 },
    { LTC3589_B1DTV2, 0x19 },
    { LTC3589_VRRCR, 0xff },
    { LTC3589_B2DTV1, 0x19 },
    { LTC3589_B2DTV2, 0x19 },
    { LTC3589_B3DTV1, 0x19 },
    { LTC3589_B3DTV2, 0x19 },
    { LTC3589_L2DTV1, 0x19 },
    { LTC3589_L2DTV2, 0x19 },
};
static const struct regmap_config ltc3589_regmap_config = {
    .reg_bits = 8,
    .val_bits = 8,
    .writeable_reg = ltc3589_writeable_reg,
    .readable_reg = ltc3589_readable_reg,
    .volatile_reg = ltc3589_volatile_reg,
    .max_register = LTC3589_L2DTV2,
    .reg_defaults = ltc3589_reg_defaults,
    .num_reg_defaults = ARRAY_SIZE(ltc3589_reg_defaults),
    .use_single_rw = true,
    .cache_type = REGCACHE_RBTREE,
};
```

对阵列中存在的任何寄存器的任何读操作都将立即返回阵列中的值。 但是，将在设备本身上执行写操作，并更新阵列中受影响的寄存器。 这样，读取 LTC3589_VRRCR 寄存器将返回 0xff。 在该寄存器中写入任何值，它将更新其在数组中的条目，以便任何新的读取操作将直接从缓存中返回最后写入的值。



### 放在一起

执行以下步骤来设置regmap子系统：

1. 根据设备的特性设置一个 ```regmap_config``` 结构。 如果需要，设置一个寄存器范围，如果需要的话，设置默认值，如果需要的话，设置 ```cache_type``` ，依此类推。 如果需要自定义读/写功能，请将其传递给 ```reg_read/reg_write``` 字段。
2. 在 ```probe``` 函数中，根据总线（I2C或SPI）使用 ```regmap_init_i2c``` 或 ```regmap_init_spi``` 分配 regmap。
3. 每当需要从寄存器读取/写入寄存器时，请调用 ```regmap_[read | write]``` 函数。
4. 完成 regmap 后，调用 ```regmap_exit``` 释放探针中分配的寄存器映射。



_regmap 示例_

为了实现我们的目标，让我们首先描述一个伪造的SPI设备，我们可以为其编写驱动程序：

* 8位寄存器地址
* 8位寄存器值
* 最大寄存器：0x80
* 写掩码为0x80
* 有效地址范围：
  * 0x20至0x4F
  * 0x60至0x7F

* 无需自定义读/写功能

下面是一个虚拟设备的框架：

```c
/* mandatory for regmap */
#include <linux/regmap.h>

/* Depending on your need you should include other files */
static struct private_struct
{
    /* Feel free to add whatever you want here */
    struct regmap *map;
    int foo;
};

static const struct regmap_range wr_rd_range[] =
{
    {
        .range_min = 0x20,
        .range_max = 0x4F,
    },{
        .range_min = 0x60,
        .range_max = 0x7F
    },
};

struct regmap_access_table drv_wr_table =
{
    .yes_ranges = wr_rd_range,
    .n_yes_ranges = ARRAY_SIZE(wr_rd_range),
};

struct regmap_access_table drv_rd_table =
{
    .yes_ranges = wr_rd_range,
    .n_yes_ranges = ARRAY_SIZE(wr_rd_range),
};

static bool writeable_reg(struct device *dev, unsigned int reg)
{
    if (reg>= 0x20 &&reg<= 0x4F)
    	return true;
    if (reg>= 0x60 &&reg<= 0x7F)
    	return true;
    return false;
}

static bool readable_reg(struct device *dev, unsigned int reg)
{
    if (reg>= 0x20 &&reg<= 0x4F)
    	return true;
    if (reg>= 0x60 &&reg<= 0x7F)
    	return true;
    return false;
}

static int my_spi_drv_probe(struct spi_device *dev)
{
    struct regmap_config config;
    struct custom_drv_private_struct *priv;
    unsigned char data;
    
    /* setup the regmap configuration */
    memset(&config, 0, sizeof(config));
    config.reg_bits = 8;
    config.val_bits = 8;
    config.write_flag_mask = 0x80;
    config.max_register = 0x80;
    config.fast_io = true;
    config.writeable_reg = drv_writeable_reg;
    config.readable_reg = drv_readable_reg;
    
    /*
    * If writeable_reg and readable_reg are set,
    * there is no need to provide wr_table nor rd_table.
    * Uncomment below code only if you do not want to use
    * writeable_reg nor readable_reg.
    */
    //config.wr_table = drv_wr_table;
    //config.rd_table = drv_rd_table;
    
    /* allocate the private data structures */
    /* priv = kzalloc */
    /* Init the regmap spi configuration */
    priv->map = regmap_init_spi(dev, &config);
    /* Use regmap_init_i2c in case of i2c bus */
    
    /*
    * Let us write into some register
    * Keep in mind that, below operation will remain same
    * whether you use SPI or I2C. It is and advantage when
    * you use regmap.
    */
    regmap_read(priv->map, 0x30, &data);
    
    [...] /* Process data */
    data = 0x24;
    regmap_write(priv->map, 0x23, data); /* write new value */
    /* set bit 2 (starting from 0) and 6 of register 0x44 */
    regmap_update_bits(priv->map, 0x44, 0b00100010, 0xFF);
    [...] /* Lot of stuff */
    
    return 0;
}
```



### 摘要

本章都是关于regmap API的。 它的简单程度让您了解它的实用性和广泛使用性。 本章介绍了您需要了解的有关regmap API的所有信息。 现在，您应该能够将任何标准SPI / I2C驱动程序转换为regmap。 下一章将介绍IIO设备，这是一个模数转换器的框架。 这类设备始终位于SPI / I2C总线的顶部。 在下一章的结尾，使用regmap API编写IIO驱动程序对我们来说将是一个挑战。